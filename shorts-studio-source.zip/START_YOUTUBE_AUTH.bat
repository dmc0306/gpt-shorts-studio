@echo off
cd /d "%~dp0"
powershell -NoProfile -File tool\start_youtube_auth.ps1
pause
