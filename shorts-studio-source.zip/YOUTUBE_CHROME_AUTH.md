# 휴대폰 Chrome 직접 인증 — 0.19.3

사용자 목표: 앱 로그인 버튼 → 휴대폰 Chrome 앱 → Google/브랜드 채널 선택 → 앱 복귀. PC, ADB, localhost, 웹 클라이언트 secret 및 별도 인증 서버를 사용하지 않습니다.

## 최초 설정

Google Cloud의 기존 프로젝트 → Google Auth Platform → 클라이언트에서 다음 **Android** 클라이언트를 엽니다.

- 클라이언트 ID: `337875283119-som1inoqhtgpf1jvkk4b31tg46rub1ag.apps.googleusercontent.com`
- 패키지: `com.local.shorts_studio`
- 설치 APK의 고정 서명 SHA-1 등록을 유지합니다.
- 고급 설정의 **Custom URI scheme 허용** 옵션을 켜고 저장합니다. Google이 기본적으로 제한하는 방식이며 계정/콘솔에서 해당 옵션이 지원되어야 합니다. 웹 클라이언트에 Android 복귀 URI를 등록하거나 웹 secret을 APK에 넣지 않습니다.
- YouTube Data API v3와 조회/업로드 동의 범위를 기존 프로젝트에서 사용합니다. 테스트 상태라면 로그인할 Google 계정이 테스트 사용자에 포함되어야 합니다.

앱에 등록한 복귀 주소:

`com.googleusercontent.apps.337875283119-som1inoqhtgpf1jvkk4b31tg46rub1ag:/oauth2redirect`

## 휴대폰에서 연결

1. APK를 업데이트 설치합니다. 앱 제거·데이터 초기화는 필요하지 않습니다.
2. 앱 설정 → 유튜브 채널·자동 업로드 → **Chrome에서 로그인 · 브랜드 채널 선택**.
3. 휴대폰에 설치된 Chrome 자체가 실행됩니다. 원하는 Google 계정과 브랜드 채널을 선택하고 YouTube 채널 조회·업로드 권한을 허용합니다.
4. 앱으로 돌아오면 조회된 실제 채널 이름/ID를 확인합니다. **이 채널로 업로드 확인** 및 아동용 여부를 선택해야 자동 업로드가 켜집니다. 로그인만으로 영상을 업로드하지 않습니다.
5. **인증 갱신 확인 · 업로드 없음**을 눌러 실제 Google 토큰 갱신과 채널 재조회를 시험합니다. 갱신 토큰을 받지 못하면 앱이 이를 표시하고 자동 업로드를 켜지 않습니다. 재로그인/동의가 필요합니다.
6. 검증 후 저장된 MP4를 수동으로 비공개 업로드하거나 완성 MP4 자동 업로드를 사용합니다. 기존 이어 올리기/채널 불일치 차단을 유지합니다.

## 0.19.3 직접 URI 복귀 처리
- 실제 기기에서 OAuth 코드가 수신됐지만 AppAuth AuthorizationManagementActivity가 USER_CANCELED_AUTH_FLOW를 반환한 것이 확인됨.
- 인증 요청 URL을 Chrome 또는 Chrome Custom Tab에 직접 실행하고, Android receiver에서 내부 MainActivity로 명시적 전달. AuthorizationManagementActivity의 onResume 취소 경로를 사용하지 않음.
- 복귀 URI는 Kotlin에서 client ID/redirect URI/state 확인, AppAuth AuthorizationResponse.Builder로 파싱, PKCE 검증자가 보존된 TokenRequest로 토큰 교환. Refresh token은 기존 Android Keystore 암호화 저장.
- 원본 URI, 인증 코드, state, 토큰은 로그/진단에 남기지 않음. 미완료 AuthorizationRequest(상태 및 PKCE verifier 포함)는 Android Keystore 암호화 저장 후 연결 성공/실패 시 삭제. 앱 프로세스가 Chrome 사용 중 종료되더라도 요청 정보 복구 가능.
- 테스트/CI 통과와 실기기 Google 인증 완료는 다른 문제이며 반드시 재검증.

## 0.19.2 OAuth 복귀 수신 진단
- Chrome Custom Tab에서도 사용자 동의 후 OAuth 유형 0 코드 1이 확인됨. 이는 AppAuth의 USER_CANCELED_AUTH_FLOW이며 실제 사용자가 취소했다는 증거는 아님.
- Android 콜백 Activity가 전달받은 이벤트만 기록하며, 복귀 URI, 토큰, 코드, 상태 값을 저장하거나 기록하지 않음.
- 리디렉션 미수신은 AUTH_CHROME_REDIRECT_MISSING, 수신 후 AppAuth 취소는 AUTH_CHROME_AFTER_REDIRECT로 분리.
- 앱 설정 화면에는 최신 수신 여부 및 URI가 인증 코드/오류를 포함하는지만 표시. 실기기 재검증 필요.

## 0.19.1 복귀 오류 확인
- 기본 Chrome 브라우저에서 동의 후 앱 복귀가 불안정하면 **Chrome 탭으로 로그인 · 복귀 오류 대안**을 시도하세요. Chrome Custom Tab도 같은 Android OAuth 클라이언트, PKCE 및 직접 앱 복귀를 사용하며 서버는 필요 없습니다.
- AUTH_CHROME_NO_RESULT는 OAuth 응답도 예외도 전달되지 않은 경우입니다. 기존 AUTH_CHROME_AUTHORIZE보다 정확하게 원인을 구분하고 OAuth 오류의 정수 유형/코드만 표시합니다. 인증 토큰, 원본 URL 등은 노출하지 않습니다.
- 어느 경로가 성공할지는 실제 기기에서 확인해야 합니다.

## 동작과 한계

- AppAuth 0.11.1의 Android public-client authorization-code flow를 사용합니다. code verifier/S256 PKCE와 일회성 state를 생성하고 반환 state 및 고정 클라이언트/복귀 URI/Google 토큰 endpoint를 검증합니다. 웹 secret은 사용하지 않습니다.
- Custom Tab/앱 내부 WebView 대신 설치된 Chrome 브라우저를 선택합니다. Chrome이 없거나 비활성화된 경우 안내 후 중단합니다.
- 인증 상태와 갱신/접근 토큰은 Android Keystore AES-GCM으로 암호화한 앱 전용 설정에 저장합니다. 클라우드 백업을 허용하지 않습니다. 원문 인증 정보/코드/토큰/브라우저 URL을 앱 UI나 공유 진단에 노출하지 않습니다.
- 갱신과 코드 교환은 Google의 고정 HTTPS endpoint로 직접 요청하며 HTTP 리디렉션을 따라가지 않습니다. 영상은 휴대폰에서 YouTube로 직접 전송합니다.
- 인증 도중 앱 프로세스가 종료되면 Chrome 연결을 다시 시작합니다. 인증 완료 후에는 암호화된 갱신 권한으로 유지합니다. 갱신 권한 만료/취소/Google 정책 변경 시 재연결이 필요하며 영구 일회 인증을 보장하지 않습니다. 외부/테스트 프로젝트의 YouTube 권한 갱신 토큰은 7일 만료 제한을 받을 수 있습니다.
- 연결 해제는 로컬 인증 정보를 삭제하고 Google 권한 취소를 시도합니다. 네트워크 등으로 원격 취소에 실패하면 Google 계정 연결 관리 안내를 표시합니다.
- 이전 Android SDK 계정 선택기에서는 Gmail만 표시되고 채널 0개가 나왔습니다. 이 Chrome 경로에서 실제 브랜드 채널이 표시되는지, 복귀·토큰 발급·갱신이 성공하는지는 사용자 기기에서 확인해야 합니다. 모의 테스트와 APK 빌드 성공은 실제 Google 인증 성공을 입증하지 않습니다.

공식/원본 문서:
- Google Custom URI scheme 허용 안내: https://developers.googleblog.com/improving-user-safety-in-oauth-flows-through-new-oauth-custom-uri-scheme-restrictions/
- AppAuth Google Android 설정: https://github.com/openid/AppAuth-Android/blob/master/app/README-Google.md
- AppAuth PKCE/redirect/token refresh: https://github.com/openid/AppAuth-Android
