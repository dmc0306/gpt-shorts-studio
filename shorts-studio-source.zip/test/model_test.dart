import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/model.dart';
void main(){
 test('only genuine TikTok HTTPS hosts are accepted',(){
  expect(tiktokUrl('공유 https://vm.tiktok.com/abc/'), 'https://vm.tiktok.com/abc/');
  for(final url in ['http://www.tiktok.com/a','https://tiktok.com.attacker.com/a','https://evil-tiktok.com/a','https://x@www.tiktok.com/a','https://www.tiktok.com:8443/a']){expect(tiktokUrl(url),isNull);}
 });
 test('editing and saved output survive round trip',(){
  final clip=Clip(id:'a',name:'test',duration:15,start:2,end:11,headline:'제목',caption:'한글',mute:true,crop:true,style:2,savedUri:'content://media/1');
  final copy=Clip.fromJson(clip.toJson());
  expect(copy.toJson(),clip.toJson());
 });
 test('link-only clip cannot be edited before source is attached',(){expect(Clip(id:'x',name:'link',url:'https://vm.tiktok.com/x').ready,false);});
}
