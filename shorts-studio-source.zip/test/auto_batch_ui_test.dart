import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/ai.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/auto_batch.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/model.dart';

void main(){
 testWidgets('back during a batch stops safely and returns after cleanup',(tester)async{
  final began=Completer<void>();var finished=false;
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   switch(call.method){
    case 'loadAiSettings':return {'key':'test','searchKey':'test'};
    case 'loadBatchReport':return '{}';
    case 'batchNotifications':return true;
    case 'batchStart':await began.future;return null;
    case 'batchFinish':finished=true;return null;
    default:return null;
   }
  });
  addTearDown(()=>TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:Builder(builder:(context)=>Scaffold(body:TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AutoBatchScreen(clips:[],onSave:()async{}))),child:const Text('열기'))))));
  await tester.tap(find.text('열기'));await tester.pumpAndSettle();
  await tester.tap(find.text('영상 5개 자동 제작'));await tester.pump();await tester.pump();
  await tester.tap(find.byTooltip('뒤로'));await tester.pumpAndSettle();
  expect(find.text('제작을 중단하고 나갈까요?'),findsOneWidget);
  await tester.tap(find.text('중단하고 나가기'));await tester.pumpAndSettle();
  expect(finished,false);began.complete();await tester.pumpAndSettle();
  expect(finished,true);expect(find.text('열기'),findsOneWidget);expect(find.byType(AutoBatchScreen),findsNothing);
 });
 testWidgets('resume reuses approved AI results and only exports the missing fifth video',(tester)async{
  final folder=Directory.systemTemp.createTempSync('studio-resume-');
  addTearDown(()=>folder.deleteSync(recursive:true));
  final file=File('${folder.path}/source.mp4')..writeAsBytesSync([0]);
  final stat=file.statSync();
  const url='https://www.tiktok.com/@resume/video/12345';
  final clip=Clip(id:'resume',name:'원본',url:url,path:file.path,duration:10,headline:'깜짝 반응\n웃음이 터져요',timedCaptions:[TimedCaption(start:0,end:2,text:'어라?',position:'bottom')]);
  final signature='${clip.id}|${clip.path}|${stat.size}|${stat.modified.millisecondsSinceEpoch}|${clip.duration}|${GeminiCaptions.defaultModel}|captions-v3-sparse';
  var exports=0,scans=0;Map? latest;
  tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadAiSettings')return {'key':'test','searchKey':'test'};
   if(call.method=='loadBatchReport')return jsonEncode({'saved':4,'items':[for(var i=0;i<4;i++){'url':'https://www.tiktok.com/@done/video/${900+i}','state':'저장 완료','title':'완성 $i','savedUri':'content://media/$i'}],
    'discovery':{'queue':[VideoCandidate(url,MixedDiscovery.topics.first,'원본').toJson()]},
    'checkpoints':{'12345':{'signature':signature,'textClear':true,'aiReady':true,'score':80,'quality':const VideoQuality().toJson()}}});
   if(call.method=='batchNotifications')return true;
   if(call.method=='scanOriginalText'){scans++;throw StateError('cached scan must not run');}
   if(call.method=='export'){exports++;return 'content://media/new';}
   if(call.method=='saveBatchReport')latest=jsonDecode((call.arguments as Map)['json'] as String) as Map;
   return null;
  });
  addTearDown(()=>tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:AutoBatchScreen(clips:[clip],onSave:()async{})));
  await tester.pumpAndSettle();
  await tester.scrollUntilVisible(find.text('남은 제작 재개'),200,scrollable:find.byType(Scrollable).first);
  await tester.pumpAndSettle();
  await tester.runAsync(()async{
   await tester.tap(find.text('남은 제작 재개'));
   for(var i=0;i<250;i++){await Future<void>.delayed(const Duration(milliseconds:20));if(latest?['running']==false)break;}
  });
  await tester.pumpAndSettle();
  expect(exports,1,reason:jsonEncode(latest));expect(scans,0);expect(latest?['saved'],5);expect(clip.savedUri,'content://media/new');
  expect(tester.takeException(),isNull);
 });

 testWidgets('phone results expose playback, filter completed clips and collapse diagnostics',(tester)async{
  tester.view.physicalSize=const Size(390,844);tester.view.devicePixelRatio=1;
  addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
  const url='https://www.tiktok.com/@a/video/123';
  const diagnostic='영상 정보를 확인하지 못했어요.\n[PAGE_METADATA]\nPAGE 본문: 999 bytes';
  tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadAiSettings')return {'key':'test','searchKey':'test'};
   if(call.method=='loadBatchReport')return jsonEncode({'saved':1,'items':[
    {'url':url,'state':'저장 완료','topic':'귀여운 동물','title':'깜짝 놀란 강아지\n웃음이 터진 순간','savedUri':'content://media/external/video/media/1'},
    {'url':'https://www.tiktok.com/@b/video/456','state':'실패','topic':'아기·가족','title':'실패 후보','error':diagnostic}
   ]});
   return null;
  });
  addTearDown(()=>tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:AutoBatchScreen(clips:[Clip(id:'123',name:'원본',path:'/test.mp4',url:url,savedUri:'content://media/external/video/media/1')],onSave:()async{})));
  await tester.pumpAndSettle();expect(tester.takeException(),isNull);
  expect(find.text('1 / 5개'),findsOneWidget);
  expect(find.textContaining('영상 전환율 50.0%'),findsOneWidget);
  await tester.scrollUntilVisible(find.text('완성본 연속 재생·평가'),200,scrollable:find.byType(Scrollable).first);
  await tester.pumpAndSettle();
  expect(find.text('완성본 연속 재생·평가'),findsOneWidget);
  expect(find.text('남은 제작 재개'),findsOneWidget);
  expect(find.text(diagnostic),findsNothing);
  await tester.scrollUntilVisible(find.widgetWithText(FilterChip,'완료'),150,scrollable:find.byType(Scrollable).first);
  await tester.tap(find.widgetWithText(FilterChip,'완료'));await tester.pumpAndSettle();
  await tester.scrollUntilVisible(find.text('저장본 재생'),150,scrollable:find.byType(Scrollable).first);await tester.pumpAndSettle();
  expect(find.text('저장본 재생'),findsOneWidget);expect(find.text('원본 재생'),findsOneWidget);expect(find.text('편집'),findsOneWidget);
  expect(find.text('실패 후보'),findsNothing);expect(tester.takeException(),isNull);
 });
}
