import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/auto_batch.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/model.dart';

void main(){
 testWidgets('phone results expose playback, filter completed clips and collapse diagnostics',(tester)async{
  tester.view.physicalSize=const Size(390,844);tester.view.devicePixelRatio=1;
  addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
  const url='https://www.tiktok.com/@a/video/123';
  const diagnostic='영상 정보를 확인하지 못했어요.\n[PAGE_METADATA]\nPAGE 본문: 999 bytes';
  tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadAiSettings')return {'key':'test','searchKey':'test'};
   if(call.method=='loadBatchReport')return jsonEncode({'saved':1,'items':[
    {'url':url,'state':'저장 완료','topic':'귀여운 동물','title':'깜짝 놀란 강아지\n웃음이 터진 순간','savedUri':'content://media/external/video/media/1'},
    {'url':'https://www.tiktok.com/@b/video/456','state':'실패','topic':'아기·가족','title':'실패 후보','error':diagnostic}
   ]});
   return null;
  });
  addTearDown(()=>tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:AutoBatchScreen(clips:[Clip(id:'123',name:'원본',path:'/test.mp4',url:url,savedUri:'content://media/external/video/media/1')],onSave:()async{})));
  await tester.pumpAndSettle();expect(tester.takeException(),isNull);
  expect(find.text('1 / 5개'),findsOneWidget);
  expect(find.text(diagnostic),findsNothing);
  await tester.tap(find.widgetWithText(FilterChip,'완료'));await tester.pumpAndSettle();
  await tester.ensureVisible(find.text('저장본 재생'));await tester.pumpAndSettle();
  expect(find.text('저장본 재생'),findsOneWidget);expect(find.text('원본 재생'),findsOneWidget);expect(find.text('편집'),findsOneWidget);
  expect(find.text('실패 후보'),findsNothing);expect(tester.takeException(),isNull);
 });
}
