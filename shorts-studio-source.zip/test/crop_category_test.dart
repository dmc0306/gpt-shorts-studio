import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/original_text.dart';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/ai_rules.dart';
import 'package:shorts_studio/scene_selection.dart';
import 'package:shorts_studio/model.dart';
void main(){
 test('center crop scope matches portrait landscape and square exports',(){
  expect(OriginalTextPolicy.cropBounds(720,1280),[0,.21875,1,.5625]);
  expect(OriginalTextPolicy.cropBounds(1280,720),[.21875,0,.5625,1]);
  expect(OriginalTextPolicy.cropBounds(720,720),[0,0,1,1]);
  expect(OriginalTextPolicy.cropBounds(0,720),isEmpty);
 });
 test('outside time is ignored while clipped letter fragments remain suspicious',(){
  final outside={'time':1,'x':.1,'y':.1,'w':.6,'h':.05,'letters':8};
  final partial={'time':12,'x':0,'y':.5,'w':.03,'h':.04,'letters':1,'clipped':true};
  expect(OriginalTextPolicy.hasOverlay({'lines':[outside]},start:10,end:20),false);
  expect(OriginalTextPolicy.hasOverlay({'lines':[outside,partial]},start:10,end:20),true);
  expect(OriginalTextPolicy.hasOverlay({'lines':[{...partial,'watermark':true}]},start:10,end:20),false);
 });
 test('category selection restricts keyword groups and supports cute rather than forced twists',(){
  expect(MixedDiscovery.topics.length,8);expect(MixedDiscovery.queries.length,8);
  final cute=MixedDiscovery.topics.indexOf('귀여운 영상');
  expect(MixedDiscovery.indicesFor('귀여운 영상'),[cute]);
  expect(MixedDiscovery.indicesFor('혼합 추천'),[0,1,2]);
  expect(MixedDiscovery.kindFor('귀여운 영상'),'cute');
  expect(MixedDiscovery.queries[cute].any((q)=>q.contains('cute')),true);
  expect(categoryRules('귀여운 영상'),contains('억지 반전'));
  final choice=SceneSelection.fromJson({'accepted':true,'kind':'cute','hook':'강아지가 졸린 모습','payoff':'꾸벅꾸벅 고개를 떨궈요','reason':'실제 모습','start':0,'end':10,'peak':5},sourceStart:0,sourceEnd:10);
  expect(choice.usable,true);
  expect(visibleTextRules(Clip(id:'c',name:'clip',videoWidth:720,videoHeight:1280),true),contains('영역 밖'));
 });
}
