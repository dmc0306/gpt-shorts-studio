import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube.dart';
import 'package:shorts_studio/youtube_settings.dart';

void main() {
  testWidgets('cancel login keeps server settings editable', (tester) async {
    final youtube = YouTube.instance;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, (call) async {
      if (call.method == 'youtubeSettings') return '{"authMode":"server"}';
      return null;
    });
    youtube.server.pending = true;
    await tester.pumpWidget(const MaterialApp(home: YouTubeSettingsScreen()));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(find.text('브라우저 인증 대기 중단'), 250);
    await tester.tap(find.text('브라우저 인증 대기 중단'));
    await tester.pump();
    expect(youtube.server.cancelled, true);
    await tester.scrollUntilVisible(find.byType(TextField).first, -250);
    await tester.enterText(find.byType(TextField).first, 'https://auth.example.com');
    await tester.pump();
    expect(tester.takeException(), null);
    youtube.server.pending = false;
    await tester.pumpWidget(const SizedBox());
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, null);
  });
}
