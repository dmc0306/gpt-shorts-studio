import 'dart:convert';
import 'dart:io';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/ai.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/auto_batch.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/model.dart';

void main(){
 testWidgets('YouTube connection failure preserves the fifth saved MP4 and batch completion',(tester)async{
  final folder=Directory.systemTemp.createTempSync('studio-resume-');
  addTearDown(()=>folder.deleteSync(recursive:true));
  final file=File('${folder.path}/source.mp4')..writeAsBytesSync([0]);
  final stat=file.statSync();
  const url='https://www.tiktok.com/@resume/video/12345';
  final clip=Clip(id:'resume',name:'원본',url:url,path:file.path,duration:10,headline:'깜짝 반응\n웃음이 터져요',timedCaptions:[TimedCaption(start:0,end:2,text:'어라?',position:'bottom')]);
  final signature='${clip.id}|${clip.path}|${stat.size}|${stat.modified.millisecondsSinceEpoch}|${clip.duration}|${GeminiCaptions.defaultModel}|crop-v6-categories|${MixedDiscovery.topics.first}';
  var exports=0,scans=0;Map? latest;
  tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='youtubeSettings')return jsonEncode({'email':'test@example.com','channelId':'UCaaaaaaaaaaaaaaaaaaaaaa','channelTitle':'Test','madeForKids':false,'automatic':true});
   if(call.method=='loadAiSettings')return {'key':'test','searchKey':'test'};
   if(call.method=='loadBatchReport')return jsonEncode({'saved':4,'items':[for(var i=0;i<4;i++){'url':'https://www.tiktok.com/@done/video/${900+i}','state':'저장 완료','title':'완성 $i','savedUri':'content://media/$i'}],
    'discovery':{'queue':[VideoCandidate(url,MixedDiscovery.topics.first,'원본').toJson()]},
    'checkpoints':{'12345':{'signature':signature,'cropTextClear':true,'previewScanned':true,'aiReady':true,'selection':{'accepted':true,'kind':'people','hook':'갑자기 놀라는 상황','payoff':'웃음이 터지는 반응','reason':'실제 행동','start':0,'end':10,'peak':5},'score':80,'quality':const VideoQuality().toJson()}}});
   if(call.method=='batchNotifications')return true;
   if(call.method=='scanOriginalText'){scans++;throw StateError('cached scan must not run');}
   if(call.method=='export'){exports++;return 'content://media/new';}
   if(call.method=='saveBatchReport')latest=jsonDecode((call.arguments as Map)['json'] as String) as Map;
   return null;
  });
  addTearDown(()=>tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:AutoBatchScreen(clips:[clip],onSave:()async{})));
  await tester.pumpAndSettle();
  await tester.scrollUntilVisible(find.text('남은 제작 재개'),200,scrollable:find.byType(Scrollable).first);
  await tester.pumpAndSettle();
  await tester.runAsync(()async{
   await tester.tap(find.text('남은 제작 재개'));
   for(var i=0;i<250;i++){await Future<void>.delayed(const Duration(milliseconds:20));if(latest?['running']==false)break;}
  });
  await tester.pumpAndSettle();
  expect(exports,1,reason:jsonEncode(latest));expect(scans,0);expect(latest?['saved'],5);expect(clip.savedUri,'content://media/new');
  final savedItem=(latest!['items'] as List).whereType<Map>().firstWhere((item)=>item['savedUri']=='content://media/new');
  expect(savedItem['youtubeError'],isA<String>().having((value)=>value.length,'nonempty',greaterThan(0)));
  expect(tester.takeException(),isNull);
 });

}
