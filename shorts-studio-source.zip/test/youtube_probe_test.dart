import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube_probe.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final calls = <String>[];
  Object? nativeFailure;
  Object? nativeReply;
  Object? lastArguments;
  setUp(() {
    calls.clear();
    lastArguments = null;
    nativeFailure = null;
    nativeReply = {'accessToken': 'private-test-token', 'resolutionShown': true};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, (call) async {
      calls.add(call.method);
      lastArguments = call.arguments;
      if (nativeFailure != null) throw nativeFailure!;
      return nativeReply;
    });
  });
  tearDown(() => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, null));

  test('direct authorization performs only own-channel GET and never changes upload settings', () async {
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () => MockClient((request) async {
      networkCalls++;
      expect(request.method, 'GET');
      expect(request.url.host, 'www.googleapis.com');
      expect(request.url.path, '/youtube/v3/channels');
      expect(request.url.queryParameters['mine'], 'true');
      expect(request.headers['Authorization'], 'Bearer private-test-token');
      expect(request.followRedirects, false);
      return http.Response(jsonEncode({'items': [{'id': 'UC${'a' * 22}', 'snippet': {'title': 'My Brand'}}], 'pageInfo': {'totalResults': 1}}), 200);
    }));
    final report = await probe.run();
    expect(report['channelTitle'], 'My Brand');
    expect(report['resolutionShown'], true);
    expect(report['uploadAttempted'], false);
    expect(report['kind'], 'single');
    expect(networkCalls, 1);
    expect(calls, ['youtubeAuthorizationProbe']);
    expect(lastArguments, {'includeUpload': false, 'selectAccount': true});
    expect(jsonEncode(report), isNot(contains('private-test-token')));
    expect(report.containsKey('accessToken'), false);
  });

  test('zero results remain diagnostic failure without hiding native chooser result', () async {
    final probe = YouTubeAuthorizationProbe(clientFactory: () => MockClient((_) async => http.Response('{"pageInfo":{"totalResults":0}}', 200)));
    final report = await probe.run();
    expect(report['stage'], 'channel_lookup');
    expect(report['kind'], 'empty');
    expect(report['count'], 0);
    expect(report['resolutionShown'], true);
    expect(report['uploadAttempted'], false);
  });

  test('native failure is redacted and never starts network or Google login', () async {
    nativeFailure = PlatformException(code: 'AUTH_NATIVE_10', message: 'sensitive raw exception private-test-token', details: {'resolutionShown': false});
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () { networkCalls++; return MockClient((_) async => http.Response('{}', 500)); });
    final report = await probe.run();
    expect(report['stage'], 'authorization');
    expect(report['code'], 'AUTH_NATIVE_10');
    expect(report['message'], contains('SHA-1'));
    expect(jsonEncode(report), isNot(contains('private-test-token')));
    expect(networkCalls, 0);
    expect(calls, ['youtubeAuthorizationProbe']);
  });

  test('missing access token never sends a channel request', () async {
    nativeReply = {'resolutionShown': true};
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () { networkCalls++; return MockClient((_) async => http.Response('{}', 500)); });
    expect((await probe.run())['kind'], 'error');
    expect(networkCalls, 0);
  });
  test('Google canceled-status intent preserves SDK status and is not called user cancellation', () async {
    nativeFailure = PlatformException(code: 'AUTH_NATIVE_16', details: {
      'resolutionShown': true, 'origin': 'activity_result', 'callbackReceived': true,
      'activityResultCode': 0, 'resultDataPresent': true, 'googleStatusCode': 16,
      'accessToken': 'private-test-token', 'intentExtras': 'private-test-token',
      'packageName': 'com.local.shorts_studio', 'signingSha1': [List.filled(20, 'AA').join(':')],
    });
    final report = await YouTubeAuthorizationProbe().run();
    expect(report['googleStatusCode'], 16);
    expect(report['activityResultCode'], 0);
    expect(report['resultDataPresent'], true);
    expect(report['origin'], 'activity_result');
    expect(report['message'], contains('직접 취소했는지는 알 수 없어요'));
    expect(report['signingSha1'], [List.filled(20, 'AA').join(':')]);
    expect(jsonEncode(report), isNot(contains('private-test-token')));
    expect(report.containsKey('intentExtras'), false);
  });

  test('no result data reports unknown early exit rather than fabricated Google error', () async {
    nativeFailure = PlatformException(code: 'AUTH_NATIVE_NO_RESULT', details: {
      'resolutionShown': true, 'origin': 'activity_result', 'callbackReceived': true,
      'activityResultCode': 0, 'resultDataPresent': false,
    });
    final report = await YouTubeAuthorizationProbe().run();
    expect(report.containsKey('googleStatusCode'), false);
    expect(report['resultDataPresent'], false);
    expect(report['message'], contains('인증 결과 없이 종료'));
  });

  test('scope and chooser comparisons are passed explicitly without changing settings', () async {
    nativeFailure = PlatformException(code: 'AUTH_NATIVE_NO_RESULT');
    final report = await YouTubeAuthorizationProbe().run(includeUpload: true, selectAccount: false);
    expect(lastArguments, {'includeUpload': true, 'selectAccount': false});
    expect(report['scopeMode'], 'read_upload');
    expect(report['selectAccount'], false);
    expect(report['uploadAttempted'], false);
    expect(calls, ['youtubeAuthorizationProbe']);
    expect(YouTubeAuthorizationProbe.nativeMessage('AUTH_NATIVE_APP_CANCELLED'), contains('앱에서'));
  });

}
