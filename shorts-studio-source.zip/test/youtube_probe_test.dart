import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube_probe.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final calls = <String>[];
  Object? nativeFailure;
  Object? nativeReply;
  setUp(() {
    calls.clear();
    nativeFailure = null;
    nativeReply = {'accessToken': 'private-test-token', 'resolutionShown': true};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, (call) async {
      calls.add(call.method);
      if (nativeFailure != null) throw nativeFailure!;
      return nativeReply;
    });
  });
  tearDown(() => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, null));

  test('direct authorization performs only own-channel GET and never changes upload settings', () async {
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () => MockClient((request) async {
      networkCalls++;
      expect(request.method, 'GET');
      expect(request.url.host, 'www.googleapis.com');
      expect(request.url.path, '/youtube/v3/channels');
      expect(request.url.queryParameters['mine'], 'true');
      expect(request.headers['Authorization'], 'Bearer private-test-token');
      expect(request.followRedirects, false);
      return http.Response(jsonEncode({'items': [{'id': 'UC${'a' * 22}', 'snippet': {'title': 'My Brand'}}], 'pageInfo': {'totalResults': 1}}), 200);
    }));
    final report = await probe.run();
    expect(report['channelTitle'], 'My Brand');
    expect(report['resolutionShown'], true);
    expect(report['uploadAttempted'], false);
    expect(report['kind'], 'single');
    expect(networkCalls, 1);
    expect(calls, ['youtubeAuthorizationProbe']);
    expect(jsonEncode(report), isNot(contains('private-test-token')));
    expect(report.containsKey('accessToken'), false);
  });

  test('zero results remain diagnostic failure without hiding native chooser result', () async {
    final probe = YouTubeAuthorizationProbe(clientFactory: () => MockClient((_) async => http.Response('{"pageInfo":{"totalResults":0}}', 200)));
    final report = await probe.run();
    expect(report['stage'], 'channel_lookup');
    expect(report['kind'], 'empty');
    expect(report['count'], 0);
    expect(report['resolutionShown'], true);
    expect(report['uploadAttempted'], false);
  });

  test('native failure is redacted and never starts network or Google login', () async {
    nativeFailure = PlatformException(code: 'AUTH_NATIVE_10', message: 'sensitive raw exception private-test-token', details: {'resolutionShown': false});
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () { networkCalls++; return MockClient((_) async => http.Response('{}', 500)); });
    final report = await probe.run();
    expect(report['stage'], 'authorization');
    expect(report['code'], 'AUTH_NATIVE_10');
    expect(report['message'], contains('SHA-1'));
    expect(jsonEncode(report), isNot(contains('private-test-token')));
    expect(networkCalls, 0);
    expect(calls, ['youtubeAuthorizationProbe']);
  });

  test('missing access token never sends a channel request', () async {
    nativeReply = {'resolutionShown': true};
    var networkCalls = 0;
    final probe = YouTubeAuthorizationProbe(clientFactory: () { networkCalls++; return MockClient((_) async => http.Response('{}', 500)); });
    expect((await probe.run())['kind'], 'error');
    expect(networkCalls, 0);
  });
}
