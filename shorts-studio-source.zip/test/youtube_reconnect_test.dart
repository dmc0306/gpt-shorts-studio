import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_sign_in_platform_interface/google_sign_in_platform_interface.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube.dart';
import 'package:shorts_studio/youtube_channel.dart';

const oldId = 'UCaaaaaaaaaaaaaaaaaaaaaa', newId = 'UCbbbbbbbbbbbbbbbbbbbbbb';

class SignInStub extends GoogleSignInPlatform {
  final events = <String>[];
  String token = 'old';
  bool failRevoke = false;
  AuthenticationResults get account => const AuthenticationResults(
    user: GoogleSignInUserData(email: 'test@example.com', id: 'account'),
    authenticationTokens: AuthenticationTokenData(idToken: null),
  );
  @override
  Future<void> init(InitParameters params) async {}
  @override
  Future<AuthenticationResults?> attemptLightweightAuthentication(
    AttemptLightweightAuthenticationParameters params,
  ) async => account;
  @override
  bool supportsAuthenticate() => true;
  @override
  Future<AuthenticationResults> authenticate(
    AuthenticateParameters params,
  ) async {
    events.add('authenticate');
    return account;
  }

  @override
  bool authorizationRequiresUserInteraction() => false;
  @override
  Future<ClientAuthorizationTokenData?> clientAuthorizationTokensForScopes(
    ClientAuthorizationTokensForScopesParameters params,
  ) async {
    events.add('token:$token');
    return ClientAuthorizationTokenData(accessToken: token);
  }

  @override
  Future<ServerAuthorizationTokenData?> serverAuthorizationTokensForScopes(
    ServerAuthorizationTokensForScopesParameters params,
  ) async => null;
  @override
  Future<void> signOut(SignOutParams params) async {}
  @override
  Future<void> clearAuthorizationToken(
    ClearAuthorizationTokenParams params,
  ) async {
    events.add('clear:${params.accessToken}');
  }

  @override
  Future<void> disconnect(DisconnectParams params) async {
    events.add('revoke');
    if (failRevoke) throw StateError('revoke failed');
    token = 'new';
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late SignInStub sdk;
  late YouTube service;
  Map<String, dynamic>? saved;
  setUp(() {
    sdk = SignInStub();
    GoogleSignInPlatform.instance = sdk;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(Native.channel, (call) async {
          if (call.method == 'youtubeSettings')
            return jsonEncode(
              YouTubePreferences(
                email: 'test@example.com',
                channelId: oldId,
                channelTitle: 'Old',
                madeForKids: false,
                automatic: true,
              ).toJson(),
            );
          if (call.method == 'saveYoutubeSettings')
            saved =
                jsonDecode((call.arguments as Map)['json'] as String)
                    as Map<String, dynamic>;
          return null;
        });
    service = YouTube.forTesting(
      clientFactory: () => MockClient((request) async {
        final fresh = request.headers['Authorization'] == 'Bearer new';
        return http.Response(
          jsonEncode({
            'items': [
              {
                'id': fresh ? newId : oldId,
                'snippet': {'title': fresh ? 'New channel' : 'Old channel'},
              },
            ],
          }),
          200,
        );
      }),
    );
  });
  tearDown(() {
    service.dispose();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(Native.channel, null);
  });
  test(
    'channel change clears old token and revokes grant before fresh authentication',
    () async {
      await service.initialize();
      await service.connect();
      expect(
        sdk.events.indexOf('clear:old'),
        lessThan(sdk.events.indexOf('revoke')),
      );
      expect(
        sdk.events.indexOf('revoke'),
        lessThan(sdk.events.indexOf('authenticate')),
      );
      expect(service.channel?.id, newId);
      expect(service.automatic, false);
      expect(service.preferences.channelId, isEmpty);
      expect(saved?['channelId'], isEmpty);
      await service.confirmChannel();
      expect(service.preferences.channelId, newId);
    },
  );
  test(
    'failed revocation never silently reuses old account or confirmed destination',
    () async {
      await service.initialize();
      sdk.failRevoke = true;
      await expectLater(service.connect(), throwsStateError);
      expect(sdk.events, contains('revoke'));
      expect(sdk.events, isNot(contains('authenticate')));
      expect(service.user, isNull);
      expect(service.channel, isNull);
      expect(service.automatic, false);
      expect(saved?['channelId'], isEmpty);
    },
  );
  test(
    'a different channel from refresh disables automatic upload and requires confirmation',
    () async {
      await service.initialize();
      sdk.token = 'new';
      await service.refreshChannel();
      expect(service.channel?.id, newId);
      expect(service.preferences.channelId, isEmpty);
      expect(service.automatic, false);
      expect(saved?['automatic'], false);
    },
  );
}
