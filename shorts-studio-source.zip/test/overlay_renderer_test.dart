import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/overlay_renderer.dart';
import 'package:shorts_studio/model.dart';
import 'package:shorts_studio/caption_layout.dart';

void main(){
 testWidgets('export renders without a UI frame while lifecycle is paused',(tester)async{
  tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  try{
   await tester.runAsync(()async{
    final png=await renderOverlayPng(headline:'첫 줄\n둘째 줄',caption:'장면 자막',style:0);
    final codec=await ui.instantiateImageCodec(png);
    final frame=await codec.getNextFrame();
    expect(frame.image.width,1080);expect(frame.image.height,1920);
    final rgba=(await frame.image.toByteData(format:ui.ImageByteFormat.rawRgba))!.buffer.asUint8List();
    expect(rgba[3],255); // black top bar
    expect(rgba[(600*1080+10)*4+3],0); // video stays transparent
    frame.image.dispose();codec.dispose();
    final subtitle=await renderOverlayPng(headline:'',caption:'시간별 자막',style:0,subtitleOnly:true);
    final cc=await ui.instantiateImageCodec(subtitle);final cf=await cc.getNextFrame();
    expect(cf.image.width,1080);expect(cf.image.height,200);
    cf.image.dispose();cc.dispose();
   });
  }finally{tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);}
 });
 testWidgets('moving subtitle strip matches full preview placement',(tester)async{
  await tester.runAsync(()async{
   final clip=Clip(id:'x',name:'x',videoWidth:1080,videoHeight:1080);
   for(final avoid in [[0.0,0.0,1.0,.6],[0.0,.4,1.0,.6],[0.0,0.0,1.0,1.0]]){
    final cue=TimedCaption(start:0,end:1,text:'장면별 위치',position:'auto',avoid:avoid);
    final placement=placeCaption(cue.text,cue:cue,clip:clip);
    final png=await renderOverlayPng(headline:'',caption:cue.text,style:0,subtitleOnly:true,cue:cue,clip:clip);
    final cc=await ui.instantiateImageCodec(png);final cf=await cc.getNextFrame();
    final pixels=(await cf.image.toByteData(format:ui.ImageByteFormat.rawRgba))!.buffer.asUint8List();
    expect(cf.image.height,200);
    final x=placement.rect.center.dx.floor();
    expect(pixels[(8*1080+x)*4+3],greaterThan(0));
    cf.image.dispose();cc.dispose();
   }
  });
 });

}
