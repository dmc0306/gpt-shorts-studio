import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/overlay_renderer.dart';

void main(){
 testWidgets('export renders without a UI frame while lifecycle is paused',(tester)async{
  tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  try{
   await tester.runAsync(()async{
    final png=await renderOverlayPng(headline:'첫 줄\n둘째 줄',caption:'장면 자막',style:0);
    final codec=await ui.instantiateImageCodec(png);
    final frame=await codec.getNextFrame();
    expect(frame.image.width,1080);expect(frame.image.height,1920);
    final rgba=(await frame.image.toByteData(format:ui.ImageByteFormat.rawRgba))!.buffer.asUint8List();
    expect(rgba[3],255); // black top bar
    expect(rgba[(600*1080+10)*4+3],0); // video stays transparent
    frame.image.dispose();codec.dispose();
    final subtitle=await renderOverlayPng(headline:'',caption:'시간별 자막',style:0,subtitleOnly:true);
    final cc=await ui.instantiateImageCodec(subtitle);final cf=await cc.getNextFrame();
    expect(cf.image.width,1080);expect(cf.image.height,200);
    cf.image.dispose();cc.dispose();
   });
  }finally{tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);}
 });
}
