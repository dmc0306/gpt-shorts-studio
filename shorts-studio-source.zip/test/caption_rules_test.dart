import 'dart:convert';
import 'package:characters/characters.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/ai.dart';
import 'package:shorts_studio/headline.dart';
import 'package:shorts_studio/caption_layout.dart';
import 'package:shorts_studio/model.dart';
import 'package:shorts_studio/original_text.dart';

void main(){
 test('headline enforces eleven graphemes including spaces on both lines',(){
  expect(validHeadline('가나다라마바사아자차카\n12345678901'),true);
  expect(validHeadline('123456789012\n짧은 줄'),false);
  expect(fitHeadline('123456789012\n123456789012\n셋째'),'12345678901\n12345678901');
  expect(fitHeadline(List.filled(12,'👨‍👩‍👧').join()).characters.length,11);
  final value=const HeadlineInputFormatter().formatEditUpdate(TextEditingValue.empty,const TextEditingValue(text:'123456789012',selection:TextSelection.collapsed(offset:12)));
  expect(value.text,'12345678901');expect(value.selection.extentOffset,11);
  final composing=const TextEditingValue(text:'12345678901ㄱ',composing:TextRange(start:11,end:12));
  expect(const HeadlineInputFormatter().formatEditUpdate(value,composing),composing);
  expect(GeminiCaptions.normalizeHeadline('주인을 따라\n기침하는 강아지').split('\n').every((s)=>s.characters.length<=11),true);
  expect(()=>GeminiCaptions.normalizeHeadline('주인이 기침을 할 때마다\n따라서 기침하는 귀여운 강아지'),throwsA(isA<AiFailure>()));
 });
 test('original English lower subtitle is caught without treating a tiny watermark as a title',(){
  final line={'x':.12,'y':.91,'w':.8,'h':.06,'letters':26,'watermark':false};
  expect(OriginalTextPolicy.hasOverlay({'lines':[line]}),true);
  expect(OriginalTextPolicy.suspicious({...line,'watermark':true}),false);
  expect(OriginalTextPolicy.suspicious({...line,'w':.12,'h':.012}),false);
 });
 test('subtitle evidence overrides edited false and missing evidence cannot pass',(){
  for(final state in ['present','uncertain']){
   expect(VideoQuality.fromJson({'edited':false,'aiSuspected':false,'uncertain':false,'reason':'하단 영어 문장','sourceText':state}).acceptable,false);
  }
  expect(()=>VideoQuality.fromJson({'edited':false,'aiSuspected':false,'uncertain':false,'reason':'확인'}),throwsA(isA<AiFailure>()));
 });
 testWidgets('captions move away from subjects and use black margin when no safe space exists',(tester)async{
  final clip=Clip(id:'x',name:'x',videoWidth:1080,videoHeight:1080);
  final top=TimedCaption(start:0,end:1,text:'깜짝 반응',position:'auto',avoid:[0,0,1,.55]);
  final bottom=TimedCaption(start:1,end:2,text:'깜짝 반응',position:'auto',avoid:[0,.45,1,.55]);
  final a=placeCaption(top.text,cue:top,clip:clip),b=placeCaption(bottom.text,cue:bottom,clip:clip);
  expect(a.rect.overlaps(subjectRect(top,clip)!),false);expect(b.rect.overlaps(subjectRect(bottom,clip)!),false);
  expect(a.stripTop,greaterThan(b.stripTop));
  final full=TimedCaption(start:2,end:3,text:'화면을 가리지 않아요',position:'auto',avoid:[0,0,1,1]);
  expect(placeCaption(full.text,cue:full,clip:clip).stripTop,1560);
  expect(placeCaption(full.text,cue:TimedCaption(start:2,end:3,text:full.text,position:'auto'),clip:clip).stripTop,1560);
 });
 testWidgets('portrait and landscape centered crop map source coordinates correctly',(tester)async{
  final cue=TimedCaption(start:0,end:1,text:'자막',position:'auto',avoid:[.25,.25,.5,.5]);
  final portrait=Clip(id:'p',name:'p',videoWidth:720,videoHeight:1280);
  final rectangle=subjectRect(cue,portrait)!;
  expect(rectangle.center.dx,540);expect(rectangle.center.dy,960);
  final landscape=Clip(id:'l',name:'l',videoWidth:1920,videoHeight:1080);
  expect(subjectRect(cue,landscape)!.center.dx,540);
  final restored=Clip.fromJson(jsonDecode(jsonEncode({...portrait.toJson(),'timedCaptions':[cue.toJson()]})) as Map<String,dynamic>);
  expect(restored.timedCaptions.single.avoid,cue.avoid);expect(restored.timedCaptions.single.position,'auto');
 });
}
