import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/ai.dart';
import 'package:shorts_studio/model.dart';
import 'package:shorts_studio/headline.dart';

Map<String,dynamic> titles()=>{'titles':{for(final key in ['curiosity','twist','humor'])key:{'top':'귀여운 고양이','bottom':'표정이 왜 저래ㅋㅋ'}}};
Map<String,dynamic> response(Map data)=>{'candidates':[{'content':{'parts':[{'text':jsonEncode(data)}]},'finishReason':'STOP'}]};
class Reply implements HttpClientResponse {@override dynamic noSuchMethod(Invocation i)=>null;}
class TextService extends GeminiCaptions {
 TextService(this.payloads);final List<Map<String,dynamic>> payloads;final requests=<Uri>[];final bodies=<Object?>[];
 @override Future<HttpClientResponse> request(String method,Uri uri,String key,{Map<String,String> headers=const {},Object? body,File? file})async{expect(file,isNull);requests.add(uri);bodies.add(body);return Reply();}
 @override Future<Map<String,dynamic>> jsonResponse(HttpClientResponse response)async=>payloads.removeAt(0);
}
void main(){
 test('every style independently validates graphemes and spaces',(){
  expect(GeminiCaptions.decodeTitles(titles()),hasLength(3));
  final bad=titles();(bad['titles'] as Map)['twist']={'top':'귀여운','bottom':'표정이 왜 저래ㅋㅋ'};
  expect(()=>GeminiCaptions.decodeTitles(bad),throwsA(isA<AiFailure>()));
  expect(validHeadline('👨‍👩‍👧가나다라\n👍🏽가나다라'),true);
  expect(validHeadline('가 나 다\n가나다라마'),true);
  expect(validHeadline('짧음\n가나다라마바사아자차카'),false);
 });
 test('title repair makes only text requests and preserves captions',()async{
  final bad=titles();(bad['titles'] as Map)['humor']={'top':'짧음','bottom':'표정이 왜 저래ㅋㅋ'};
  final service=TextService([response(bad),response(titles())]);
  final original=TimedCaption(start:1,end:2,text:'어라?');
  final clip=Clip(id:'a',name:'a',path:'/video',headline:'기존 제목을\n그대로 둡니다',timedCaptions:[original],aiContext:{'path':'/video','sceneSummary':'고양이가 놀람','timeline':[original.toJson()]});
  final draft=await service.regenerate(clip:clip,key:'fake',model:'fake',titleOnly:true,onStatus:(_){});
  expect(draft.titles,hasLength(3));expect(draft.captions.single,same(original));expect(clip.headline,'기존 제목을\n그대로 둡니다');
  expect(service.requests,hasLength(2));expect(service.requests.every((u)=>u.path.endsWith(':generateContent')),true);
  expect(jsonEncode(service.bodies),isNot(contains('file_data')));
 });
 test('caption regeneration uses saved timestamps and subject bounds without upload',()async{
  final cue=TimedCaption(start:1,end:2,text:'어라?',position:'left',avoid:[.2,.2,.4,.4]);
  final clip=Clip(id:'a',name:'a',path:'/video',headline:'제목은 그대로\n자막만 바꿔요',aiContext:{'path':'/video','sceneSummary':'고양이가 놀람','timeline':[cue.toJson()]});
  final service=TextService([response({'captions':[{'start':1,'end':2,'text':'엥? ㄷㄷ','position':'auto','avoid':[]}]})]);
  final draft=await service.regenerate(clip:clip,key:'fake',model:'fake',titleOnly:false,onStatus:(_){});
  expect(draft.headline,clip.headline);expect(draft.captions.single.avoid,cue.avoid);expect(draft.captions.single.position,'left');
  expect(service.requests,hasLength(1));expect(jsonEncode(service.bodies),isNot(contains('file_data')));
  final restored=Clip.fromJson(clip.toJson());expect(restored.aiContext['sceneSummary'],'고양이가 놀람');
 });
 test('missing analysis never uploads automatically',()async{
  final service=TextService([]);
  await expectLater(service.regenerate(clip:Clip(id:'a',name:'a'),key:'fake',model:'fake',titleOnly:true,onStatus:(_){}),throwsA(isA<AiFailure>()));
  expect(service.requests,isEmpty);
 });
}
