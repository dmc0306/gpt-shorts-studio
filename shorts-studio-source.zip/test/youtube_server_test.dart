import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube_server.dart';
import 'package:shorts_studio/youtube_channel.dart';
import 'package:shorts_studio/youtube_upload.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  String? stored;
  setUp(() {
    stored = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, (call) async {
      if (call.method == 'saveYoutubeServerConfig') stored = call.arguments['json'] as String;
      if (call.method == 'youtubeServerConfig') return stored;
      return null;
    });
  });
  tearDown(() => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, null));
  test('server accepts only HTTPS origins without credentials or query', () {
    for (final url in ['http://example.com', 'https://user:key@example.com', 'https://example.com/path', 'https://example.com?q=x', 'https://example.com:8765']) {
      expect(() => YouTubeServer.validateUrl(url), throwsA(isA<YouTubeFailure>()));
    }
    expect(YouTubeServer.validateUrl('https://auth.example.com/').toString(), 'https://auth.example.com');
  });
  test('persistent server mode retains upload confirmation', () {
    final p = YouTubePreferences(authMode: 'server', email: 'server:id:channel', channelId: 'channel', madeForKids: false);
    expect(YouTubePreferences.fromJson(p.toJson()).authMode, 'server');
  });
  test('remote bearer is sent only to configured origin and token is cached', () async {
    var requests = 0;
    final server = YouTubeServer(clientFactory: () => MockClient((request) async {
      requests++;
      expect(request.url.toString(), 'https://auth.example.com/api/token');
      expect(request.followRedirects, false);
      expect(request.headers['Authorization'], 'Bearer ${'a' * 43}');
      return http.Response(jsonEncode({'access_token': 'short-token', 'identity': 'server:client:channel',
        'expires': DateTime.now().add(const Duration(hours: 1)).millisecondsSinceEpoch / 1000}), 200);
    }));
    await server.configure('https://auth.example.com', 'a' * 43);
    expect(await server.token(), 'short-token');
    expect(await server.token(), 'short-token');
    expect(requests, 1);
    expect(await server.configuredUrl(), 'https://auth.example.com');
  });
  test('server errors identify auth rather than video generation', () async {
    final server = YouTubeServer(clientFactory: () => MockClient((_) async => http.Response('{}', 401)));
    await server.configure('https://auth.example.com', 'a' * 43);
    await expectLater(server.token(), throwsA(isA<YouTubeFailure>().having((e) => e.message, 'message', contains('AUTH_KEY'))));
  });
}
