import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/ai.dart';
import 'package:shorts_studio/model.dart';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/discovery_store.dart';

void main(){
 final clip=Clip(id:'test',name:'test',duration:10);
 Map<String,dynamic> response(String text,{String finish='STOP'})=>{'candidates':[{'finishReason':finish,'content':{'parts':[{'text':'ignored reasoning','thought':true},{'text':text}]}}]};
 final draft={'headline':'웃긴 순간\n깜짝 반전','captions':[{'start':1,'end':3,'text':'깜짝 놀랐어요'}],'entertainmentScore':80,'quality':{'edited':false,'aiSuspected':false,'uncertain':false,'reason':'실제 동작'}};
 test('automatic schema can be constructed and encoded without runtime casts',(){
  final schema=jsonDecode(jsonEncode(GeminiCaptions.responseSchema(assessEntertainment:true))) as Map;
  expect((schema['properties'] as Map)['quality']['properties']['edited']['type'],'BOOLEAN');
  expect(schema['required'],containsAll(['headline','captions','quality','entertainmentScore']));
 });
 test('normal and fenced results preserve captions and quality while ignoring thoughts',(){
  for(final text in [jsonEncode(draft),'```json\n${jsonEncode(draft)}\n```']){
   final result=GeminiCaptions.decodeDraft(response(text),clip,assessEntertainment:true);
   expect(result.entertainmentScore,80);expect(result.quality.acceptable,true);expect(result.captions.single.start,1);
  }
 });
 test('empty, truncated, missing and malformed fields have distinct safe diagnostics',(){
  final cases=[(response(''),'AI_EMPTY'),(response('{'),'AI_JSON'),(response('{}'),'AI_FIELDS'),(response('{',finish:'MAX_TOKENS'),'AI_MAX_TOKENS'),(response(jsonEncode({...draft,'quality':null})),'AI_QUALITY_FIELDS')];
  for(final entry in cases){expect(()=>GeminiCaptions.decodeDraft(entry.$1,clip,assessEntertainment:true),throwsA(isA<AiFailure>().having((e)=>e.message,'message',contains(entry.$2)).having((e)=>e.retryable,'retryable',true)));}
 });
 test('deferred AI failures stay queued but are not retried in the same execution',(){
  final store=DiscoveryStore();const c=VideoCandidate('https://www.tiktok.com/@a/video/100','pets','a');store.add([c]);
  expect(store.next('pets',skip:{'100'}),isNull);
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.next('pets')?.url,c.url);expect(restored.seen,isEmpty);
 });
}
