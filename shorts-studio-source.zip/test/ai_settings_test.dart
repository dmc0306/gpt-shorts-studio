import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/ai_settings.dart';
import 'package:shorts_studio/bridge.dart';

void main(){
 TestWidgetsFlutterBinding.ensureInitialized();
 testWidgets('shared settings save both keys and model; dismissal keeps controllers alive',(tester)async{
  Map<dynamic,dynamic>? saved;
  tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadAiSettings')return {'key':'test-gemini','searchKey':'test-search','model':'gemini-3.1-flash-lite'};
   if(call.method=='saveAiSettings'){saved=call.arguments as Map;return null;}
   throw PlatformException(code:'unexpected');
  });
  addTearDown(()=>tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
  await tester.pumpWidget(MaterialApp(home:Builder(builder:(context)=>Scaffold(body:TextButton(onPressed:()=>showAiSettings(context),child:const Text('open'))))));
  await tester.tap(find.text('open'));await tester.pumpAndSettle();
  expect(find.text('Tavily 검색 API 키'),findsOneWidget);
  await tester.ensureVisible(find.text('추천 모델로 변경'));
  await tester.tap(find.text('추천 모델로 변경')); await tester.pump();
  await tester.tap(find.text('저장'));await tester.pumpAndSettle();
  expect(saved,{'key':'test-gemini','searchKey':'test-search','model':'gemini-3.5-flash-lite'});
  expect(tester.takeException(),isNull);
 });
}
