import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/discovery_store.dart';
import 'package:shorts_studio/ai.dart';

void main(){
 test('all topics have diverse unique Korean and English situations',(){
  for(final group in MixedDiscovery.queries){
   expect(group.length,36);expect(group.toSet().length,36);
   expect(group.any((q)=>RegExp(r'[가-힣]').hasMatch(q)),true);
   expect(group.any((q)=>RegExp(r'^[a-z]').hasMatch(q)),true);
  }
 });
 test('old successful searches do not monopolize once every query was tried',(){
  final store=DiscoveryStore();
  for(final q in MixedDiscovery.queries[0])store.count(q,'searches');
  final old=MixedDiscovery.queries[0].first;
  for(var i=0;i<5;i++){store.count(old,'searches');store.count(old,'saved');}
  expect(store.queryFor(0,{}),isNot(old));
  for(final q in MixedDiscovery.queries[0].skip(1))store.count(q,'emptySearches');
  expect(store.queryFor(0,{}),isNot(old));
 });
 test('preferred accounts rotate situations across persisted searches',(){
  final store=DiscoveryStore();
  store.feedback['99']={'url':'https://www.tiktok.com/@creator/video/99','label':'괜찮음','topic':MixedDiscovery.topics[1]};
  final first=store.targetedQuery(1,{})!;store.count(first,'searches');
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.targetedQuery(1,{}),isNot(first));
  expect(first,contains('site:tiktok.com/@creator'));
 });

 test('empty search history rotates into unused alternatives on next run',(){
  final store=DiscoveryStore();
  final first=<String>{};
  for(var i=0;i<3;i++){final q=store.queryFor(0,first);first.add(q);store.count(q,'searches');}
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  final next=<String>{};
  for(var i=0;i<3;i++){final q=restored.queryFor(0,next);expect(first, isNot(contains(q)));next.add(q);restored.count(q,'searches');}
 });

 test('user preference changes account ranking and rejects disliked videos after reload',(){
  final store=DiscoveryStore();
  const a=VideoCandidate('https://www.tiktok.com/@a/video/11','pets','a');
  const b=VideoCandidate('https://www.tiktok.com/@b/video/22','pets','b');
  store.add([a,b]);
  store.feedback['old']={'url':'https://www.tiktok.com/@b/video/99','label':'괜찮음','query':'q'};
  expect(store.next('pets')?.url,b.url);
  store.feedback['22']={'url':b.url,'label':'재미없음','query':'q'};
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.next('pets')?.url,a.url);
  expect(restored.preference(query:'q'),.5);
  restored.feedback['22']!['label']='괜찮음';expect(restored.next('pets')?.url,b.url);
 });

 test('keeps all 20 candidates and persists queue, exclusions and metrics',(){
  final found=MixedDiscovery.candidatesFromResults(List.generate(20,(i)=>{'url':'https://www.tiktok.com/@a/video/${100+i}','title':'$i'}),MixedDiscovery.topics[1],{});
  expect(found.length,20);
  final store=DiscoveryStore()..add(found);
  store.count('q','downloaded');store.finish(found.first);
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.queue.length,19);expect(restored.seen,contains('100'));expect(restored.metrics['q']?['downloaded'],1);
  restored.add([found.first,found.last]);expect(restored.queue.length,19);
 });
 test('cached selection preserves mixed topics and prioritizes successful accounts',(){
  final store=DiscoveryStore();
  const a=VideoCandidate('https://www.tiktok.com/@a/video/1','pets','a');
  const b=VideoCandidate('https://www.tiktok.com/@b/video/2','pets','b');
  store.add([a,b]);store.accountCount(b.url,'attempted');store.accountCount(b.url,'saved');
  expect(store.next('pets')?.url,b.url);expect(store.next('family'),isNull);
  expect(store.queue.length,2);store.finish(b);expect(store.next('pets')?.url,a.url);
 });
 test('query exploration never repeats within an execution',(){
  final store=DiscoveryStore();final used=<String>{};
  for(var i=0;i<3;i++){final q=store.queryFor(0,used);expect(used.add(q),true);store.count(q,'searches');}
  expect(used.length,3);
 });
 test('quality flags reject edited, suspected AI and uncertain footage',(){
  for(final flag in ['edited','aiSuspected','uncertain']){
   final data=<String,dynamic>{'edited':false,'aiSuspected':false,'uncertain':false,'reason':'관찰 근거','sourceText':'absent'};data[flag]=true;
   expect(VideoQuality.fromJson(data).acceptable,false);
  }
  expect(const VideoQuality().acceptable,true);
  expect(()=>VideoQuality.fromJson({'edited':'false'}),throwsA(isA<AiFailure>()));
 });
}
