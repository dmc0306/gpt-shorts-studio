import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/discovery.dart';
import 'package:shorts_studio/discovery_store.dart';
import 'package:shorts_studio/ai.dart';

void main(){
 test('keeps all 20 candidates and persists queue, exclusions and metrics',(){
  final found=MixedDiscovery.candidatesFromResults(List.generate(20,(i)=>{'url':'https://www.tiktok.com/@a/video/${100+i}','title':'$i'}),MixedDiscovery.topics[1],{});
  expect(found.length,20);
  final store=DiscoveryStore()..add(found);
  store.count('q','downloaded');store.finish(found.first);
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.queue.length,19);expect(restored.seen,contains('100'));expect(restored.metrics['q']?['downloaded'],1);
  restored.add([found.first,found.last]);expect(restored.queue.length,19);
 });
 test('cached selection preserves mixed topics and prioritizes successful accounts',(){
  final store=DiscoveryStore();
  const a=VideoCandidate('https://www.tiktok.com/@a/video/1','pets','a');
  const b=VideoCandidate('https://www.tiktok.com/@b/video/2','pets','b');
  store.add([a,b]);store.accountCount(b.url,'attempted');store.accountCount(b.url,'saved');
  expect(store.next('pets')?.url,b.url);expect(store.next('family'),isNull);
  expect(store.queue.length,2);store.finish(b);expect(store.next('pets')?.url,a.url);
 });
 test('query exploration never repeats within an execution',(){
  final store=DiscoveryStore();final used=<String>{};
  for(var i=0;i<3;i++){final q=store.queryFor(0,used);expect(used.add(q),true);store.count(q,'searches');}
  expect(used.length,3);
 });
 test('quality flags reject edited, suspected AI and uncertain footage',(){
  for(final flag in ['edited','aiSuspected','uncertain']){
   final data=<String,dynamic>{'edited':false,'aiSuspected':false,'uncertain':false,'reason':'관찰 근거'};data[flag]=true;
   expect(VideoQuality.fromJson(data).acceptable,false);
  }
  expect(const VideoQuality().acceptable,true);
  expect(()=>VideoQuality.fromJson({'edited':'false'}),throwsA(isA<AiFailure>()));
 });
}
