import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/main.dart';
import 'package:shorts_studio/ai_settings.dart';

void main(){
  setUp((){TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
    if(call.method=='loadProjects')return '[]';
    if(call.method=='loadAiSettings')return <String,String>{};
    if(call.method=='watchEnabled')return false;
    if(call.method=='drainInbox')return <dynamic>[];
    return null;
  });});
  tearDown((){TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null);});
  testWidgets('restored home retains TikTok automatic production beside YouTube settings',(tester)async{
    await tester.pumpWidget(const Studio());await tester.pumpAndSettle();
    expect(find.text('혼합 영상 5개 자동 제작'),findsOneWidget);
    expect(find.byTooltip('유튜브 채널 설정'),findsOneWidget);
    expect(find.byTooltip('앱 설정'),findsOneWidget);
    expect(find.text('링크 추가'),findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });
  testWidgets('shared settings retain search and Gemini fields with a YouTube entry',(tester)async{
    await tester.pumpWidget(MaterialApp(home:Builder(builder:(context)=>Scaffold(body:TextButton(onPressed:()=>showAiSettings(context),child:const Text('설정'))))));
    await tester.tap(find.text('설정'));await tester.pumpAndSettle();
    expect(find.text('Tavily 검색 API 키'),findsOneWidget);
    expect(find.text('Gemini API 키'),findsOneWidget);
    expect(find.text('유튜브 채널 · 자동 업로드'),findsOneWidget);
    await tester.pumpWidget(const SizedBox());await tester.pumpAndSettle();
  });
}
