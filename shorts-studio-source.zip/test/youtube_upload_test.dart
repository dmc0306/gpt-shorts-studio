import 'package:flutter_test/flutter_test.dart';
import '../tool/verify_youtube_upload.dart' as protocol;

void main() {
  test(
    'resumable upload protocol, recovery and duplicate protection',
    protocol.main,
  );
}
