import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/discovery.dart';

void main() {
  test('refill changes search terms and excludes attempted IDs across rounds', () {
    final queries=<String>{};
    for(var round=0;round<MixedDiscovery.maxRounds;round++){
      for(final topic in MixedDiscovery.topicsForRound(round)){
        queries.add(MixedDiscovery.searchBody(topic)['query'] as String);
      }
    }
    expect(queries.length,9);
    final seen={'123'};
    final result=MixedDiscovery.candidatesFromResults([
      {'url':'https://www.tiktok.com/@newname/video/123'},
      {'url':'https://www.tiktok.com/@other/video/456'},
    ],'pets',seen);
    expect(result.map((c)=>MixedDiscovery.videoId(c.url)),['456']);
  });
  test('search uses basic credits and only actual individual result URLs', () {
    final body=MixedDiscovery.searchBody('funny pets');
    expect(body['search_depth'],'basic');
    expect(body['auto_parameters'],false);
    expect(body['include_answer'],false);
    expect(body['include_domains'],['tiktok.com']);
    final seen={'999'};
    final candidates=MixedDiscovery.candidatesFromResults([
      {'url':'https://www.tiktok.com/@a/video/999','title':'saved'},
      {'url':'https://www.tiktok.com/@a/video/123?x=1','title':'pet'},
      {'url':'https://m.tiktok.com/@a/video/123','title':'duplicate'},
      {'url':'https://www.tiktok.com/discover/pets','title':'not a video'},
      {'url':'https://example.com','content':'https://www.tiktok.com/@a/video/555'},
      {'url':null},
    ],'animals',seen);
    expect(candidates.length,1);
    expect(candidates.single.url,'https://www.tiktok.com/@a/video/123');
    expect(candidates.single.title,'pet');
    expect(seen,{'999','123'});
  });
  test('canonicalizes only HTTPS individual TikTok video URLs', () {
    expect(MixedDiscovery.videoUrl('https://m.tiktok.com/@demo/video/123/?x=1'),
        'https://www.tiktok.com/@demo/video/123');
    for (final raw in [
      'https://tiktok.com.evil.example/@demo/video/123',
      'http://www.tiktok.com/@demo/video/123',
      'https://user@www.tiktok.com/@demo/video/123',
      'https://www.tiktok.com:8443/@demo/video/123',
      'https://www.tiktok.com/@demo',
      'https://www.tiktok.com/discover/funny',
      'https://www.tiktok.com/@demo/video/abc',
    ]) {
      expect(MixedDiscovery.videoUrl(raw), isNull, reason: raw);
    }
  });

  test('resolver handles direct, malformed and untrusted URLs without requests', () async {
    final discovery = MixedDiscovery();
    addTearDown(discovery.cancel);
    expect(await discovery.resolve('https://www.tiktok.com/@demo/video/123'),
        'https://www.tiktok.com/@demo/video/123');
    expect(await discovery.resolve('https://['), isNull);
    expect(await discovery.resolve('https://example.com/grounding-api-redirect/x'), isNull);
    expect(await discovery.resolve('https://vertexaisearch.cloud.google.com/other'), isNull);
  });
}
