import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/discovery.dart';

void main() {
  test('canonicalizes only HTTPS individual TikTok video URLs', () {
    expect(MixedDiscovery.videoUrl('https://m.tiktok.com/@demo/video/123/?x=1'),
        'https://www.tiktok.com/@demo/video/123');
    for (final raw in [
      'https://tiktok.com.evil.example/@demo/video/123',
      'http://www.tiktok.com/@demo/video/123',
      'https://user@www.tiktok.com/@demo/video/123',
      'https://www.tiktok.com:8443/@demo/video/123',
      'https://www.tiktok.com/@demo',
      'https://www.tiktok.com/discover/funny',
      'https://www.tiktok.com/@demo/video/abc',
    ]) {
      expect(MixedDiscovery.videoUrl(raw), isNull, reason: raw);
    }
  });

  test('resolver handles direct, malformed and untrusted URLs without requests', () async {
    final discovery = MixedDiscovery();
    addTearDown(discovery.cancel);
    expect(await discovery.resolve('https://www.tiktok.com/@demo/video/123'),
        'https://www.tiktok.com/@demo/video/123');
    expect(await discovery.resolve('https://['), isNull);
    expect(await discovery.resolve('https://example.com/grounding-api-redirect/x'), isNull);
    expect(await discovery.resolve('https://vertexaisearch.cloud.google.com/other'), isNull);
  });
}
