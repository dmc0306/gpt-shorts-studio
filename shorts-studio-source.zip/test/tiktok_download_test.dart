import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/tiktok_download.dart';
String page(Map<String,dynamic> item)=>'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__">${jsonEncode({'__DEFAULT_SCOPE__':{'webapp.video-detail':{'itemInfo':{'itemStruct':item}}}})}</script>';
Map<String,dynamic> item()=>{'id':'123','desc':'한글 제목','author':{'uniqueId':'creator'},'video':{'downloadAddr':'https://v16.tiktokcdn.com/video.mp4'}};
void main(){
 test('extracts download URL and metadata for the requested video',(){
  final media=parseTikTokPage(page(item()),'123');
  expect(media.url.host,'v16.tiktokcdn.com');expect(media.title,'한글 제목');expect(media.creator,'@creator');
 });
 test('supports old SIGI metadata format',(){
  final html='<script id="SIGI_STATE">${jsonEncode({'ItemModule':{'123':item()}})}</script>';
  expect(parseTikTokPage(html,'123').title,'한글 제목');
 });
 test('does not download a different video or a private/disabled video',(){
  expect(()=>parseTikTokPage(page(item()),'456'),throwsA(isA<DownloadFailure>()));
  for(final flag in [{'privateItem':true},{'downloadEnabled':false}]){
   expect(()=>parseTikTokPage(page({...item(),...flag}),'123'),throwsA(isA<DownloadFailure>()));
  }
 });
 test('does not use playback URL as a download URL',(){
  expect(()=>parseTikTokPage(page({...item(),'video':{'playAddr':'https://v16.tiktokcdn.com/play.mp4'}}),'123'),throwsA(isA<DownloadFailure>()));
 });
 test('rejects non-TikTok hosts, insecure URLs and authentication URLs',(){
  for(final raw in ['http://v16.tiktokcdn.com/a','https://tiktokcdn.com.attacker.test/a','https://127.0.0.1/a','https://user:pass@v16.tiktokcdn.com/a','https://v16.tiktokcdn.com:8443/a']){
   expect(allowedDownloadUri(Uri.parse(raw)),false);
   expect(()=>parseTikTokPage(page({...item(),'video':{'downloadAddr':raw}}),'123'),throwsA(isA<DownloadFailure>()));
  }
  expect(allowedDownloadUri(Uri.parse('https://vm.tiktok.com/short'),page:true),true);
  expect(allowedDownloadUri(Uri.parse('https://v16.tiktokcdn.com/a'),page:true),false);
 });
 test('missing, invalid, or login-page JSON produces an explicit failure',(){
  for(final html in ['<h1>Login</h1>','<script id="SIGI_STATE">invalid</script>']){
   expect(()=>parseTikTokPage(html,'123'),throwsA(isA<DownloadFailure>()));
  }
 });
}
