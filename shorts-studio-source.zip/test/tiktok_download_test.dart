import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/tiktok_download.dart';
String page(Map<String,dynamic> item)=>'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__">${jsonEncode({'__DEFAULT_SCOPE__':{'webapp.video-detail':{'itemInfo':{'itemStruct':item}}}})}</script>';
Map<String,dynamic> item()=>{'id':'123','desc':'한글 제목','author':{'uniqueId':'creator'},'video':{'playAddr':'https://v16.tiktokcdn.com/video.mp4'}};
void main(){
 test('duration preflight skips media requests, retries at most once',()async{
  final longPage=page({...item(),'video':{'playAddr':'https://v16.tiktokcdn.com/a','duration':60}});
  for(final first in [PageReply(400,'bad request'),PageReply(200,'<h1>Video</h1>')]){
   final client=PageClient([first,PageReply(200,longPage)]);
   await expectLater(TikTokDownloader(client:client).download('https://www.tiktok.com/@a/video/123',(_,__) {},minDuration:5,maxDuration:30),throwsA(isA<DownloadLengthFailure>().having((e)=>e.duration,'duration',60)));
   expect(client.requests,hasLength(2));expect(client.requests.every((u)=>u.host=='www.tiktok.com'),true);
  }
 });
 test('persistent 400 and visible verification never loop or fetch media',()async{
  final client=PageClient([PageReply(400,'bad'),PageReply(400,'bad')]);
  await expectLater(TikTokDownloader(client:client).download('https://www.tiktok.com/@a/video/123',(_,__) {}),throwsA(isA<DownloadFailure>().having((e)=>e.code,'code','PAGE_HTTP_400')));
  expect(client.requests,hasLength(2));
  final challenge=PageClient([PageReply(200,'<h1>Verify you are human</h1>')]);
  await expectLater(TikTokDownloader(client:challenge).download('https://www.tiktok.com/@a/video/123',(_,__) {}),throwsA(isA<DownloadFailure>().having((e)=>e.code,'code','PAGE_VERIFICATION')));
  expect(challenge.requests,hasLength(1));
 });
 test('duration boundaries and unknown duration are handled without guessing',(){
  for(final seconds in [5,30]){final media=parseTikTokPage(page({...item(),'video':{'playAddr':'https://v16.tiktokcdn.com/a','duration':seconds}}),'123');expect(media.duration,seconds);checkMediaDuration(media,minDuration:5,maxDuration:30);}
  for(final seconds in [0,-1,'unknown']){final media=parseTikTokPage(page({...item(),'video':{'playAddr':'https://v16.tiktokcdn.com/a','duration':seconds}}),'123');expect(media.duration,isNull);checkMediaDuration(media,minDuration:5,maxDuration:30);}
 });
 test('nested matching item and lower-case URL list support keep ID restrictions',(){
  final nested='<script id="api-data">${jsonEncode({'items':[{'itemStruct':{...item(),'video':{'playAddr':{'urlList':['https://v16.tiktokcdn.com/a']},'duration':12.5}}}]})}</script>';
  expect(parseTikTokPage(nested,'123').duration,12.5);
  expect(()=>parseTikTokPage(nested,'456'),throwsA(isA<DownloadFailure>()));
 });
 test('parses api-data videoDetail when universal state has no video',(){
  final html=File('test/fixtures/tiktok_api_data.html').readAsStringSync();
  final media=parseTikTokPage(html,'123');
  expect(media.url.path,'/example.mp4');
  expect(pageMetadataSummary(html,'123'),contains('api-data: JSON 정상 · 영상 일치=true'));
  expect(pageMetadataSummary(html,'123'),contains('상태=0'));
  expect(()=>parseTikTokPage(html,'456'),throwsA(isA<DownloadFailure>()));
  for(final flag in [{'privateItem':true},{'downloadEnabled':false}]){
   final restricted='<script id="api-data">${jsonEncode({'videoDetail':{'itemInfo':{'itemStruct':{...item(),...flag}}}})}</script>';
   expect(()=>parseTikTokPage(restricted,'123'),throwsA(isA<DownloadFailure>()));
  }
 });

 test('parses the observed mobile share reflow schema',(){
  final html=File('test/fixtures/tiktok_reflow.html').readAsStringSync();
  final media=parseTikTokPage(html,'123');
  expect(media.url.host,'v16-webapp-prime.tiktok.com');
  expect(pageMetadataSummary(html,'123'),contains('영상 일치=true'));
  expect(pageMetadataSummary(html,'123'),contains('playAddr=true'));
  expect(()=>parseTikTokPage(html,'456'),throwsA(isA<DownloadFailure>()));
 });
 test('selects only matching video across desktop and reflow scopes',(){
  final html='<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__">${jsonEncode({'__DEFAULT_SCOPE__':{'webapp.video-detail':{'itemInfo':{'itemStruct':{...item(),'id':'456'}}},'webapp.reflow.video.detail':{'itemInfo':{'itemStruct':item()}}}})}</script>';
  expect(parseTikTokPage(html,'123').title,'한글 제목');
 });
 test('captcha references in scripts do not prove human verification',(){
  expect(hasVisibleVerification('<script>const config={captcha:true};</script><h1>Video</h1>'),false);
  expect(hasVisibleVerification('<h1>Verify you are <b>human</b></h1>'),true);
 });
 test('download URL failure keeps its own code despite captcha script references',(){
  final html=page({...item(),'video':{'downloadAddr':'https://v16.tiktokcdn.com/a'}})+'<script>captcha()</script>';
  expect(()=>parseTikTokPage(html,'123'),throwsA(isA<DownloadFailure>().having((e)=>e.code,'code','PAGE_DOWNLOAD_URL')));
  expect(pageMetadataSummary(html,'123'),contains('playAddr=false'));
  expect(pageMetadataSummary(html,'123'),isNot(contains('https://')));
 });
 test('metadata diagnostics distinguish absent and malformed scripts',(){
  expect(pageMetadataSummary('<h1>Video</h1>','123'),contains('없음'));
  expect(pageMetadataSummary('<script id="SIGI_STATE">invalid</script>','123'),contains('JSON 해석 실패'));
 });
 test('cookies survive responses without Set-Cookie and obey domain scope',(){
  final jar=DownloadCookies();final origin=Uri.parse('https://vm.tiktok.com/short');
  jar.update(origin,[Cookie('shared','one')..domain='.tiktok.com'..path='/',Cookie('local','two')]);
  jar.update(origin,[]);
  expect(jar.forUri(origin).map((c)=>c.name),containsAll(['shared','local']));
  expect(jar.forUri(Uri.parse('https://www.tiktok.com/video')).map((c)=>c.name),['shared']);
  expect(jar.forUri(Uri.parse('https://child.vm.tiktok.com/video')).map((c)=>c.name),['shared']);
  expect(jar.forUri(Uri.parse('https://v16.tiktokcdn.com/video')),isEmpty);
 });
 test('expired and deleted cookies are removed, path boundaries are respected',(){
  final jar=DownloadCookies();final origin=Uri.parse('https://www.tiktok.com/video/123');
  jar.update(origin,[Cookie('scoped','one')..path='/video']);
  expect(jar.forUri(origin),hasLength(1));
  expect(jar.forUri(Uri.parse('https://www.tiktok.com/videos')),isEmpty);
  jar.update(origin,[Cookie('scoped','two')..path='/video'..maxAge=0]);
  expect(jar.forUri(origin),isEmpty);
 });
 test('extracts download URL and metadata for the requested video',(){
  final media=parseTikTokPage(page(item()),'123');
  expect(media.url.host,'v16.tiktokcdn.com');expect(media.title,'한글 제목');expect(media.creator,'@creator');
 });
 test('supports old SIGI metadata format',(){
  final html='<script id="SIGI_STATE">${jsonEncode({'ItemModule':{'123':item()}})}</script>';
  expect(parseTikTokPage(html,'123').title,'한글 제목');
 });
 test('does not download a different video or a private/disabled video',(){
  expect(()=>parseTikTokPage(page(item()),'456'),throwsA(isA<DownloadFailure>()));
  for(final flag in [{'privateItem':true},{'downloadEnabled':false}]){
   expect(()=>parseTikTokPage(page({...item(),...flag}),'123'),throwsA(isA<DownloadFailure>()));
  }
 });
 test('does not fall back to a watermarked download URL',(){
  expect(()=>parseTikTokPage(page({...item(),'video':{'downloadAddr':'https://v16.tiktokcdn.com/play.mp4'}}),'123'),throwsA(isA<DownloadFailure>()));
 });
 test('rejects non-TikTok hosts, insecure URLs and authentication URLs',(){
  for(final raw in ['http://v16.tiktokcdn.com/a','https://tiktokcdn.com.attacker.test/a','https://127.0.0.1/a','https://user:pass@v16.tiktokcdn.com/a','https://v16.tiktokcdn.com:8443/a']){
   expect(allowedDownloadUri(Uri.parse(raw)),false);
   expect(()=>parseTikTokPage(page({...item(),'video':{'playAddr':raw}}),'123'),throwsA(isA<DownloadFailure>()));
  }
  expect(allowedDownloadUri(Uri.parse('https://vm.tiktok.com/short'),page:true),true);
  expect(allowedDownloadUri(Uri.parse('https://v16.tiktokcdn.com/a'),page:true),false);
 });
 test('missing, invalid, or login-page JSON produces an explicit failure',(){
  for(final html in ['<h1>Login</h1>','<script id="SIGI_STATE">invalid</script>']){
   expect(()=>parseTikTokPage(html,'123'),throwsA(isA<DownloadFailure>()));
  }
 });
}

class PageHeaders implements HttpHeaders {
 @override ContentType? contentType=ContentType.html;
 @override void set(String name,Object value,{bool preserveHeaderCase=false}){}
 @override String? value(String name)=>null;
 @override dynamic noSuchMethod(Invocation invocation)=>super.noSuchMethod(invocation);
}
class PageReply extends Stream<List<int>> implements HttpClientResponse {
 PageReply(this.statusCode,this.body);
 final String body;
 @override final int statusCode;
 @override final headers=PageHeaders();
 @override List<Cookie> get cookies=>[];
 @override int get contentLength=>utf8.encode(body).length;
 @override StreamSubscription<List<int>> listen(void Function(List<int>)? onData,{Function? onError,void Function()? onDone,bool? cancelOnError})=>Stream.value(utf8.encode(body)).listen(onData,onError:onError,onDone:onDone,cancelOnError:cancelOnError);
 @override dynamic noSuchMethod(Invocation invocation)=>super.noSuchMethod(invocation);
}
class PageRequest implements HttpClientRequest {
 PageRequest(this.reply);
 final PageReply reply;
 @override final headers=PageHeaders();
 @override final List<Cookie> cookies=[];
 @override Future<HttpClientResponse> close()async=>reply;
 @override dynamic noSuchMethod(Invocation invocation)=>null;
}
class PageClient implements HttpClient {
 PageClient(this.replies);
 final List<PageReply> replies;
 final requests=<Uri>[];
 @override Future<HttpClientRequest> getUrl(Uri uri)async{requests.add(uri);return PageRequest(replies.removeAt(0));}
 @override dynamic noSuchMethod(Invocation invocation)=>null;
}
