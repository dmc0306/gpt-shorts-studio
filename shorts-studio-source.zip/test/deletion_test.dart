import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/deletion.dart';
import 'package:shorts_studio/model.dart';

void main(){
 TestWidgetsFlutterBinding.ensureInitialized();
 tearDown(()=>TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
 test('saved deletion preserves original and failed deletion preserves URI',()async{
  final clip=Clip(id:'a',name:'원본',path:'/original.mp4',savedUri:'content://media/1',category:'귀여운 동물',inCollection:false);
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{throw PlatformException(code:'DENIED');});
  await expectLater(deleteSavedClip(clip),throwsA(isA<PlatformException>()));expect(clip.savedUri,'content://media/1');
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async=>null);
  await deleteSavedClip(clip);expect(clip.savedUri,isEmpty);expect(clip.path,'/original.mp4');expect(clip.inCollection,true);
  clip.inCollection=false;final restored=Clip.fromJson(clip.toJson());expect(restored.inCollection,false);expect(restored.category,'귀여운 동물');
 });
 test('deleted saved URI is removed from the batch report',()async{
  Map? saved;
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadBatchReport')return jsonEncode({'items':[{'state':'저장 완료','savedUri':'content://media/1'},{'state':'저장 완료','savedUri':'content://media/2'}]});
   if(call.method=='saveBatchReport')saved=jsonDecode((call.arguments as Map)['json'] as String) as Map;
   return null;
  });
  await syncDeletedReports({'content://media/1'});expect(saved?['saved'],1);expect(saved?['items'][0]['state'],'삭제');expect(saved?['items'][1]['savedUri'],'content://media/2');
 });
}
