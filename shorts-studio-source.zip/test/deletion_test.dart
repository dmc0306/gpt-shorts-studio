import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/deletion.dart';
import 'package:shorts_studio/model.dart';

void main(){
 test('replacement commits new file before deleting old file and updates review URI',()async{
  final events=<String>[];Map? report;
  final clip=Clip(id:'a',name:'원본',path:'/original.mp4',savedUri:'content://media/old',headline:'수정 제목');
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='deleteSavedVideo'){events.add('delete');expect((call.arguments as Map)['uri'],'content://media/old');}
   if(call.method=='loadBatchReport')return jsonEncode({'items':[{'savedUri':'content://media/old','state':'저장 완료'}]});
   if(call.method=='saveBatchReport')report=jsonDecode((call.arguments as Map)['json'] as String) as Map;
   return null;
  });
  final complete=await replaceSavedClip(clip,'content://media/new',()async{events.add('persist');expect(clip.savedUri,'content://media/new');});
  expect(complete,true);expect(events,['persist','delete']);expect(clip.path,'/original.mp4');expect(report?['items'][0]['savedUri'],'content://media/new');
 });
 test('replacement keeps old file on persistence failure and new file on deletion failure',()async{
  var deleted=false;final clip=Clip(id:'a',name:'원본',savedUri:'content://media/old',savedAt:'old-time');
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='deleteSavedVideo'){deleted=true;throw PlatformException(code:'DENIED');}return '{}';
  });
  await expectLater(replaceSavedClip(clip,'content://media/new',()async{throw StateError('disk');}),throwsStateError);
  expect(deleted,false);expect(clip.savedUri,'content://media/old');expect(clip.savedAt,'old-time');
  expect(await replaceSavedClip(clip,'content://media/new',()async{}),false);expect(clip.savedUri,'content://media/new');
 });
 TestWidgetsFlutterBinding.ensureInitialized();
 tearDown(()=>TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,null));
 test('saved deletion preserves original and failed deletion preserves URI',()async{
  final clip=Clip(id:'a',name:'원본',path:'/original.mp4',savedUri:'content://media/1',category:'귀여운 동물',inCollection:false);
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{throw PlatformException(code:'DENIED');});
  await expectLater(deleteSavedClip(clip),throwsA(isA<PlatformException>()));expect(clip.savedUri,'content://media/1');
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async=>null);
  await deleteSavedClip(clip);expect(clip.savedUri,isEmpty);expect(clip.path,'/original.mp4');expect(clip.inCollection,true);
  clip.inCollection=false;final restored=Clip.fromJson(clip.toJson());expect(restored.inCollection,false);expect(restored.category,'귀여운 동물');
 });
 test('deleted saved URI is removed from the batch report',()async{
  Map? saved;
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel,(call)async{
   if(call.method=='loadBatchReport')return jsonEncode({'items':[{'state':'저장 완료','savedUri':'content://media/1'},{'state':'저장 완료','savedUri':'content://media/2'}]});
   if(call.method=='saveBatchReport')saved=jsonDecode((call.arguments as Map)['json'] as String) as Map;
   return null;
  });
  await syncDeletedReports({'content://media/1'});expect(saved?['saved'],1);expect(saved?['items'][0]['state'],'삭제');expect(saved?['items'][1]['savedUri'],'content://media/2');
 });
}
