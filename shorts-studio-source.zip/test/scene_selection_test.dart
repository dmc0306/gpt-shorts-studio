import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/scene_selection.dart';
import 'package:shorts_studio/ai.dart';
import 'package:shorts_studio/model.dart';
import 'package:shorts_studio/discovery_store.dart';

Map<String,dynamic> scene()=>{'accepted':true,'kind':'skill','hook':'공이 장애물 뒤에 놓여요','payoff':'회전한 공이 구멍에 들어가요','reason':'연속된 실제 동작','start':20,'end':35,'peak':30};
Map<String,dynamic> response(Map<String,dynamic> payload)=>{'candidates':[{'content':{'parts':[{'text':jsonEncode(payload)}]},'finishReason':'STOP'}]};
void main(){
 test('validates source bounds, maximum clip length and event time',(){
  final s=SceneSelection.fromJson(scene(),sourceStart:0,sourceEnd:60);expect(s.usable,true);expect(s.start,20);
  for(final bad in [{'start':-1},{'end':61},{'start':1,'end':40},{'peak':50},{'start':double.nan},{'accepted':'yes'}]){
   expect(()=>SceneSelection.fromJson({...scene(),...bad},sourceStart:0,sourceEnd:60),throwsFormatException);
  }
  expect(SceneSelection.fromJson({...scene(),'hook':'귀엽다','payoff':''},sourceStart:0,sourceEnd:60).usable,false);
  expect(SceneSelection.fromJson({...scene(),'kind':'other'},sourceStart:0,sourceEnd:60).usable,false);
 });
 test('captions use original timestamps in the selected short segment',(){
  final c=Clip(id:'test',name:'source',duration:60);
  final payload={'headline':'놀라운 손기술\n공이 돌아 들어감','captions':[{'start':29,'end':31,'text':'여기로 들어간다고 ㄷㄷ','position':'auto','avoid':[]}],'selection':scene(),'entertainmentScore':80,'quality':const VideoQuality().toJson()};
  final d=GeminiCaptions.decodeDraft(response(payload),c,assessEntertainment:true,selectHighlight:true);
  expect(d.selection!.start,20);expect(d.selection!.end,35);expect(d.captions.single.start,29);
  expect(c.start,0);expect(c.end,60);
  final bad={...payload,'captions':[{'start':1,'end':3,'text':'밖','position':'auto','avoid':[]}]};
  expect(()=>GeminiCaptions.decodeDraft(response(bad),c,assessEntertainment:true,selectHighlight:true),throwsA(isA<AiFailure>()));
  payload['selection']={...scene(),'accepted':false};payload.remove('headline');payload['captions']=[];
  expect(GeminiCaptions.decodeDraft(response(payload),c,assessEntertainment:true,selectHighlight:true).selection!.usable,false);
 });
 test('selection is required in batch schema and feedback summary persists',(){
  expect(GeminiCaptions.responseSchema(assessEntertainment:true,selectHighlight:true)['required'],contains('selection'));
  final store=DiscoveryStore();store.feedback['1']={'kind':'skill','label':'괜찮음'};store.feedback['2']={'kind':'people','label':'재미없음'};
  final restored=DiscoveryStore.fromJson(jsonDecode(jsonEncode(store.toJson())) as Map);
  expect(restored.contentPreferences(),contains('skill'));expect(restored.contentPreferences(),contains('재미없음'));
 });
}
