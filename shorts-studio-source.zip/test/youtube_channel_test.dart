import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/youtube_channel.dart';
import 'package:shorts_studio/youtube_upload.dart';

const channelId = 'UCaaaaaaaaaaaaaaaaaaaaaa';
void main() {
  String body(List<dynamic> items) => jsonEncode({'items': items});
  Map<String, dynamic> item(String id) => {
    'id': id,
    'snippet': {'title': '검증 채널'},
  };
  test(
    'reads actual authorized channel using mine, without redirecting the token',
    () async {
      final client = MockClient((request) async {
        expect(request.url.queryParameters['mine'], 'true');
        expect(request.headers['Authorization'], 'Bearer fake');
        expect(request.followRedirects, false);
        return http.Response(
          body([item(channelId)]),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      });
      final channel = await readYouTubeChannel(client, 'fake');
      expect(channel.id, channelId);
      expect(channel.title, '검증 채널');
    },
  );
  test('zero or ambiguous channels cannot be confirmed', () {
    for (final items in [
      [],
      [item(channelId), item('UCbbbbbbbbbbbbbbbbbbbbbb')],
    ]) {
      expect(
        () => YouTubeChannel.parse(body(items)),
        throwsA(isA<YouTubeFailure>()),
      );
    }
  });
  test('invalid channel IDs and missing names are rejected', () {
    expect(
      () => YouTubeChannel.parse(body([item('wrong')])),
      throwsA(isA<YouTubeFailure>()),
    );
    expect(
      () => YouTubeChannel.parse(
        body([
          {'id': channelId},
        ]),
      ),
      throwsA(anything),
    );
  });
  test('one channel with empty nextPageToken is not falsely rejected', () {
    final channel = YouTubeChannel.parse(
      jsonEncode({
        'items': [item(channelId)],
        'nextPageToken': '',
        'pageInfo': {'totalResults': 1},
      }),
    );
    expect(channel.id, channelId);
  });
  test(
    'zero channels and multiple channels have different redacted diagnostics',
    () {
      try {
        YouTubeChannel.parse(body([]));
        fail('expected empty result');
      } on YouTubeChannelLookupFailure catch (e) {
        expect(e.message, contains('YT_CHANNEL_EMPTY'));
        expect(e.diagnostic['count'], 0);
        expect(e.diagnostic['kind'], 'empty');
      }
      try {
        YouTubeChannel.parse(
          body([item(channelId), item('UCbbbbbbbbbbbbbbbbbbbbbb')]),
        );
        fail('expected ambiguity');
      } on YouTubeChannelLookupFailure catch (e) {
        expect(e.message, contains('YT_CHANNEL_MULTIPLE'));
        expect(e.diagnostic['count'], 2);
        expect(e.diagnostic['kind'], 'multiple');
        expect(e.diagnostic.keys, isNot(contains('token')));
      }
    },
  );
  test('API may omit items when pageInfo explicitly says zero results', () {
    expect(
      () => YouTubeChannel.parse('{"pageInfo":{"totalResults":0}}'),
      throwsA(
        isA<YouTubeChannelLookupFailure>().having(
          (e) => e.diagnostic['kind'],
          'kind',
          'empty',
        ),
      ),
    );
  });
  test('another account or channel cannot receive a confirmed upload', () {
    final settings = YouTubePreferences(
      email: 'a@example.com',
      channelId: channelId,
      madeForKids: false,
    );
    expect(
      () => settings.requireTarget(
        'a@example.com',
        const YouTubeChannel(channelId, 'same'),
      ),
      returnsNormally,
    );
    expect(
      () => settings.requireTarget(
        'b@example.com',
        const YouTubeChannel(channelId, 'same'),
      ),
      throwsA(isA<YouTubeFailure>()),
    );
    expect(
      () => settings.requireTarget(
        'a@example.com',
        const YouTubeChannel('UCbbbbbbbbbbbbbbbbbbbbbb', 'other'),
      ),
      throwsA(isA<YouTubeFailure>()),
    );
  });
  test(
    'old automatic flag without channel and audience confirmation stays disabled',
    () {
      final settings = YouTubePreferences.fromJson({'automatic': true});
      expect(settings.automatic, false);
      expect(settings.confirmed, false);
      expect(
        () => settings.requireTarget(
          'a@example.com',
          const YouTubeChannel(channelId, 'same'),
        ),
        throwsA(isA<YouTubeFailure>()),
      );
    },
  );
  test('confirmed identity, audience and disclosure survive storage', () {
    final settings = YouTubePreferences(
      email: 'a@example.com',
      channelId: channelId,
      channelTitle: '검증 채널',
      madeForKids: false,
      automatic: true,
      syntheticMedia: true,
    );
    final copy = YouTubePreferences.fromJson(
      jsonDecode(jsonEncode(settings.toJson())) as Map<String, dynamic>,
    );
    expect(copy.toJson(), settings.toJson());
    expect(copy.automatic, true);
  });
  test('channel access failure is not treated as a valid channel', () async {
    final client = MockClient(
      (_) async => http.Response(
        '{"error":{"errors":[{"reason":"insufficientPermissions"}]}}',
        403,
      ),
    );
    await expectLater(
      readYouTubeChannel(client, 'fake'),
      throwsA(isA<YouTubeFailure>()),
    );
  });
}
