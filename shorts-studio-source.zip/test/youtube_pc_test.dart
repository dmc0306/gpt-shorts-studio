import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube_pc.dart';
import 'package:shorts_studio/youtube_upload.dart';
import 'package:shorts_studio/youtube_channel.dart';
import 'package:shorts_studio/youtube.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final calls = <String>[];
  String pairing = 'test-pairing';
  setUp(() {
    pairing = 'test-pairing';
    calls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(Native.channel, (call) async {
          calls.add(call.method);
          if (call.method == 'youtubePcKey') return pairing;
          return null;
        });
  });
  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(Native.channel, null),
  );

  test(
    'only paired loopback requests, no redirects, no refresh token required by phone',
    () async {
      final pc = YouTubePc(
        clientFactory: () => MockClient((request) async {
          expect(request.url.toString(), 'http://127.0.0.1:8765/api/token');
          expect(request.method, 'POST');
          expect(request.followRedirects, false);
          expect(request.headers['Authorization'], 'Bearer test-pairing');
          return http.Response(
            jsonEncode({
              'access_token': 'short-lived',
              'identity': 'pc:client:channel',
            }),
            200,
          );
        }),
      );
      expect(await pc.token(), 'short-lived');
      expect(pc.identity, 'pc:client:channel');
    },
  );
  test('missing pairing cannot contact broker or open browser', () async {
    pairing = '';
    final pc = YouTubePc(
      clientFactory: () => throw StateError('must not connect'),
    );
    await expectLater(pc.connect(), throwsA(isA<YouTubeFailure>()));
    expect(calls, isNot(contains('openYoutubeBrowser')));
    expect(pc.pending, false);
  });
  test('pairing after a failed attempt recovers without restarting the app', () async {
    pairing = '';
    final pc = YouTubePc(clientFactory: () => MockClient((request) async => http.Response(
      jsonEncode({'access_token': 'fresh', 'identity': 'pc:client:channel'}), 200)));
    await expectLater(pc.token(), throwsA(isA<YouTubeFailure>()));
    pairing = 'new-pairing';
    expect(await pc.token(), 'fresh');
  });
  test('broker cannot direct phone to a non-Google login page', () async {
    final pc = YouTubePc(
      clientFactory: () => MockClient(
        (request) async => http.Response(
          jsonEncode({'flow': 'flow', 'url': 'https://evil.example/login'}),
          200,
        ),
      ),
    );
    await expectLater(pc.connect(), throwsA(isA<YouTubeFailure>()));
    expect(calls, isNot(contains('openYoutubeBrowser')));
  });
  test('redirect responses never supply credentials', () async {
    final pc = YouTubePc(
      clientFactory: () => MockClient(
        (request) async => http.Response(
          jsonEncode({'error': 'redirect'}),
          302,
          headers: {'Location': 'https://evil.example'},
        ),
      ),
    );
    await expectLater(pc.token(), throwsA(isA<YouTubeFailure>()));
    expect(pc.identity, isEmpty);
  });
  test(
    'browser login opens system browser then polls completion without handling Google consent',
    () async {
      final requests = <String>[];
      final pc = YouTubePc(
        clientFactory: () => MockClient((request) async {
          requests.add(request.url.path);
          return http.Response(
            jsonEncode(
              request.url.path == '/api/login'
                  ? {
                      'flow': 'one-flow',
                      'url':
                          'https://accounts.google.com/o/oauth2/v2/auth?state=nonce',
                    }
                  : {'status': 'complete'},
            ),
            200,
          );
        }),
      );
      await pc.connect();
      expect(calls, contains('openYoutubeBrowser'));
      expect(requests, ['/api/login', '/api/login/one-flow']);
      expect(pc.pending, false);
    },
  );
  test(
    'PC mode confirms actual channel and disables automatic upload on changed identity',
    () async {
      const channelId = 'UCaaaaaaaaaaaaaaaaaaaaaa';
      var identity = 'pc:client:$channelId';
      final saved = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(Native.channel, (call) async {
            if (call.method == 'youtubePcKey') return 'test-pairing';
            if (call.method == 'youtubeSettings')
              return jsonEncode(
                YouTubePreferences(
                  authMode: 'pc',
                  email: identity,
                  channelId: channelId,
                  madeForKids: false,
                  automatic: true,
                ).toJson(),
              );
            if (call.method == 'saveYoutubeSettings')
              saved.add(jsonDecode((call.arguments as Map)['json'] as String));
            return null;
          });
      final pc = YouTubePc(
        clientFactory: () => MockClient(
          (request) async => http.Response(
            jsonEncode({'access_token': 'short', 'identity': identity}),
            200,
          ),
        ),
      );
      final service = YouTube.forTesting(
        pcAuth: pc,
        clientFactory: () => MockClient((request) async {
          expect(request.headers['Authorization'], 'Bearer short');
          expect(request.url.queryParameters['mine'], 'true');
          return http.Response(
            jsonEncode({
              'items': [
                {
                  'id': channelId,
                  'snippet': {'title': 'Brand'},
                },
              ],
            }),
            200,
          );
        }),
      );
      // No Google SDK platform implementation is needed for browser mode.
      await service.initialize();
      expect(service.user, isNull);
      await service.confirmChannel();
      expect(service.preferences.email, identity);
      expect(service.preferences.channelTitle, 'Brand');
      identity = 'pc:other-client:$channelId';
      await service.refreshChannel();
      expect(service.automatic, false);
      expect(service.preferences.channelId, isEmpty);
      expect(saved.last['automatic'], false);
      service.dispose();
    },
  );
  test(
    'browser mode survives persistence and still binds channel and identity',
    () {
      final p = YouTubePreferences(
        email: 'pc:client:channel',
        channelId: 'UC${'a' * 22}',
        madeForKids: false,
        authMode: 'pc',
        automatic: true,
      );
      final restored = YouTubePreferences.fromJson(p.toJson());
      expect(restored.authMode, 'pc');
      expect(restored.confirmed, true);
      restored.requireTarget(p.email, YouTubeChannel(p.channelId, 'Brand'));
      expect(
        () => restored.requireTarget(
          'pc:other:channel',
          YouTubeChannel(p.channelId, 'Brand'),
        ),
        throwsA(isA<YouTubeFailure>()),
      );
      expect(
        () => restored.requireTarget(
          p.email,
          YouTubeChannel('UC${'b' * 22}', 'Other'),
        ),
        throwsA(isA<YouTubeFailure>()),
      );
    },
  );
}
