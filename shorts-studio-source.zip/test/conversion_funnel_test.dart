import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/conversion_funnel.dart';

void main(){
 test('deduplicates queued IDs and counts the last completed stage',(){
  final funnel=ConversionFunnel.fromResults([
   {'url':'https://www.tiktok.com/@a/video/1','savedUri':'content://saved/1'},
   {'url':'https://www.tiktok.com/@b/video/2','downloaded':true,'lengthPassed':true},
   {'url':'https://www.tiktok.com/@c/video/3','textClear':true},
  ],['https://www.tiktok.com/@a/video/1','https://www.tiktok.com/@d/video/4']);
  expect(funnel.counts,[4,3,3,2,1,1]);
  expect(funnel.overall,'25.0%');expect(funnel.stepRate(4),'50.0%');
 });
 test('empty reports have no invented conversion rate',(){
  final funnel=ConversionFunnel.fromResults([],[]);
  expect(funnel.counts,[0,0,0,0,0,0]);expect(funnel.overall,'—');
 });
}
