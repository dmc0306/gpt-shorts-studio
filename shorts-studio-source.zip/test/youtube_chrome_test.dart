import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/bridge.dart';
import 'package:shorts_studio/youtube.dart';
import 'package:shorts_studio/youtube_chrome.dart';
import 'package:shorts_studio/youtube_channel.dart';
import 'package:shorts_studio/youtube_upload.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final calls = <String>[];
  Map<String, dynamic> prefs = {};
  var actualId = 'UC${'a' * 22}';
  PlatformException? failure;
  bool? customTabRequested;
  Map<String, dynamic> meta = {};
  setUp(() {
    calls.clear(); prefs = {}; actualId = 'UC${'a' * 22}'; failure = null; customTabRequested = null;
    meta = {'hasGrant': true, 'hasRefreshToken': true, 'expiresAt': 4000000000000};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, (call) async {
      calls.add(call.method);
      if (call.method == 'youtubeSettings') return jsonEncode(prefs);
      if (call.method == 'saveYoutubeSettings') { prefs = jsonDecode(call.arguments['json'] as String) as Map<String, dynamic>; return null; }
      if (call.method == 'youtubeChromeDisconnect') return {'revoked': true};
      if (call.method == 'youtubeChromeConnect') {
        customTabRequested = call.arguments['customTab'] == true;
        if (failure != null) throw failure!;
      }
      if (call.method == 'youtubeChromeToken') {
        calls.add(call.arguments['forceRefresh'] == true ? 'forceRefresh' : 'cachedOrRefresh');
        return {...meta, 'accessToken': 'private-access-token'};
      }
      if (call.method.startsWith('youtubeChrome')) return meta;
      throw StateError('Unexpected operation ${call.method}');
    });
  });
  tearDown(() => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(Native.channel, null));
  YouTube youtube() => YouTube.forTesting(clientFactory: () => MockClient((request) async {
    expect(request.method, 'GET');
    expect(request.url.path, '/youtube/v3/channels');
    expect(request.url.queryParameters['mine'], 'true');
    expect(request.headers['Authorization'], 'Bearer private-access-token');
    return http.Response(jsonEncode({'items': [{'id': actualId, 'snippet': {'title': 'Brand Channel'}}], 'pageInfo': {'totalResults': 1}}), 200);
  }));

  test('Chrome connection queries actual channel without PC or Google Sign-In then requires confirmation', () async {
    final yt = youtube();
    await yt.connectChrome();
    expect(yt.chromeMode, true);
    expect(yt.channel?.id, actualId);
    expect(yt.preferences.automatic, false);
    expect(yt.preferences.confirmed, false);
    yt.preferences.madeForKids = false;
    await yt.confirmChannel();
    expect(yt.preferences.confirmed, true);
    expect(yt.preferences.email, 'chrome:${YouTubeChrome.clientId}:$actualId');
    await yt.setAutomatic(true);
    expect(yt.automatic, true);
    expect(calls.any((s) => s.contains('Pc') || s.contains('Server')), false);
    expect(jsonEncode(prefs), isNot(contains('private-access-token')));
  });

  test('Chrome Custom Tab fallback uses the same Android OAuth bridge', () async {
    final yt = youtube();
    await yt.connectChrome(customTab: true);
    expect(customTabRequested, true);
    expect(yt.chromeMode, true);
    expect(yt.channel?.id, actualId);
    expect(yt.preferences.automatic, false);
  });

  test('Chrome mode survives persistence and refresh revalidates changed target', () async {
    final yt = youtube();
    await yt.connectChrome(); yt.preferences.madeForKids = false;
    await yt.confirmChannel(); await yt.setAutomatic(true);
    final restored = youtube();
    await restored.initialize();
    expect(restored.chromeMode, true);
    expect(restored.connected, true);
    await restored.verifyChromeRefresh();
    expect(calls, contains('forceRefresh'));
    expect(restored.automatic, true);
    actualId = 'UC${'b' * 22}';
    await restored.verifyChromeRefresh();
    expect(restored.automatic, false);
    expect(restored.preferences.confirmed, false);
    expect(restored.preferences.channelId, '');
  });

  test('missing refresh grant cannot enable automatic upload', () async {
    meta['hasRefreshToken'] = false;
    final yt = youtube(); await yt.connectChrome();
    yt.preferences.madeForKids = false; await yt.confirmChannel();
    await expectLater(yt.setAutomatic(true), throwsA(isA<YouTubeFailure>()));
    expect(yt.automatic, false);
  });

  test('Chrome errors are redacted and connection failure clears automatic target', () async {
    prefs = {'authMode': 'google', 'email': 'old', 'channelId': actualId, 'channelTitle': 'old', 'madeForKids': false, 'automatic': true};
    failure = PlatformException(code: 'AUTH_CHROME_TOKEN', message: 'private-access-token', details: {'oauthError': 'invalid_client', 'secret': 'private-access-token'});
    final yt = youtube();
    await expectLater(yt.connectChrome(), throwsA(isA<YouTubeFailure>().having((e) => e.message, 'message', allOf(contains('클라이언트'), isNot(contains('private-access-token'))))));
    expect(yt.automatic, false);
    expect(yt.preferences.channelId, '');
    expect(prefs['automatic'], false);
  });

  test('No-result diagnostics remain redacted', () async {
    failure = PlatformException(code: 'AUTH_CHROME_NO_RESULT', details: {
      'returnedIntent': false, 'secret': 'private-access-token'
    });
    await expectLater(youtube().connectChrome(), throwsA(
      isA<YouTubeFailure>().having((e) => e.message, 'message',
        allOf(contains('응답 Intent 없음'), isNot(contains('private-access-token'))))
    ));
  });

  test('Redirect failure is distinguished without exposing credentials', () async {
    failure = PlatformException(code: 'AUTH_CHROME_REDIRECT_MISSING',
      details: {'oauthType':0, 'oauthCode':1, 'secret':'private-access-token'});
    await expectLater(youtube().connectChrome(), throwsA(isA<YouTubeFailure>()
      .having((e) => e.message, 'message',
        allOf(contains('복귀 URI'), isNot(contains('private-access-token'))))));
  });

  test('Direct redirect validation error stays redacted', () async {
    failure = PlatformException(code: 'AUTH_CHROME_STATE',
      details: {'code': 'private-authorization-code', 'state': 'private-state'});
    await expectLater(youtube().connectChrome(), throwsA(isA<YouTubeFailure>()
      .having((e) => e.message, 'message',
        allOf(contains('AUTH_CHROME_STATE'), isNot(contains('private-authorization-code')),
              isNot(contains('private-state'))))));
  });

  test('Chrome disconnect uses local Chrome grant and resets confirmation', () async {
    final yt = youtube(); await yt.connectChrome();
    await yt.disconnect();
    expect(calls, contains('youtubeChromeDisconnect'));
    expect(yt.connected, false);
    expect(yt.preferences.confirmed, false);
    expect(YouTubePreferences.fromJson({'authMode': 'chrome'}).authMode, 'chrome');
  });
}
