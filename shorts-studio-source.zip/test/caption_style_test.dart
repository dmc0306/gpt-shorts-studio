import 'package:flutter_test/flutter_test.dart';
import 'package:shorts_studio/caption_text.dart';
import 'package:shorts_studio/caption_pacing.dart';
import 'package:shorts_studio/model.dart';

void main(){
 TestWidgetsFlutterBinding.ensureInitialized();
 test('whole Korean words stay together in explicit lines',(){
  const text='장소를 바꾼 다시 거울 앞에 등장';
  final layout=layoutCaptionText(text,300);
  final rendered=layout.painter.text!.toPlainText();
  expect(rendered, isNot(contains('거\n울')));
  for(final word in rendered.replaceAll('…','').split(RegExp(r'\s+')).where((w)=>w.isNotEmpty)){
   expect(text.split(' '),contains(word));
  }
  expect(layout.painter.width,lessThanOrEqualTo(300));
  layout.painter.dispose();
 });
 test('dense AI captions keep blank gaps and limited exposure',(){
  final cues=[for(var i=0;i<12;i++)TimedCaption(start:i*1.2,end:i*1.2+1,text:'반응 $i')];
  final result=sparseCaptions(cues,15);
  expect(result.length,lessThanOrEqualTo(3));expect(result,isNotEmpty);
  expect(result.fold<double>(0,(v,c)=>v+c.end-c.start),lessThanOrEqualTo(6));
  for(var i=1;i<result.length;i++){expect(result[i].start-result[i-1].end,greaterThanOrEqualTo(1.5));}
 });
}
