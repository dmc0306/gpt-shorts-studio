import 'overlay_renderer.dart';
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:video_player/video_player.dart';
import 'bridge.dart';
import 'ai.dart';
import 'ai_settings.dart';
import 'input_dialog.dart';
import 'model.dart';
import 'theme.dart';
class EditorScreen extends StatefulWidget{
 const EditorScreen({super.key,required this.clip,required this.onSave});
 final Clip clip; final Future<void> Function() onSave;
 @override State<EditorScreen> createState()=>_EditorState();
}
class _EditorState extends State<EditorScreen>{
 late final VideoPlayerController player;late final TextEditingController headline,caption;
 final overlayKey=GlobalKey();bool ready=false,exporting=false;String? error;double? progress;Timer? timer;bool generating=false;String aiStatus="";String? exportCaption;GeminiCaptions? ai;
 Clip get c=>widget.clip;
 @override void initState(){super.initState();if(c.headline.isEmpty)c.headline=c.name.replaceAll(RegExp(r'\.[a-zA-Z0-9]+$'),'');headline=TextEditingController(text:c.headline);caption=TextEditingController(text:c.caption);player=VideoPlayerController.file(File(c.path));initialize();}
 Future<void> initialize()async{try{await player.initialize();c.duration=player.value.duration.inMilliseconds/1000;c.end=c.end.clamp(.1,c.duration).toDouble();c.start=c.start.clamp(0,c.end-.1).toDouble();await player.setVolume(c.mute?0:1);await player.seekTo(Duration(milliseconds:(c.start*1000).round()));player.addListener(tick);if(mounted)setState(()=>ready=true);}catch(e){if(mounted)setState(()=>error='이 영상을 열 수 없어요. 다른 MP4 파일을 사용해 주세요.');}}
 void tick(){if(!mounted||!ready)return;if(player.value.isPlaying&&player.value.position.inMilliseconds>=c.end*1000){player.pause();player.seekTo(Duration(milliseconds:(c.start*1000).round()));}setState((){});}
 @override void dispose(){timer?.cancel();ai?.cancel();player.removeListener(tick);player.dispose();headline.dispose();caption.dispose();super.dispose();}
 Future<void> persist()async{c.headline=headline.text.trim();c.caption=caption.text.trim();await widget.onSave();}
 void toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 String get visibleCaption {
  if(exportCaption!=null)return exportCaption!;
  if(c.timedCaptions.isEmpty)return caption.text;
  final time=player.value.position.inMilliseconds/1000;
  for(final entry in c.timedCaptions){if(time>=entry.start&&time<entry.end)return entry.text;}
  return '';
 }
 Future<bool> aiSettings()=>showAiSettings(context);
 Future<void> generateAi()async{
  if(generating||exporting||!ready)return;
  try{
   var settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
   if((settings['key'] as String? ?? '').isEmpty){if(!await aiSettings())return;settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};}
   final key=settings['key'] as String? ?? '';if(key.isEmpty)return;
   await player.pause();if(!mounted)return;
   setState((){generating=true;aiStatus='생성 준비 중';});
   final service=GeminiCaptions();ai=service;
   final draft=await service.generate(clip:c,key:key,model:settings['model'] as String? ?? GeminiCaptions.defaultModel,onStatus:(s){if(mounted)setState(()=>aiStatus=s);});
   if(!mounted)return;
   final apply=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('AI 생성 결과'),content:SizedBox(width:double.maxFinite,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(draft.headline,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:16),for(final t in draft.captions)Padding(padding:const EdgeInsets.only(bottom:12),child:Text('${t.start.toStringAsFixed(1)}–${t.end.toStringAsFixed(1)}초  ${t.text}')),const Text('적용하면 기존 제목과 자막을 교체해요. 문구와 시간은 적용 후 수정할 수 있어요.',style:TextStyle(color:muted,fontSize:12))]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('닫기')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('적용'))]));
   if(apply==true&&mounted){setState((){headline.text=draft.headline;caption.clear();c.timedCaptions=draft.captions;});await persist();}
  }catch(e){toast(e is AiFailure?e.message:'AI 설정을 불러오지 못했어요.');}
  finally{ai=null;if(mounted)setState(()=>generating=false);}
 }
 Future<void> editTimed([TimedCaption? original])async{
  if(original==null&&c.end-c.start<.2){toast('자막을 추가하려면 0.2초 이상 구간을 선택하세요.');return;}
  final text=TextEditingController(text:original?.text??'');
  final position=original?.start??(player.value.position.inMilliseconds/1000).clamp(c.start,c.end-.2).toDouble();
  final begin=TextEditingController(text:(original?.start??position).toStringAsFixed(2));
  final finish=TextEditingController(text:(original?.end??(position+2).clamp(position+.2,c.end)).toStringAsFixed(2));
  String? message;
  final entry=await showDialog<TimedCaption>(context:context,builder:(ctx)=>ManagedInputDialog(controllers:[text,begin,finish],builder:(ctx)=>StatefulBuilder(builder:(ctx,update)=>AlertDialog(title:const Text('시간별 자막 수정'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:text,maxLength:40,maxLines:2,decoration:const InputDecoration(labelText:'자막')),Row(children:[Expanded(child:TextField(controller:begin,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'시작(초)'))),const SizedBox(width:12),Expanded(child:TextField(controller:finish,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'종료(초)')))]),const Text('시간은 원본 영상 시작 기준이에요.',style:TextStyle(fontSize:12,color:muted)),if(message!=null)Text(message!,style:const TextStyle(color:Colors.red,fontSize:12))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('취소')),FilledButton(onPressed:(){
   final a=double.tryParse(begin.text),b=double.tryParse(finish.text);
   if(a==null||b==null||!a.isFinite||!b.isFinite||a<0||b>c.duration||b-a<.2||text.text.trim().isEmpty||text.text.split('\n').length>2){update(()=>message='0~${c.duration.toStringAsFixed(2)}초 범위에서 0.2초 이상, 두 줄 이하로 입력하세요.');return;}
   if(c.timedCaptions.any((t)=>t!=original&&a<t.end&&b>t.start)){update(()=>message='다른 자막과 시간이 겹쳐요.');return;}
   Navigator.pop(ctx,TimedCaption(start:a,end:b,text:text.text.trim()));
  },child:const Text('저장'))]))));
  if(entry!=null&&mounted){setState((){if(original!=null)c.timedCaptions.remove(original);c.timedCaptions.add(entry);c.timedCaptions.sort((a,b)=>a.start.compareTo(b.start));});await persist();}
 }
 Widget aiControls()=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Row(children:[Expanded(child:OutlinedButton.icon(onPressed:ready?generateAi:null,icon:const Icon(Icons.auto_awesome,size:18),label:const Text('AI 제목·자막 생성'))),IconButton(tooltip:'AI 설정',onPressed:aiSettings,icon:const Icon(Icons.key_rounded))]),
  const Text('원본 영상·소리를 Google로 전송해 장면별 자막을 만들어요. 무료 한도 적용.',style:TextStyle(fontSize:11,color:muted)),
  if(c.timedCaptions.isNotEmpty)...[const SizedBox(height:12),const Text('시간별 자막 · 눌러서 해당 장면 보기',style:TextStyle(fontSize:13)),for(final t in c.timedCaptions)ListTile(contentPadding:EdgeInsets.zero,title:Text(t.text,style:const TextStyle(fontSize:13)),subtitle:Text('${t.start.toStringAsFixed(2)}–${t.end.toStringAsFixed(2)}초',style:const TextStyle(fontSize:11)),onTap:()=>player.seekTo(Duration(milliseconds:(t.start*1000).round())),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(tooltip:'자막 수정',onPressed:()=>editTimed(t),icon:const Icon(Icons.edit_outlined,size:18)),IconButton(tooltip:'자막 삭제',onPressed:()async{setState(()=>c.timedCaptions.remove(t));await persist();},icon:const Icon(Icons.delete_outline,size:18))]))],
  if(c.timedCaptions.length<20)TextButton.icon(onPressed:ready?()=>editTimed():null,icon:const Icon(Icons.add,size:16),label:const Text('시간별 자막 추가')),
  const SizedBox(height:12)
 ]);
 Future<Uint8List> captureOverlay({bool subtitleOnly=false})async{
  await WidgetsBinding.instance.endOfFrame;
  final render=overlayKey.currentContext?.findRenderObject();
  if(render is! RenderRepaintBoundary)throw StateError('저장용 자막 레이어가 준비되지 않았어요.');
  final boundary=render;
  final source=await boundary.toImage(pixelRatio:1080/boundary.size.width);
  ui.Image image=source;
  if(subtitleOnly){final recorder=ui.PictureRecorder();final canvas=ui.Canvas(recorder);canvas.drawImage(source,const ui.Offset(0,-1200),ui.Paint());final picture=recorder.endRecording();image=await picture.toImage(1080,200);picture.dispose();source.dispose();}
  final bytes=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();
  if(bytes==null)throw StateError('자막 이미지를 만들 수 없어요.');
  return bytes.buffer.asUint8List();
 }
 Future<void> export()async{
  if(exporting||generating||!ready)return;FocusScope.of(context).unfocus();await player.pause();await persist();if(!mounted)return;setState((){exporting=true;progress=null;exportCaption=c.timedCaptions.isEmpty?caption.text:"";});
  try{
   final bytes=await captureOverlay();
   final timed=<Map<String,dynamic>>[];
   for(final t in c.timedCaptions){
    final a=t.start.clamp(c.start,c.end).toDouble(),b=t.end.clamp(c.start,c.end).toDouble();if(b<=a)continue;
    if(!mounted)return;setState(()=>exportCaption=t.text);
    timed.add({'startUs':((a-c.start)*1000000).round(),'endUs':((b-c.start)*1000000).round(),'png':await captureOverlay(subtitleOnly:true)});
   }
   if(mounted)setState(()=>exportCaption=null);
   timer=Timer.periodic(const Duration(milliseconds:500),(_)async{try{final p=await Native.call<num>('exportProgress');if(mounted&&exporting)setState(()=>progress=p==null||p<0?null:p.toDouble()/100);}catch(_){}});
   final uri=await Native.call<String>('export',{'path':c.path,'overlay':bytes,'timedOverlays':timed,'startMs':(c.start*1000).round(),'endMs':(c.end*1000).round(),'mute':c.mute,'crop':c.crop});
   if(uri!=null){c.savedUri=uri;c.savedAt=DateTime.now().toIso8601String();await widget.onSave();toast('갤러리의 Movies/ShortsStudio에 저장했어요.');}
  }catch(e){toast('저장하지 못했어요. $e');}finally{timer?.cancel();if(mounted)setState((){exporting=false;exportCaption=null;});}
 }
 @override Widget build(BuildContext context)=>Stack(children:[
  Positioned(top:0,left:0,width:270,height:480,child:IgnorePointer(child:RepaintBoundary(key:overlayKey,child:Material(type:MaterialType.transparency,child:ClipOverlay(headline:headline.text,caption:visibleCaption,style:c.style))))),
  PopScope(canPop:!exporting&&!generating,onPopInvokedWithResult:(didPop,result){if(didPop){persist().catchError((Object _){});}},child:Scaffold(appBar:AppBar(title:const Text('쇼츠 편집',style:TextStyle(fontSize:16)),actions:[Padding(padding:const EdgeInsets.only(right:24),child:Center(child:Text('${(c.end-c.start).toStringAsFixed(1)}s',style:const TextStyle(color:muted,fontSize:13))))]),body:SafeArea(child:AbsorbPointer(absorbing:exporting||generating,child:ListView(padding:const EdgeInsets.fromLTRB(24,0,24,24),children:[const Row(children:[Text('01  템플릿 적용',style:TextStyle(fontSize:11,color:blue)),Spacer(),Text('02  다듬기',style:TextStyle(fontSize:11,color:muted)),Spacer(),Text('03  저장',style:TextStyle(fontSize:11,color:muted))]),const SizedBox(height:20),Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:290),child:AspectRatio(aspectRatio:9/16,child:ClipRRect(borderRadius:BorderRadius.circular(24),child:LayoutBuilder(builder:(context,box)=>Stack(fit:StackFit.expand,children:[Container(color:Colors.black),if(ready)Positioned(top:box.maxWidth*420/1080,left:0,right:0,height:box.maxWidth,child:ClipRect(child:FittedBox(fit:c.crop?BoxFit.cover:BoxFit.contain,child:SizedBox(width:player.value.size.width,height:player.value.size.height,child:VideoPlayer(player))))),ClipOverlay(headline:headline.text,caption:visibleCaption,style:c.style),if(!ready)Center(child:error==null?const CircularProgressIndicator():Padding(padding:const EdgeInsets.all(24),child:Text(error!,style:const TextStyle(color:Colors.white))))])))))),if(ready)Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(tooltip:player.value.isPlaying?'일시 정지':'재생',onPressed:(){player.value.isPlaying?player.pause():player.play();},icon:Icon(player.value.isPlaying?Icons.pause_rounded:Icons.play_arrow_rounded)),Text('${(player.value.position.inMilliseconds/1000).toStringAsFixed(1)} / ${c.end.toStringAsFixed(1)}',style:const TextStyle(fontSize:12,color:muted)),IconButton(tooltip:'구간 처음으로',onPressed:()=>player.seekTo(Duration(milliseconds:(c.start*1000).round())),icon:const Icon(Icons.replay,size:18))]),const SizedBox(height:16),const Text('참고 영상 포맷 · 제목 색상',style:TextStyle(fontSize:18)),const SizedBox(height:12),Row(children:List.generate(3,(i)=>Expanded(child:Padding(padding:EdgeInsets.only(right:i==2?0:8),child:InkWell(onTap:()=>setState(()=>c.style=i),borderRadius:BorderRadius.circular(16),child:Container(height:68,decoration:BoxDecoration(color:i==1?ink:const Color(0xfff5f5f5),borderRadius:BorderRadius.circular(16),border:Border.all(color:c.style==i?blue:Colors.transparent,width:2)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(['Aa','Aa.','Aa↗'][i],style:TextStyle(fontSize:20,fontWeight:i==1?FontWeight.w800:FontWeight.w400,color:i==1?Colors.white:ink)),Text(['흰색·노랑','흰색','노랑'][i],style:TextStyle(fontSize:10,color:i==1?Colors.white70:muted))]))))))),const SizedBox(height:24),TextField(controller:headline,maxLength:48,maxLines:2,onChanged:(_)=>setState((){}),decoration:const InputDecoration(labelText:'상단 제목',hintText:'첫 줄은 흰색\n둘째 줄은 노란색')),const SizedBox(height:8),aiControls(),if(c.timedCaptions.isEmpty)TextField(controller:caption,maxLength:70,maxLines:2,onChanged:(_)=>setState((){}),decoration:const InputDecoration(labelText:'고정 자막 (선택)' ,hintText:'필요한 말만 짧게')),const Text('제목은 Enter로 두 줄을 나눠 주세요. Gmarket Sans Bold · 중앙 정사각 영상 · 검정 여백',style:TextStyle(fontSize:11,color:muted)),const SizedBox(height:24),Row(children:[const Text('사용할 구간',style:TextStyle(fontSize:16)),const Spacer(),Text('${c.start.toStringAsFixed(1)}s — ${c.end.toStringAsFixed(1)}s',style:const TextStyle(color:muted,fontSize:12))]),if(ready)RangeSlider(min:0,max:c.duration,values:RangeValues(c.start,c.end),onChanged:(v){if(v.end-v.start<.1)return;setState((){c.start=v.start;c.end=v.end;});},onChangeEnd:(v)=>player.seekTo(Duration(milliseconds:(v.start*1000).round()))),SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,title:const Text('정사각 영상 영역 채우기',style:TextStyle(fontSize:14)),subtitle:const Text('켜면 중앙 기준으로 자르고, 끄면 원본 전체를 보여줘요.',style:TextStyle(fontSize:11)),value:c.crop,onChanged:(v)=>setState(()=>c.crop=v)),SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,title:const Text('원본 소리 끄기',style:TextStyle(fontSize:14)),value:c.mute,onChanged:(v){setState(()=>c.mute=v);player.setVolume(v?0:1);}),const SizedBox(height:8),const Text('1080 × 1920 · MP4 · 영상 저장은 기기 내 처리',style:TextStyle(color:muted,fontSize:12))]))),bottomNavigationBar:SafeArea(child:Container(padding:const EdgeInsets.fromLTRB(24,12,24,16),decoration:const BoxDecoration(color:Colors.white,border:Border(top:BorderSide(color:line))),child:Column(mainAxisSize:MainAxisSize.min,children:[if(generating)...[const LinearProgressIndicator(),const SizedBox(height:8),Text(aiStatus,style:const TextStyle(fontSize:12,color:muted)),TextButton(onPressed:()=>ai?.cancel(),child:const Text("생성 취소"))],if(exporting)...[LinearProgressIndicator(value:progress),const SizedBox(height:8),const Text('저장 중에는 앱을 켜두세요.',style:TextStyle(fontSize:12,color:muted)),TextButton(onPressed:()=>Native.call('cancelExport'),child:const Text('취소'))],SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:exporting||generating||!ready?null:export,icon:const Icon(Icons.south_rounded,size:20),label:Text(exporting?'영상 저장 중${progress==null?'':' ${(progress!*100).round()}%'}':'MP4로 저장')))])))))]);
}
// Coordinates are in the reference video's 1080 × 1920 output space.
class ClipOverlay extends StatelessWidget{
 const ClipOverlay({super.key,required this.headline,required this.caption,required this.style});
 final String headline,caption;final int style;
 @override Widget build(BuildContext context)=>CustomPaint(painter:ShortsOverlayPainter(headline:headline,caption:caption,style:style),child:const SizedBox.expand());
}
