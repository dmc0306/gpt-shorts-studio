import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:video_player/video_player.dart';
import 'bridge.dart';
import 'model.dart';
import 'theme.dart';
class EditorScreen extends StatefulWidget{
 const EditorScreen({super.key,required this.clip,required this.onSave});
 final Clip clip; final Future<void> Function() onSave;
 @override State<EditorScreen> createState()=>_EditorState();
}
class _EditorState extends State<EditorScreen>{
 late final VideoPlayerController player;late final TextEditingController headline,caption;
 final overlayKey=GlobalKey();bool ready=false,exporting=false;String? error;double? progress;Timer? timer;
 Clip get c=>widget.clip;
 @override void initState(){super.initState();if(c.headline.isEmpty)c.headline=c.name.replaceAll(RegExp(r'\.[a-zA-Z0-9]+$'),'');headline=TextEditingController(text:c.headline);caption=TextEditingController(text:c.caption);player=VideoPlayerController.file(File(c.path));initialize();}
 Future<void> initialize()async{try{await player.initialize();c.duration=player.value.duration.inMilliseconds/1000;c.end=c.end.clamp(.1,c.duration).toDouble();c.start=c.start.clamp(0,c.end-.1).toDouble();await player.setVolume(c.mute?0:1);await player.seekTo(Duration(milliseconds:(c.start*1000).round()));player.addListener(tick);if(mounted)setState(()=>ready=true);}catch(e){if(mounted)setState(()=>error='이 영상을 열 수 없어요. 다른 MP4 파일을 사용해 주세요.');}}
 void tick(){if(!mounted||!ready)return;if(player.value.isPlaying&&player.value.position.inMilliseconds>=c.end*1000){player.pause();player.seekTo(Duration(milliseconds:(c.start*1000).round()));}setState((){});}
 @override void dispose(){timer?.cancel();player.removeListener(tick);player.dispose();headline.dispose();caption.dispose();super.dispose();}
 Future<void> persist()async{c.headline=headline.text.trim();c.caption=caption.text.trim();await widget.onSave();}
 void toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 Future<void> export()async{
  if(exporting||!ready)return;FocusScope.of(context).unfocus();await player.pause();await persist();if(!mounted)return;setState((){exporting=true;progress=null;});
  try{
   await WidgetsBinding.instance.endOfFrame;
   final boundary=overlayKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
   final image=await boundary.toImage(pixelRatio:1080/boundary.size.width);
   final bytes=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();
   if(bytes==null)throw StateError('자막 이미지를 만들 수 없어요.');
   timer=Timer.periodic(const Duration(milliseconds:500),(_)async{try{final p=await Native.call<num>('exportProgress');if(mounted&&exporting)setState(()=>progress=p==null||p<0?null:p.toDouble()/100);}catch(_){}});
   final uri=await Native.call<String>('export',{'path':c.path,'overlay':bytes.buffer.asUint8List(),'startMs':(c.start*1000).round(),'endMs':(c.end*1000).round(),'mute':c.mute,'crop':c.crop});
   if(uri!=null){c.savedUri=uri;c.savedAt=DateTime.now().toIso8601String();await widget.onSave();toast('갤러리의 Movies/ShortsStudio에 저장했어요.');}
  }catch(e){toast('저장하지 못했어요. $e');}finally{timer?.cancel();if(mounted)setState(()=>exporting=false);}
 }
 @override Widget build(BuildContext context)=>PopScope(canPop:!exporting,onPopInvokedWithResult:(didPop,result){if(didPop){persist().catchError((Object _){});}},child:Scaffold(appBar:AppBar(title:const Text('쇼츠 편집',style:TextStyle(fontSize:16)),actions:[Padding(padding:const EdgeInsets.only(right:24),child:Center(child:Text('${(c.end-c.start).toStringAsFixed(1)}s',style:const TextStyle(color:muted,fontSize:13))))]),body:SafeArea(child:AbsorbPointer(absorbing:exporting,child:ListView(padding:const EdgeInsets.fromLTRB(24,0,24,24),children:[const Row(children:[Text('01  템플릿 적용',style:TextStyle(fontSize:11,color:blue)),Spacer(),Text('02  다듬기',style:TextStyle(fontSize:11,color:muted)),Spacer(),Text('03  저장',style:TextStyle(fontSize:11,color:muted))]),const SizedBox(height:20),Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:290),child:AspectRatio(aspectRatio:9/16,child:ClipRRect(borderRadius:BorderRadius.circular(24),child:LayoutBuilder(builder:(context,box)=>Stack(fit:StackFit.expand,children:[Container(color:Colors.black),if(ready)Positioned(top:box.maxWidth*420/1080,left:0,right:0,height:box.maxWidth,child:ClipRect(child:FittedBox(fit:c.crop?BoxFit.cover:BoxFit.contain,child:SizedBox(width:player.value.size.width,height:player.value.size.height,child:VideoPlayer(player))))),RepaintBoundary(key:overlayKey,child:ClipOverlay(headline:headline.text,caption:caption.text,style:c.style)),if(!ready)Center(child:error==null?const CircularProgressIndicator():Padding(padding:const EdgeInsets.all(24),child:Text(error!,style:const TextStyle(color:Colors.white))))])))))),if(ready)Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(tooltip:player.value.isPlaying?'일시 정지':'재생',onPressed:(){player.value.isPlaying?player.pause():player.play();},icon:Icon(player.value.isPlaying?Icons.pause_rounded:Icons.play_arrow_rounded)),Text('${(player.value.position.inMilliseconds/1000).toStringAsFixed(1)} / ${c.end.toStringAsFixed(1)}',style:const TextStyle(fontSize:12,color:muted)),IconButton(tooltip:'구간 처음으로',onPressed:()=>player.seekTo(Duration(milliseconds:(c.start*1000).round())),icon:const Icon(Icons.replay,size:18))]),const SizedBox(height:16),const Text('참고 영상 포맷 · 제목 색상',style:TextStyle(fontSize:18)),const SizedBox(height:12),Row(children:List.generate(3,(i)=>Expanded(child:Padding(padding:EdgeInsets.only(right:i==2?0:8),child:InkWell(onTap:()=>setState(()=>c.style=i),borderRadius:BorderRadius.circular(16),child:Container(height:68,decoration:BoxDecoration(color:i==1?ink:const Color(0xfff5f5f5),borderRadius:BorderRadius.circular(16),border:Border.all(color:c.style==i?blue:Colors.transparent,width:2)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(['Aa','Aa.','Aa↗'][i],style:TextStyle(fontSize:20,fontWeight:i==1?FontWeight.w800:FontWeight.w400,color:i==1?Colors.white:ink)),Text(['흰색·노랑','흰색','노랑'][i],style:TextStyle(fontSize:10,color:i==1?Colors.white70:muted))]))))))),const SizedBox(height:24),TextField(controller:headline,maxLength:48,maxLines:2,onChanged:(_)=>setState((){}),decoration:const InputDecoration(labelText:'상단 제목',hintText:'첫 줄은 흰색\n둘째 줄은 노란색')),const SizedBox(height:8),TextField(controller:caption,maxLength:70,maxLines:2,onChanged:(_)=>setState((){}),decoration:const InputDecoration(labelText:'상황 자막',hintText:'필요한 말만 짧게')),const Text('제목은 Enter로 두 줄을 나눠 주세요. Gmarket Sans Bold · 중앙 정사각 영상 · 검정 여백',style:TextStyle(fontSize:11,color:muted)),const SizedBox(height:24),Row(children:[const Text('사용할 구간',style:TextStyle(fontSize:16)),const Spacer(),Text('${c.start.toStringAsFixed(1)}s — ${c.end.toStringAsFixed(1)}s',style:const TextStyle(color:muted,fontSize:12))]),if(ready)RangeSlider(min:0,max:c.duration,values:RangeValues(c.start,c.end),onChanged:(v){if(v.end-v.start<.1)return;setState((){c.start=v.start;c.end=v.end;});},onChangeEnd:(v)=>player.seekTo(Duration(milliseconds:(v.start*1000).round()))),SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,title:const Text('정사각 영상 영역 채우기',style:TextStyle(fontSize:14)),subtitle:const Text('켜면 중앙 기준으로 자르고, 끄면 원본 전체를 보여줘요.',style:TextStyle(fontSize:11)),value:c.crop,onChanged:(v)=>setState(()=>c.crop=v)),SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,title:const Text('원본 소리 끄기',style:TextStyle(fontSize:14)),value:c.mute,onChanged:(v){setState(()=>c.mute=v);player.setVolume(v?0:1);}),const SizedBox(height:8),const Text('1080 × 1920 · MP4 · 기기 내에서 처리',style:TextStyle(color:muted,fontSize:12))]))),bottomNavigationBar:SafeArea(child:Container(padding:const EdgeInsets.fromLTRB(24,12,24,16),decoration:const BoxDecoration(color:Colors.white,border:Border(top:BorderSide(color:line))),child:Column(mainAxisSize:MainAxisSize.min,children:[if(exporting)...[LinearProgressIndicator(value:progress),const SizedBox(height:8),const Text('저장 중에는 앱을 켜두세요.',style:TextStyle(fontSize:12,color:muted)),TextButton(onPressed:()=>Native.call('cancelExport'),child:const Text('취소'))],SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:exporting||!ready?null:export,icon:const Icon(Icons.south_rounded,size:20),label:Text(exporting?'영상 저장 중${progress==null?'':' ${(progress!*100).round()}%'}':'MP4로 저장')))])))));
}
// Coordinates are in the reference video's 1080 × 1920 output space.
class ClipOverlay extends StatelessWidget{
 const ClipOverlay({super.key,required this.headline,required this.caption,required this.style});
 final String headline,caption;final int style;
 @override Widget build(BuildContext context)=>LayoutBuilder(builder:(context,box){
  final scale=box.maxWidth/1080;
  final lines=headline.trim().split('\n');
  final titleLines=lines.length>1?[lines.first,lines.skip(1).join(' ')]:lines;
  return Stack(fit:StackFit.expand,children:[
   Positioned(top:0,left:0,right:0,height:420*scale,child:const ColoredBox(color:Colors.black)),
   Positioned(bottom:0,left:0,right:0,height:420*scale,child:const ColoredBox(color:Colors.black)),
   if(headline.trim().isNotEmpty)Positioned(top:164*scale,left:60*scale,right:60*scale,height:232*scale,
    child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
     for(var i=0;i<titleLines.length;i++)SizedBox(height:116*scale,width:double.infinity,
      child:FittedBox(fit:BoxFit.scaleDown,child:Text(titleLines[i],textScaler:TextScaler.noScaling,
       style:TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:112*scale,height:1.0,
        color:style==1?Colors.white:style==2?const Color(0xffffdf00):i==0?Colors.white:const Color(0xffffdf00)))))
    ])),
   if(caption.trim().isNotEmpty)Positioned(top:1200*scale,left:48*scale,right:48*scale,
    child:Center(child:Container(padding:EdgeInsets.symmetric(horizontal:12*scale,vertical:8*scale),color:Colors.black,
     child:Text(caption,textScaler:TextScaler.noScaling,textAlign:TextAlign.center,maxLines:2,overflow:TextOverflow.ellipsis,
      style:TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:44*scale,height:1.15,color:Colors.white)))))
  ]);
 });
}
