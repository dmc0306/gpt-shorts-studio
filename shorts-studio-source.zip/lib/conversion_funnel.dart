import 'discovery.dart';
class ConversionFunnel {
 const ConversionFunnel(this.counts);
 final List<int> counts;
 static const labels=['후보','다운로드','길이 통과','원본 검사 통과','AI 적합','MP4 저장'];
 String get overall=>percent(counts.last,counts.first);
 String stepRate(int index)=>percent(counts[index],counts[index-1]);
 static String percent(int value,int total)=>total==0?'—':'${(100*value/total).toStringAsFixed(1)}%';
 factory ConversionFunnel.fromResults(List<Map<String,dynamic>> reports,Iterable<String> queue){
  final items=<String,Map<String,dynamic>>{};
  for(final item in reports){final id=MixedDiscovery.videoId(item['url'] as String? ?? '');if(id!=null)items[id]=item;}
  final ids={...items.keys,...queue.map(MixedDiscovery.videoId).whereType<String>()};
  final counts=[ids.length,0,0,0,0,0];
  for(final item in items.values){
   final saved=(item['savedUri'] as String? ?? '').isNotEmpty;
   final ai=item['aiPassed']==true||saved;
   final original=item['textClear']==true||ai;
   final length=item['lengthPassed']==true||original;
   final downloaded=item['downloaded']==true||length;
   for(final entry in [downloaded,length,original,ai,saved].indexed){if(entry.$2)counts[entry.$1+1]++;}
  }
  return ConversionFunnel(counts);
 }
}
