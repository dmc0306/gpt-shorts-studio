import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'youtube_publish_plan.dart';

/// Persistent resumable upload. A saved session is checked before sending bytes.
class YouTubeUpload {
  YouTubeUpload({
    required this.client,
    required this.readState,
    required this.writeState,
    required this.token,
  });
  final http.Client client;
  final Future<Map<String, dynamic>> Function() readState;
  final Future<void> Function(Map<String, dynamic>) writeState;
  final Future<String> Function() token;
  static final endpoint = Uri.https(
    'www.googleapis.com',
    '/upload/youtube/v3/videos',
    {'uploadType': 'resumable', 'part': 'snippet,status'},
  );

  Future<http.Response> send(
    String method,
    Uri uri, {
    Map<String, String>? headers,
    List<int>? body,
  }) async {
    final request = http.Request(method, uri)..followRedirects = false;
    request.headers.addAll({
      'Authorization': 'Bearer ${await token()}',
      ...?headers,
    });
    if (body != null) request.bodyBytes = body;
    return http.Response.fromStream(
      await client.send(request).timeout(const Duration(minutes: 2)),
    ).timeout(const Duration(minutes: 2));
  }

  static void check(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) return;
    String reason = '';
    try {
      reason =
          jsonDecode(response.body)['error']['errors'][0]['reason'] as String;
    } catch (_) {
      /* Never expose raw responses or session URLs to the UI. */
    }
    if (response.statusCode == 401) {
      throw const YouTubeFailure('권한이 만료됐어요. 계정을 다시 연결한 후 이어 올려 주세요.');
    }
    throw YouTubeFailure(switch (reason) {
      'quotaExceeded' ||
      'dailyLimitExceeded' => '오늘 API 사용량을 초과했어요. 나중에 이어 올려 주세요.',
      'uploadLimitExceeded' => '채널의 업로드 한도에 도달했어요. 나중에 다시 시도해 주세요.',
      'youtubeSignupRequired' => '이 구글 계정에 유튜브 채널을 먼저 만들어 주세요.',
      'accessNotConfigured' =>
        '같은 Google Cloud 프로젝트에서 YouTube Data API v3를 켜 주세요.',
      'forbidden' ||
      'insufficientPermissions' => '유튜브 업로드 권한을 허용하고 계정을 다시 연결해 주세요.',
      _ => '유튜브 전송에 실패했어요 (HTTP ${response.statusCode}). 잠시 후 이어 올려 주세요.',
    });
  }

  static int offset(http.Response response, int size) {
    final range = response.headers['range'];
    if (range == null) return 0;
    final match = RegExp(r'^bytes=0-(\d+)$').firstMatch(range);
    if (match == null) {
      throw const YouTubeFailure('전송 위치를 확인하지 못했어요. 다시 이어 올려 주세요.');
    }
    final next = int.parse(match[1]!) + 1;
    if (next > size) throw const YouTubeFailure('전송 크기가 일치하지 않아요.');
    return next;
  }

  Future<String> upload({
    required File file,
    required String email,
    required String channelId,
    required String title,
    required String description,
    required bool madeForKids,
    required bool syntheticMedia,
    YouTubePublishPlan publishPlan=const YouTubePublishPlan.private(),
    required void Function(double) onProgress,
  }) async {
    final state = await readState();
    if (state['videoId'] is String) return state['videoId'] as String;
    if (state.isNotEmpty &&
        (state['email'] != email || state['channelId'] != channelId)) {
      throw const YouTubeFailure('이 영상의 전송을 시작했던 구글 계정·채널로 연결해 주세요.');
    }
    final size = await file.length();
    if (size == 0) throw const YouTubeFailure('저장된 영상이 비어 있어요. 다시 저장해 주세요.');
    Uri session;
    int position = 0;
    Future<String> completed(http.Response response) async {
      check(response);
      final id = (jsonDecode(response.body) as Map<String, dynamic>)['id'];
      if (id is! String || !RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(id)) {
        throw const YouTubeFailure('전송 결과를 확인하지 못했어요. 이어 올리기를 눌러 확인해 주세요.');
      }
      // Save the id before notifying; do not reupload on uncertain retries.
      final status=jsonDecode(response.body) as Map;
      final actual=status['status'] is Map?
          (status['status'] as Map)['privacyStatus'] as String?:null;
      await writeState({...state,'videoId':id,
        'actualPrivacy':actual??'unknown'});
      onProgress(1);
      return id;
    }

    if (state['session'] is String) {
      if (state['size'] != size) {
        throw const YouTubeFailure('저장된 영상이 변경됐어요. 새 MP4로 저장해 주세요.');
      }
      session = Uri.parse(state['session'] as String);
      validateSession(session);
      final response = await send(
        'PUT',
        session,
        headers: {'Content-Range': 'bytes */$size'},
        body: [],
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        return completed(response);
      }
      if (response.statusCode == 404 || response.statusCode == 410) {
        throw const YouTubeFailure(
          '이어 올리기 기한이 지났어요. YouTube Studio에서 업로드 여부를 확인해 주세요. 중복 방지를 위해 자동 재전송하지 않아요.',
        );
      }
      if (response.statusCode != 308) check(response);
      position = offset(response, size);
    } else {
      if(publishPlan.publishAt!=null&&
         !publishPlan.publishAt!.isAfter(DateTime.now().toUtc().add(const Duration(minutes:10)))){
        throw const YouTubeFailure('예약 시각이 너무 가까워요. 다음 게시 시간으로 다시 예약해 주세요.');
      }
      if (title.trim().isEmpty ||
          title.runes.length > 100 ||
          title.contains(RegExp('[<>]'))) {
        throw const YouTubeFailure('제목은 꺾쇠 없이 1~100자로 입력해 주세요.');
      }
      final response = await send(
        'POST',
        endpoint,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'X-Upload-Content-Length': '$size',
          'X-Upload-Content-Type': 'video/mp4',
        },
        body: utf8.encode(
          jsonEncode({
            'snippet': {
              'title': title.trim(),
              'description': description,
              'categoryId': '22',
            },
            'status':publishPlan.status(
              madeForKids:madeForKids,syntheticMedia:syntheticMedia),

          }),
        ),
      );
      check(response);
      final location = response.headers['location'];
      if (location == null) {
        throw const YouTubeFailure('업로드 연결을 만들지 못했어요. 다시 시도해 주세요.');
      }
      session = Uri.parse(location);
      validateSession(session);
      state.addAll({
        'publishMode':publishPlan.mode,
        'requestedPrivacy':publishPlan.privacyStatus,
        if(publishPlan.publishAt!=null)
          'publishAt':publishPlan.publishAt!.toUtc().toIso8601String(),
        'channelId': channelId,
        'session': session.toString(),
        'size': size,
        'email': email,
      });
      await writeState(state);
    }
    final input = await file.open();
    try {
      while (position < size) {
        await input.setPosition(position);
        final bytes = await input.read(min(8 * 1024 * 1024, size - position));
        if (bytes.isEmpty) throw const YouTubeFailure('저장된 영상을 읽지 못했어요.');
        final response = await send(
          'PUT',
          session,
          headers: {
            'Content-Type': 'video/mp4',
            'Content-Range':
                'bytes $position-${position + bytes.length - 1}/$size',
          },
          body: bytes,
        );
        if (response.statusCode == 200 || response.statusCode == 201) {
          return await completed(response);
        }
        if (response.statusCode != 308) check(response);
        final next = offset(response, size);
        if (next <= position) {
          throw const YouTubeFailure('전송이 멈췄어요. 잠시 후 이어 올려 주세요.');
        }
        position = next;
        onProgress(position / size);
      }
      throw const YouTubeFailure('유튜브 처리 결과 확인이 필요해요. 이어 올리기를 눌러 주세요.');
    } finally {
      await input.close();
    }
  }

  static void validateSession(Uri uri) {
    if (uri.scheme != 'https' ||
        uri.host != 'www.googleapis.com' ||
        uri.userInfo.isNotEmpty ||
        uri.port != 443 ||
        !uri.path.startsWith('/upload/')) {
      throw const YouTubeFailure('유튜브 업로드 주소를 확인하지 못했어요.');
    }
  }
}

class YouTubeFailure implements Exception {
  const YouTubeFailure(this.message);
  final String message;
  @override
  String toString() => message;
}
