import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'ai.dart';

class VideoCandidate {
 const VideoCandidate(this.url,this.topic,this.title,{this.query=''});
 final String url,topic,title,query;
 Map<String,dynamic> toJson()=>{'url':url,'topic':topic,'title':title,'query':query};
 factory VideoCandidate.fromJson(Map data)=>VideoCandidate(data['url'] as String,data['topic'] as String,data['title'] as String,query:data['query'] as String? ?? '');
}
class MixedDiscovery {
 final resolver=HttpClient()..connectionTimeout=const Duration(seconds:15);
 bool cancelled=false;
 Map<String,int> diagnostics={};
 void cancel(){cancelled=true;resolver.close(force:true);}
 static String? videoUrl(String raw){
  final u=Uri.tryParse(raw);
  if(u==null||u.scheme!='https'||u.userInfo.isNotEmpty||(u.hasPort&&u.port!=443)||!(u.host=='tiktok.com'||u.host.endsWith('.tiktok.com')))return null;
  if(!RegExp(r'^/@[^/]+/video/[0-9]+/?$').hasMatch(u.path))return null;
  return Uri.https('www.tiktok.com',u.path.replaceAll(RegExp(r'/$'),'')).toString();
 }
 static String? videoId(String raw)=>RegExp(r'/video/([0-9]+)').firstMatch(raw)?.group(1);
 Future<String?> resolve(String raw)async{
  final parsed=Uri.tryParse(raw);if(parsed==null)return null;
  Uri uri=parsed;
  for(var i=0;i<4;i++){
   final direct=videoUrl(uri.toString());if(direct!=null)return direct;
   if(uri.scheme!='https'||uri.host!='vertexaisearch.cloud.google.com'||!uri.path.startsWith('/grounding-api-redirect/')||uri.userInfo.isNotEmpty||(uri.hasPort&&uri.port!=443))return null;
   final req=await resolver.getUrl(uri);req.followRedirects=false;
   final response=await req.close();final location=response.headers.value('location');await response.drain<void>();
   if(response.statusCode<300||response.statusCode>=400||location==null)return null;
   uri=uri.resolve(location);
  }
  return null;
 }
 static List<VideoCandidate> candidatesFromResults(Object? results,String topic,Set<String> seen,{Map<String,int>? diagnostics}){
  final d=diagnostics;
  void count(String key){if(d!=null)d[key]=(d[key]??0)+1;}
  final group=<VideoCandidate>[];
  if(results is! List)return group;
  if(d!=null)d['received']=results.length;
  for(final value in results){
   if(value is! Map){count('invalid');continue;}
   final result=value;
   final raw=result['url'];if(raw is! String){count('invalid');continue;}
   final url=videoUrl(raw);if(url==null){count('nonVideo');continue;}
   final id=videoId(url);if(id==null||!seen.add(id)){count('duplicate');continue;}
   final title=result['title'];
   if(title is String&&RegExp(r'\b(compilation|montage)\b|모음집|모음 영상',caseSensitive:false).hasMatch(title)){count('compilation');continue;}
   count('accepted');group.add(VideoCandidate(url,topic,title is String?title:topic));
   if(group.length==20)break;
  }
  return group;
 }
 static Map<String,Object> searchBody(String topic)=>{
  'query':'$topic site:tiktok.com -compilation -montage',
  'topic':'general','search_depth':'basic','auto_parameters':false,
  'max_results':20,'include_domains':['tiktok.com'],
  'include_answer':false,'include_raw_content':false,'include_images':false,
  'safe_search':true
 };
 static String apiError(int code)=>'Tavily 검색 API · HTTP $code [TAVILY_HTTP_$code] · ${switch(code){401=>'검색 API 키가 유효하지 않아요.',403=>'검색 API 접근 권한이 거부됐어요.',429=>'요청 속도 또는 사용량 한도에 도달했어요. 이 코드만으로 어느 한도인지 구분할 수 없어요.',432||433=>'검색 계정의 사용량·크레딧 제한을 확인해 주세요.',400||422=>'검색 요청 형식·매개변수가 거부됐어요.',_=>code>=500?'검색 서버 오류예요. 다음 실행에서 재시도할 수 있어요.':'검색 요청이 거부됐어요.'}}';
 static const maxRounds=3;
 static const topics=['웃긴 상황·실수·반전','귀여운 동물','아기·가족'];
 static const queries=[
  ['unexpected harmless everyday fail original clip','funny surprised reaction real life','funny harmless accident caught on camera','unexpected kitchen mishap funny reaction','funny slip harmless backyard moment','surprised reaction everyday funny short'],
  ['cat startled by own reflection original','dog reaction owner sneezing funny original','funny kitten puppy unexpected reaction','cat surprised cucumber reaction','dog confused mirror funny','funny rabbit bird unexpected moment'],
  ['baby laughing dad sneezing original','toddler funny unexpected reaction family','baby giggles parents funny moment','toddler surprised food reaction','baby laughing peekaboo funny','dad baby unexpected funny moment'],
 ];
 static List<String> topicsForRound(int round)=>const [
  ['웃긴 상황·실수·반전 funny fail unexpected','귀여운 동물 funny pets cute animals','아기·가족의 재미있는 순간 funny baby family'],
  ['웃긴 상황·실수·반전 funny harmless prank surprise short clip','귀여운 동물 funny kitten puppy reaction short clip','아기·가족의 재미있는 순간 funny toddler laughing parents short clip'],
  ['웃긴 상황·실수·반전 funny everyday bloopers unexpected ending','귀여운 동물 funny otter rabbit bird cute moments','아기·가족의 재미있는 순간 funny baby giggles family surprise'],
 ][round.clamp(0,maxRounds-1)];
 Future<List<VideoCandidate>> discover({required String key,required Set<String> excluded,required void Function(String) onStatus,int round=0,String? query,String? topic})async{
  final limit=Timer(const Duration(minutes:2),cancel);
  final groups=<List<VideoCandidate>>[];
  final seen=excluded.map((value)=>RegExp(r'^\d+$').hasMatch(value)?value:videoId(value)).whereType<String>().toSet();
  try{
   for(final search in query==null?topicsForRound(round):[query]){
    if(cancelled)throw const AiFailure('Tavily 검색을 취소했어요.');
    onStatus('Tavily 검색 · ${topic ?? search.split(' funny').first}');
    final req=await resolver.postUrl(Uri.https('api.tavily.com','/search'));
    req.followRedirects=false;
    req.headers.set('Authorization','Bearer $key');
    req.headers.contentType=ContentType.json;
    req.write(jsonEncode(searchBody(search)));
    final response=await req.close();
    if(response.statusCode!=200){
     await response.drain<void>();
     throw AiFailure(apiError(response.statusCode),retryable:response.statusCode>=500);
    }
    final rawData=jsonDecode(await utf8.decoder.bind(response).join());
    if(rawData is! Map||rawData['results'] is! List)throw const AiFailure('Tavily 검색 응답 형식 오류 [SEARCH_RESPONSE] · 영상 결과 목록이 없어요.');
    final data=rawData;diagnostics={};
    groups.add(candidatesFromResults(data['results'],topic ?? search.split(' funny').first,seen,diagnostics:diagnostics).map((c)=>VideoCandidate(c.url,c.topic,c.title,query:search)).toList());
   }
   final mixed=<VideoCandidate>[];
   for(var i=0;i<20;i++){for(final group in groups){if(i<group.length)mixed.add(group[i]);}}
   
   return mixed;
  }on AiFailure{rethrow;}on SocketException{throw const AiFailure('Tavily 검색 네트워크 연결 실패 [SEARCH_NETWORK]',retryable:true);}on HandshakeException{throw const AiFailure('Tavily 검색 TLS 연결 실패 [SEARCH_TLS]',retryable:true);}on FormatException{throw const AiFailure('Tavily 검색 JSON 해석 실패 [SEARCH_RESPONSE]');}catch(_){throw AiFailure(cancelled?'Tavily 검색이 취소되었거나 제한 시간을 넘겼어요.':'Tavily 검색 응답을 처리하지 못했어요. 네트워크 상태를 확인해 주세요.');}
  finally{limit.cancel();resolver.close(force:true);}
 }
}
