import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'ai.dart';

class VideoCandidate {
 const VideoCandidate(this.url,this.topic,this.title,{this.query=''});
 final String url,topic,title,query;
 Map<String,dynamic> toJson()=>{'url':url,'topic':topic,'title':title,'query':query};
 factory VideoCandidate.fromJson(Map data)=>VideoCandidate(data['url'] as String,data['topic'] as String,data['title'] as String,query:data['query'] as String? ?? '');
}
class MixedDiscovery {
 final resolver=HttpClient()..connectionTimeout=const Duration(seconds:15);
 bool cancelled=false;
 Map<String,int> diagnostics={};
 void cancel(){cancelled=true;resolver.close(force:true);}
 static String? videoUrl(String raw){
  final u=Uri.tryParse(raw);
  if(u==null||u.scheme!='https'||u.userInfo.isNotEmpty||(u.hasPort&&u.port!=443)||!(u.host=='tiktok.com'||u.host.endsWith('.tiktok.com')))return null;
  if(!RegExp(r'^/@[^/]+/video/[0-9]+/?$').hasMatch(u.path))return null;
  return Uri.https('www.tiktok.com',u.path.replaceAll(RegExp(r'/$'),'')).toString();
 }
 static String? videoId(String raw)=>RegExp(r'/video/([0-9]+)').firstMatch(raw)?.group(1);
 Future<String?> resolve(String raw)async{
  final parsed=Uri.tryParse(raw);if(parsed==null)return null;
  Uri uri=parsed;
  for(var i=0;i<4;i++){
   final direct=videoUrl(uri.toString());if(direct!=null)return direct;
   if(uri.scheme!='https'||uri.host!='vertexaisearch.cloud.google.com'||!uri.path.startsWith('/grounding-api-redirect/')||uri.userInfo.isNotEmpty||(uri.hasPort&&uri.port!=443))return null;
   final req=await resolver.getUrl(uri);req.followRedirects=false;
   final response=await req.close();final location=response.headers.value('location');await response.drain<void>();
   if(response.statusCode<300||response.statusCode>=400||location==null)return null;
   uri=uri.resolve(location);
  }
  return null;
 }
 static List<VideoCandidate> candidatesFromResults(Object? results,String topic,Set<String> seen,{Map<String,int>? diagnostics}){
  final d=diagnostics;
  void count(String key){if(d!=null)d[key]=(d[key]??0)+1;}
  final group=<VideoCandidate>[];
  if(results is! List)return group;
  if(d!=null)d['received']=results.length;
  for(final value in results){
   if(value is! Map){count('invalid');continue;}
   final result=value;
   final raw=result['url'];if(raw is! String){count('invalid');continue;}
   final url=videoUrl(raw);if(url==null){count('nonVideo');continue;}
   final id=videoId(url);if(id==null||!seen.add(id)){count('duplicate');continue;}
   final title=result['title'];
   if(title is String&&RegExp(r'\b(compilation|montage)\b|모음집|모음 영상',caseSensitive:false).hasMatch(title)){count('compilation');continue;}
   count('accepted');group.add(VideoCandidate(url,topic,title is String?title:topic));
   if(group.length==20)break;
  }
  return group;
 }
 static Map<String,Object> searchBody(String topic)=>{
  'query':'$topic site:tiktok.com -compilation -montage',
  'topic':'general','search_depth':'basic','auto_parameters':false,
  'max_results':20,'include_domains':['tiktok.com'],
  'include_answer':false,'include_raw_content':false,'include_images':false,
  'safe_search':true
 };
 static String apiError(int code)=>'Tavily 검색 API · HTTP $code [TAVILY_HTTP_$code] · ${switch(code){401=>'검색 API 키가 유효하지 않아요.',403=>'검색 API 접근 권한이 거부됐어요.',429=>'요청 속도 또는 사용량 한도에 도달했어요. 이 코드만으로 어느 한도인지 구분할 수 없어요.',432||433=>'검색 계정의 사용량·크레딧 제한을 확인해 주세요.',400||422=>'검색 요청 형식·매개변수가 거부됐어요.',_=>code>=500?'검색 서버 오류예요. 다음 실행에서 재시도할 수 있어요.':'검색 요청이 거부됐어요.'}}';
 static const maxRounds=3;
 static const topics=['사람·관계 반전','놀라운 실력','신기한 영상','귀여운 영상','웃긴 영상','힐링·감동','스포츠·묘기','생활·음식'];
 static const kinds=['people','skill','curiosity','cute','humor','healing','sports','lifestyle'];
 static String kindFor(String topic)=>kinds[topics.indexOf(topic)];
 static List<int> indicesFor(String selected)=>selected=='혼합 추천'?const [0,1,2]:[topics.indexOf(selected)];
 static const queries=[
  [
   'unexpected boyfriend girlfriend reaction',
   '커플 예상 못한 반응',
   'funny sibling surprise reaction',
   '형제 자매 웃긴 반전',
   'friends unexpected ending funny',
   '친구 예상 밖 결말',
   'husband wife funny misunderstanding',
   '부부 웃긴 오해',
   'friend perfect timing reaction',
   '친구 절묘한 타이밍',
   'dad reveals hidden talent reaction',
   '아빠 숨겨진 실력 반응',
   'unexpected wedding guest reaction',
   '결혼식 예상 밖 반응',
   'funny workplace unexpected moment',
   '직장 동료 웃긴 상황',
   'couple playful competition funny ending',
   '커플 대결 웃긴 결말',
   'friend surprised by magic trick',
   '마술에 놀란 친구 반응',
   'siblings funny competition twist',
   '남매 대결 웃긴 반전',
   'unexpected family reunion reaction',
   '가족 깜짝 만남 반응',
   'funny misunderstanding silent reaction',
   '말없이 웃긴 오해 반응',
   'friends synchronized accidental moment',
   '친구 우연히 동작 일치',
   'couple funny role reversal',
   '커플 역할 바뀐 웃긴 순간',
   'grandparent unexpected skill family reaction',
   '할아버지 실력 가족 반응',
   'friend photobomb unexpected reaction',
   '사진 찍다가 웃긴 반응',
   'partner surprise genuine reaction',
   '깜짝 선물 현실 반응',
  ],
  [
   'pool billiards trick shot impressive',
   '포켓볼 놀라운 기술',
   'table tennis unexpected trick shot',
   '탁구 예상 밖 기술',
   'basketball incredible pass trick shot',
   '농구 놀라운 패스',
   'worker amazing hand skills',
   '작업자 놀라운 손기술',
   'chef fast knife skills',
   '요리사 손놀림 기술',
   'barber impressive haircut transformation',
   '바버샵 놀라운 변화',
   'street performer incredible balance',
   '거리 공연 균형 기술',
   'football freestyle unexpected skill',
   '축구 프리스타일 기술',
   'skateboard creative trick landing',
   '스케이트보드 묘기 성공',
   'juggling surprising skill',
   '저글링 놀라운 기술',
   'tshirt throwing perfect accuracy',
   '티셔츠 던지기 정확도',
   'craftsman precise woodworking technique',
   '목공 정교한 작업 기술',
   'pottery amazing shaping technique',
   '도자기 만드는 손기술',
   'dancer impressive footwork',
   '댄서 놀라운 발동작',
   'gymnastics unexpected skill routine',
   '체조 놀라운 동작',
   'card magic sleight of hand reveal',
   '카드 마술 손기술',
   'parkour precision jump controlled',
   '파쿠르 정확한 착지',
   'musician unexpected instrument technique',
   '악기 연주 특이한 기술',
  ],
  [
   'clever mechanical invention demonstration',
   '기발한 기계 작동 원리',
   'unusual tool surprisingly useful',
   '특이한 도구 놀라운 결과',
   'satisfying unusual manufacturing process',
   '신기한 제조 과정',
   'ship launching into water',
   '배 처음 물에 띄우는 과정',
   'clever space saving furniture mechanism',
   '공간 절약 가구 기발한 작동',
   'unexpected domino chain reaction',
   '도미노 예상 밖 연쇄 반응',
   'kinetic sculpture surprising movement',
   '움직이는 조형물 기발한 구조',
   'optical illusion sculpture reveal',
   '착시 조형물 반전',
   'creative solution everyday problem',
   '일상 문제 기발한 해결',
   'clever packaging machine process',
   '포장 기계 신기한 과정',
   'unusual automatic machine demonstration',
   '특이한 자동 기계 작동',
   'unexpected object transformation process',
   '물건 변신 놀라운 결과',
   'creative cooking tool mechanism',
   '요리 도구 기발한 원리',
   'interesting science demonstration visual',
   '눈으로 보는 신기한 실험',
   'hidden mechanism revealed short',
   '숨겨진 구조 공개',
   'creative diy invention actually works',
   '직접 만든 발명품 작동',
   'unusual construction clever technique',
   '건설 현장 기발한 작업',
   'unexpected satisfying restoration reveal',
   '복원 작업 예상 밖 결과',
  ],
  [
   'cute kitten cuddling',
   '아기 고양이 애교',
   'cute puppy sleepy',
   '졸린 강아지 귀여운 모습',
   'cute baby laughing',
   '아기 웃음 귀여운 반응',
   'cute hamster eating',
   '햄스터 먹방 귀여운 모습',
   'cute rabbit playing',
   '토끼 장난 귀여운 모습',
   'cute duckling following',
   '아기 오리 따라가기',
   'cute otter playing',
   '수달 장난 귀여운 모습',
   'cute red panda reaction',
   '레서판다 귀여운 반응',
   'cute hedgehog eating',
   '고슴도치 먹는 모습',
   'cute kitten puppy friendship',
   '고양이 강아지 우정',
   'cute pet greeting owner',
   '주인 반기는 반려동물',
   'cute baby peekaboo',
   '까꿍하는 아기',
   'cute puppy first snow',
   '강아지 첫눈 반응',
   'cute cat tiny meow',
   '아기 고양이 작은 울음',
   'cute parrot head tilt',
   '앵무새 고개 갸웃',
   'cute baby animal rescue reunion',
   '아기 동물 만남',
   'cute pet gentle interaction',
   '반려동물 다정한 모습',
   'cute toddler innocent reaction',
   '아기 순수한 반응',
  ],
  [
   'funny harmless everyday fail',
   '일상 웃긴 실수',
   'funny surprise reaction',
   '예상 밖 웃긴 반응',
   'funny cooking mistake',
   '요리하다 웃긴 실수',
   'funny friend misunderstanding',
   '친구 웃긴 오해',
   'funny cat confused',
   '고양이 당황한 반응',
   'funny dog unexpected reaction',
   '강아지 웃긴 반응',
   'funny toddler unexpected answer',
   '아기 예상 밖 대답',
   'funny perfect timing coincidence',
   '절묘한 타이밍 웃긴 순간',
   'funny dancing fail harmless',
   '춤추다 웃긴 실수',
   'funny birthday surprise',
   '생일 웃긴 상황',
   'funny workplace moment',
   '직장 웃긴 순간',
   'funny husband wife reaction',
   '부부 웃긴 반응',
   'funny sports harmless mistake',
   '운동 웃긴 실수',
   'funny pet photobomb',
   '사진 방해하는 반려동물',
   'funny sneeze reaction',
   '재채기 웃긴 반응',
   'funny harmless prank reveal',
   '가벼운 장난 웃긴 결말',
   'funny object unexpected movement',
   '물건 예상 밖 움직임',
   'funny baby imitation',
   '따라하는 아기 웃긴 모습',
  ],
  [
   'wholesome family reunion',
   '가족 재회 따뜻한 순간',
   'heartwarming dog owner reunion',
   '강아지 주인 재회',
   'calming nature waterfall',
   '잔잔한 자연 폭포',
   'satisfying craft process',
   '힐링되는 공예 과정',
   'gentle animal friendship',
   '동물 다정한 우정',
   'wholesome strangers helping',
   '서로 도와주는 따뜻한 순간',
   'peaceful cat relaxing',
   '편안히 쉬는 고양이',
   'calming rain garden',
   '빗소리 정원 힐링',
   'heartwarming surprise gift',
   '감동적인 깜짝 선물',
   'wholesome grandparent grandchild',
   '할머니 손주 다정한 순간',
   'satisfying restoration reveal',
   '물건 복원 감동적인 결과',
   'calming ocean sunset',
   '바다 노을 힐링',
   'heartwarming graduation reaction',
   '졸업 감동적인 반응',
   'wholesome friendship kindness',
   '친구 배려 따뜻한 순간',
   'calming pottery shaping',
   '잔잔한 도자기 만들기',
   'peaceful cooking morning',
   '조용한 아침 요리',
   'gentle pet cuddles',
   '반려동물 다정한 포옹',
   'heartwarming achievement reaction',
   '목표 달성 감동적인 반응',
  ],
  [
   'basketball trick shot',
   '농구 묘기 성공',
   'football freestyle skill',
   '축구 프리스타일',
   'table tennis amazing rally',
   '탁구 놀라운 랠리',
   'pool trick shot precision',
   '포켓볼 정교한 묘기',
   'skateboard creative trick',
   '스케이트보드 창의적인 묘기',
   'gymnastics balance skill',
   '체조 균형 기술',
   'badminton incredible rally',
   '배드민턴 놀라운 랠리',
   'volleyball impressive save',
   '배구 멋진 수비',
   'bowling unusual strike',
   '볼링 특이한 스트라이크',
   'tennis surprising shot',
   '테니스 놀라운 샷',
   'archery precision shot',
   '양궁 정확한 샷',
   'parkour controlled precision',
   '파쿠르 정확한 착지',
   'jump rope impressive skills',
   '줄넘기 놀라운 기술',
   'bmx technical trick',
   '자전거 묘기 기술',
   'climbing clever technique',
   '클라이밍 기발한 기술',
   'skating impressive footwork',
   '스케이트 발놀림',
   'baseball amazing catch',
   '야구 놀라운 수비',
   'dance acrobatic controlled routine',
   '댄스 아크로바틱 동작',
  ],
  [
   'clever kitchen tool demonstration',
   '기발한 주방 도구',
   'quick cooking technique',
   '빠른 요리 기술',
   'satisfying food preparation',
   '음식 만드는 신기한 과정',
   'creative dessert decoration',
   '디저트 창의적인 장식',
   'useful cleaning technique',
   '유용한 청소 방법',
   'clever storage idea',
   '기발한 수납 아이디어',
   'simple home repair trick',
   '간단한 집 수리 방법',
   'creative lunchbox preparation',
   '도시락 만드는 과정',
   'barista latte art technique',
   '바리스타 라떼 아트',
   'bread shaping technique',
   '빵 모양 만드는 기술',
   'noodle making hand skills',
   '면 만드는 손기술',
   'clever folding clothes',
   '옷 접는 기발한 방법',
   'smart everyday gadget',
   '생활 신기한 도구',
   'fruit cutting creative technique',
   '과일 자르는 기술',
   'unusual cooking process',
   '특이한 요리 과정',
   'creative furniture mechanism',
   '기발한 가구 구조',
   'satisfying organization process',
   '정리하는 시원한 과정',
   'food plating transformation',
   '음식 플레이팅 변화',
  ],
 ];
 static List<String> topicsForRound(int round)=>[for(final group in queries)group[(round.clamp(0,maxRounds-1))*2]];
 Future<List<VideoCandidate>> discover({required String key,required Set<String> excluded,required void Function(String) onStatus,int round=0,String? query,String? topic})async{
  final limit=Timer(const Duration(minutes:2),cancel);
  final groups=<List<VideoCandidate>>[];
  final seen=excluded.map((value)=>RegExp(r'^\d+$').hasMatch(value)?value:videoId(value)).whereType<String>().toSet();
  try{
   for(final search in query==null?topicsForRound(round):[query]){
    if(cancelled)throw const AiFailure('Tavily 검색을 취소했어요.');
    onStatus('Tavily 검색 · ${topic ?? search.split(' funny').first}');
    final req=await resolver.postUrl(Uri.https('api.tavily.com','/search'));
    req.followRedirects=false;
    req.headers.set('Authorization','Bearer $key');
    req.headers.contentType=ContentType.json;
    req.write(jsonEncode(searchBody(search)));
    final response=await req.close();
    if(response.statusCode!=200){
     await response.drain<void>();
     throw AiFailure(apiError(response.statusCode),retryable:response.statusCode>=500);
    }
    final rawData=jsonDecode(await utf8.decoder.bind(response).join());
    if(rawData is! Map||rawData['results'] is! List)throw const AiFailure('Tavily 검색 응답 형식 오류 [SEARCH_RESPONSE] · 영상 결과 목록이 없어요.');
    final data=rawData;diagnostics={};
    groups.add(candidatesFromResults(data['results'],topic ?? search.split(' funny').first,seen,diagnostics:diagnostics).map((c)=>VideoCandidate(c.url,c.topic,c.title,query:search)).toList());
   }
   final mixed=<VideoCandidate>[];
   for(var i=0;i<20;i++){for(final group in groups){if(i<group.length)mixed.add(group[i]);}}
   
   return mixed;
  }on AiFailure{rethrow;}on SocketException{throw const AiFailure('Tavily 검색 네트워크 연결 실패 [SEARCH_NETWORK]',retryable:true);}on HandshakeException{throw const AiFailure('Tavily 검색 TLS 연결 실패 [SEARCH_TLS]',retryable:true);}on FormatException{throw const AiFailure('Tavily 검색 JSON 해석 실패 [SEARCH_RESPONSE]');}catch(_){throw AiFailure(cancelled?'Tavily 검색이 취소되었거나 제한 시간을 넘겼어요.':'Tavily 검색 응답을 처리하지 못했어요. 네트워크 상태를 확인해 주세요.');}
  finally{limit.cancel();resolver.close(force:true);}
 }
}
