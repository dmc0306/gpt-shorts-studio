import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'ai.dart';

class VideoCandidate {
 const VideoCandidate(this.url,this.topic,this.title,{this.query=''});
 final String url,topic,title,query;
 Map<String,dynamic> toJson()=>{'url':url,'topic':topic,'title':title,'query':query};
 factory VideoCandidate.fromJson(Map data)=>VideoCandidate(data['url'] as String,data['topic'] as String,data['title'] as String,query:data['query'] as String? ?? '');
}
class MixedDiscovery {
 final resolver=HttpClient()..connectionTimeout=const Duration(seconds:15);
 bool cancelled=false;
 Map<String,int> diagnostics={};
 void cancel(){cancelled=true;resolver.close(force:true);}
 static String? videoUrl(String raw){
  final u=Uri.tryParse(raw);
  if(u==null||u.scheme!='https'||u.userInfo.isNotEmpty||(u.hasPort&&u.port!=443)||!(u.host=='tiktok.com'||u.host.endsWith('.tiktok.com')))return null;
  if(!RegExp(r'^/@[^/]+/video/[0-9]+/?$').hasMatch(u.path))return null;
  return Uri.https('www.tiktok.com',u.path.replaceAll(RegExp(r'/$'),'')).toString();
 }
 static String? videoId(String raw)=>RegExp(r'/video/([0-9]+)').firstMatch(raw)?.group(1);
 Future<String?> resolve(String raw)async{
  final parsed=Uri.tryParse(raw);if(parsed==null)return null;
  Uri uri=parsed;
  for(var i=0;i<4;i++){
   final direct=videoUrl(uri.toString());if(direct!=null)return direct;
   if(uri.scheme!='https'||uri.host!='vertexaisearch.cloud.google.com'||!uri.path.startsWith('/grounding-api-redirect/')||uri.userInfo.isNotEmpty||(uri.hasPort&&uri.port!=443))return null;
   final req=await resolver.getUrl(uri);req.followRedirects=false;
   final response=await req.close();final location=response.headers.value('location');await response.drain<void>();
   if(response.statusCode<300||response.statusCode>=400||location==null)return null;
   uri=uri.resolve(location);
  }
  return null;
 }
 static List<VideoCandidate> candidatesFromResults(Object? results,String topic,Set<String> seen,{Map<String,int>? diagnostics}){
  final d=diagnostics;
  void count(String key){if(d!=null)d[key]=(d[key]??0)+1;}
  final group=<VideoCandidate>[];
  if(results is! List)return group;
  if(d!=null)d['received']=results.length;
  for(final value in results){
   if(value is! Map){count('invalid');continue;}
   final result=value;
   final raw=result['url'];if(raw is! String){count('invalid');continue;}
   final url=videoUrl(raw);if(url==null){count('nonVideo');continue;}
   final id=videoId(url);if(id==null||!seen.add(id)){count('duplicate');continue;}
   final title=result['title'];
   if(title is String&&RegExp(r'\b(compilation|montage)\b|모음집|모음 영상',caseSensitive:false).hasMatch(title)){count('compilation');continue;}
   count('accepted');group.add(VideoCandidate(url,topic,title is String?title:topic));
   if(group.length==20)break;
  }
  return group;
 }
 static Map<String,Object> searchBody(String topic)=>{
  'query':'$topic site:tiktok.com -compilation -montage',
  'topic':'general','search_depth':'basic','auto_parameters':false,
  'max_results':20,'include_domains':['tiktok.com'],
  'include_answer':false,'include_raw_content':false,'include_images':false,
  'safe_search':true
 };
 static String apiError(int code)=>'Tavily 검색 API · HTTP $code [TAVILY_HTTP_$code] · ${switch(code){401=>'검색 API 키가 유효하지 않아요.',403=>'검색 API 접근 권한이 거부됐어요.',429=>'요청 속도 또는 사용량 한도에 도달했어요. 이 코드만으로 어느 한도인지 구분할 수 없어요.',432||433=>'검색 계정의 사용량·크레딧 제한을 확인해 주세요.',400||422=>'검색 요청 형식·매개변수가 거부됐어요.',_=>code>=500?'검색 서버 오류예요. 다음 실행에서 재시도할 수 있어요.':'검색 요청이 거부됐어요.'}}';
 static const maxRounds=3;
 static const topics=['사람·관계 반전','놀라운 실력','기발한 상황'];
 static const queries=[
  [
   'unexpected boyfriend girlfriend reaction',
   '커플 예상 못한 반응',
   'funny sibling surprise reaction',
   '형제 자매 웃긴 반전',
   'friends unexpected ending funny',
   '친구 예상 밖 결말',
   'husband wife funny misunderstanding',
   '부부 웃긴 오해',
   'friend perfect timing reaction',
   '친구 절묘한 타이밍',
   'dad reveals hidden talent reaction',
   '아빠 숨겨진 실력 반응',
   'unexpected wedding guest reaction',
   '결혼식 예상 밖 반응',
   'funny workplace unexpected moment',
   '직장 동료 웃긴 상황',
   'couple playful competition funny ending',
   '커플 대결 웃긴 결말',
   'friend surprised by magic trick',
   '마술에 놀란 친구 반응',
   'siblings funny competition twist',
   '남매 대결 웃긴 반전',
   'unexpected family reunion reaction',
   '가족 깜짝 만남 반응',
   'funny misunderstanding silent reaction',
   '말없이 웃긴 오해 반응',
   'friends synchronized accidental moment',
   '친구 우연히 동작 일치',
   'couple funny role reversal',
   '커플 역할 바뀐 웃긴 순간',
   'grandparent unexpected skill family reaction',
   '할아버지 실력 가족 반응',
   'friend photobomb unexpected reaction',
   '사진 찍다가 웃긴 반응',
   'partner surprise genuine reaction',
   '깜짝 선물 현실 반응',
  ],
  [
   'pool billiards trick shot impressive',
   '포켓볼 놀라운 기술',
   'table tennis unexpected trick shot',
   '탁구 예상 밖 기술',
   'basketball incredible pass trick shot',
   '농구 놀라운 패스',
   'worker amazing hand skills',
   '작업자 놀라운 손기술',
   'chef fast knife skills',
   '요리사 손놀림 기술',
   'barber impressive haircut transformation',
   '바버샵 놀라운 변화',
   'street performer incredible balance',
   '거리 공연 균형 기술',
   'football freestyle unexpected skill',
   '축구 프리스타일 기술',
   'skateboard creative trick landing',
   '스케이트보드 묘기 성공',
   'juggling surprising skill',
   '저글링 놀라운 기술',
   'tshirt throwing perfect accuracy',
   '티셔츠 던지기 정확도',
   'craftsman precise woodworking technique',
   '목공 정교한 작업 기술',
   'pottery amazing shaping technique',
   '도자기 만드는 손기술',
   'dancer impressive footwork',
   '댄서 놀라운 발동작',
   'gymnastics unexpected skill routine',
   '체조 놀라운 동작',
   'card magic sleight of hand reveal',
   '카드 마술 손기술',
   'parkour precision jump controlled',
   '파쿠르 정확한 착지',
   'musician unexpected instrument technique',
   '악기 연주 특이한 기술',
  ],
  [
   'clever mechanical invention demonstration',
   '기발한 기계 작동 원리',
   'unusual tool surprisingly useful',
   '특이한 도구 놀라운 결과',
   'satisfying unusual manufacturing process',
   '신기한 제조 과정',
   'ship launching into water',
   '배 처음 물에 띄우는 과정',
   'clever space saving furniture mechanism',
   '공간 절약 가구 기발한 작동',
   'unexpected domino chain reaction',
   '도미노 예상 밖 연쇄 반응',
   'kinetic sculpture surprising movement',
   '움직이는 조형물 기발한 구조',
   'optical illusion sculpture reveal',
   '착시 조형물 반전',
   'creative solution everyday problem',
   '일상 문제 기발한 해결',
   'clever packaging machine process',
   '포장 기계 신기한 과정',
   'unusual automatic machine demonstration',
   '특이한 자동 기계 작동',
   'unexpected object transformation process',
   '물건 변신 놀라운 결과',
   'creative cooking tool mechanism',
   '요리 도구 기발한 원리',
   'interesting science demonstration visual',
   '눈으로 보는 신기한 실험',
   'hidden mechanism revealed short',
   '숨겨진 구조 공개',
   'creative diy invention actually works',
   '직접 만든 발명품 작동',
   'unusual construction clever technique',
   '건설 현장 기발한 작업',
   'unexpected satisfying restoration reveal',
   '복원 작업 예상 밖 결과',
  ],
 ];
 static List<String> topicsForRound(int round)=>[for(final group in queries)group[(round.clamp(0,maxRounds-1))*2]];
 Future<List<VideoCandidate>> discover({required String key,required Set<String> excluded,required void Function(String) onStatus,int round=0,String? query,String? topic})async{
  final limit=Timer(const Duration(minutes:2),cancel);
  final groups=<List<VideoCandidate>>[];
  final seen=excluded.map((value)=>RegExp(r'^\d+$').hasMatch(value)?value:videoId(value)).whereType<String>().toSet();
  try{
   for(final search in query==null?topicsForRound(round):[query]){
    if(cancelled)throw const AiFailure('Tavily 검색을 취소했어요.');
    onStatus('Tavily 검색 · ${topic ?? search.split(' funny').first}');
    final req=await resolver.postUrl(Uri.https('api.tavily.com','/search'));
    req.followRedirects=false;
    req.headers.set('Authorization','Bearer $key');
    req.headers.contentType=ContentType.json;
    req.write(jsonEncode(searchBody(search)));
    final response=await req.close();
    if(response.statusCode!=200){
     await response.drain<void>();
     throw AiFailure(apiError(response.statusCode),retryable:response.statusCode>=500);
    }
    final rawData=jsonDecode(await utf8.decoder.bind(response).join());
    if(rawData is! Map||rawData['results'] is! List)throw const AiFailure('Tavily 검색 응답 형식 오류 [SEARCH_RESPONSE] · 영상 결과 목록이 없어요.');
    final data=rawData;diagnostics={};
    groups.add(candidatesFromResults(data['results'],topic ?? search.split(' funny').first,seen,diagnostics:diagnostics).map((c)=>VideoCandidate(c.url,c.topic,c.title,query:search)).toList());
   }
   final mixed=<VideoCandidate>[];
   for(var i=0;i<20;i++){for(final group in groups){if(i<group.length)mixed.add(group[i]);}}
   
   return mixed;
  }on AiFailure{rethrow;}on SocketException{throw const AiFailure('Tavily 검색 네트워크 연결 실패 [SEARCH_NETWORK]',retryable:true);}on HandshakeException{throw const AiFailure('Tavily 검색 TLS 연결 실패 [SEARCH_TLS]',retryable:true);}on FormatException{throw const AiFailure('Tavily 검색 JSON 해석 실패 [SEARCH_RESPONSE]');}catch(_){throw AiFailure(cancelled?'Tavily 검색이 취소되었거나 제한 시간을 넘겼어요.':'Tavily 검색 응답을 처리하지 못했어요. 네트워크 상태를 확인해 주세요.');}
  finally{limit.cancel();resolver.close(force:true);}
 }
}
