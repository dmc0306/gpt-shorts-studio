import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'bridge.dart';
import 'youtube_upload.dart';

/// The Google refresh token and web-client secret remain on the user's PC.
class YouTubePc {
  YouTubePc({http.Client Function()? clientFactory})
    : _clientFactory = clientFactory ?? http.Client.new;
  final http.Client Function() _clientFactory;
  String get identityPrefix => 'pc:';
  String identity = '';
  bool cancelled = false;
  bool pending = false;

  Future<Map<String, dynamic>> request(String method, String path) async {
    final key = await Native.call<String>('youtubePcKey');
    if (key == null || key.isEmpty) {
      throw const YouTubeFailure('PC에서 인증 도구의 휴대폰 연결을 먼저 실행해 주세요.');
    }
    final client = _clientFactory();
    try {
      final req = http.Request(method, Uri.parse('http://127.0.0.1:8765$path'))
        ..followRedirects = false
        ..headers['Authorization'] = 'Bearer $key';
      final response = await http.Response.fromStream(
        await client.send(req).timeout(const Duration(seconds: 75)),
      ).timeout(const Duration(seconds: 75));
      if (response.statusCode == 401) {
        throw const YouTubeFailure('PC와 휴대폰을 다시 연결해 주세요.');
      }
      final data =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (response.statusCode != 200) {
        final error = data['error'] as String? ?? '';
        if (error.contains('PC_SETUP')) {
          throw const YouTubeFailure(
            'PC에 Google 웹 클라이언트 JSON을 등록해야 해요. PC 인증 도구 안내를 확인해 주세요.',
          );
        }
        if (error.contains('YT_CHANNEL_COUNT')) {
          throw const YouTubeFailure(
            '브라우저에서 선택한 권한으로 채널 하나를 확인하지 못했어요. 원하는 브랜드 계정의 소유 권한을 확인해 주세요.',
          );
        }
        throw const YouTubeFailure(
          '브라우저 인증을 완료하지 못했어요. 앱에서 다시 연결하고 채널 조회·업로드 권한을 모두 허용해 주세요.',
        );
      }
      return data;
    } on TimeoutException {
      throw const YouTubeFailure('PC 응답이 늦어요. PC 인증 도구와 휴대폰 연결을 확인해 주세요.');
    } on http.ClientException {
      throw const YouTubeFailure('PC 인증 도구와 ADB 연결을 확인해 주세요. PC가 켜져 있어야 해요.');
    } finally {
      client.close();
    }
  }

  Future<void> connect() async {
    cancelled = false;
    pending = true;
    try {
      final login = await request('POST', '/api/login');
      final uri = Uri.parse(login['url'] as String);
      if (uri.scheme != 'https' ||
          uri.host != 'accounts.google.com' ||
          uri.path != '/o/oauth2/v2/auth' ||
          uri.userInfo.isNotEmpty ||
          uri.port != 443) {
        throw const YouTubeFailure('인증 주소를 확인하지 못했어요.');
      }
      await Native.call('openYoutubeBrowser', {'url': uri.toString()});
      final deadline = DateTime.now().add(const Duration(minutes: 10));
      while (!cancelled && DateTime.now().isBefore(deadline)) {
        await Future<void>.delayed(const Duration(seconds: 2));
        if (cancelled) break;
        final status = await request(
          'GET',
          '/api/login/${Uri.encodeComponent(login['flow'] as String)}',
        );
        if (cancelled) break;
        if (status['status'] == 'complete') return;
        if (status['status'] == 'error') {
          final error = status['error'] as String? ?? '';
          throw YouTubeFailure(
            error.contains('YT_CHANNEL_COUNT')
                ? '선택한 권한으로 채널 하나를 확인하지 못했어요. 원하는 브랜드 계정의 소유 권한을 확인해 주세요.'
                : '인증이 취소됐거나 권한이 부족해요. 브라우저에서 다시 연결해 주세요.',
          );
        }
      }
      throw const YouTubeFailure('브라우저 인증을 중단했거나 시간이 지났어요. 다시 연결해 주세요.');
    } finally {
      pending = false;
    }
  }

  Future<String> token() async {
    final data = await request('POST', '/api/token');
    final token = data['access_token'], id = data['identity'];
    if (token is! String ||
        token.isEmpty ||
        id is! String ||
        !id.startsWith(identityPrefix)) {
      throw const YouTubeFailure('PC 인증 응답을 확인하지 못했어요.');
    }
    identity = id;
    return token;
  }

  Future<void> disconnect() async {
    await request('POST', '/api/disconnect');
    identity = '';
  }
}
