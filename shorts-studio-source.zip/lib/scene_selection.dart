// Observable scene evidence; scores are not a popularity prediction.
class SceneSelection {
 const SceneSelection({required this.accepted,required this.kind,required this.hook,required this.payoff,required this.reason,required this.start,required this.end,required this.peak});
 final bool accepted;
 final String kind,hook,payoff,reason;
 final double start,end,peak;
 bool get usable=>accepted&&['people','skill','curiosity','cute','humor','healing','sports','lifestyle'].contains(kind)&&hook.trim().length>=5&&payoff.trim().length>=5;
 Map<String,dynamic> toJson()=>{'accepted':accepted,'kind':kind,'hook':hook,'payoff':payoff,'reason':reason,'start':start,'end':end,'peak':peak};
 factory SceneSelection.fromJson(Map data,{required double sourceStart,required double sourceEnd}){
  if(data['accepted'] is! bool||!['people','skill','curiosity','cute','humor','healing','sports','lifestyle','other'].contains(data['kind'])||['hook','payoff','reason'].any((k)=>data[k] is! String)||['start','end','peak'].any((k)=>data[k] is! num||(data[k] as num).isFinite==false))throw const FormatException('장면 선택 필드가 없거나 잘못됐어요.');
  final start=(data['start'] as num).toDouble(),end=(data['end'] as num).toDouble(),peak=(data['peak'] as num).toDouble();
  if(start<sourceStart||end>sourceEnd||end-start<5||end-start>30||peak<start||peak>end)throw const FormatException('핵심 장면·구간 시간이 범위를 벗어났어요.');
  return SceneSelection(accepted:data['accepted'] as bool,kind:data['kind'] as String,hook:data['hook'] as String,payoff:data['payoff'] as String,reason:data['reason'] as String,start:start,end:end,peak:peak);
 }
 static Map<String,dynamic> schema()=>{'type':'OBJECT','properties':{'accepted':{'type':'BOOLEAN'},'kind':{'type':'STRING','enum':['people','skill','curiosity','cute','humor','healing','sports','lifestyle','other']},for(final k in ['hook','payoff','reason'])k:{'type':'STRING'},for(final k in ['start','end','peak'])k:{'type':'NUMBER'}},'required':['accepted','kind','hook','payoff','reason','start','end','peak']};
}
const sceneRules='수집 취향은 사람·관계 반전(커플/친구/형제의 예상 밖 행동·반응), 놀라운 실력(손재주/기술/묘기), 기발한 상황(독특한 과정·발명·결과)이야. 카테고리별 추가 지침을 우선해. selection.kind는 people/skill/curiosity/cute/humor/healing/sports/lifestyle/other. hook에는 선택 구간 초반에 실제 보이는 궁금증·상황, payoff에는 핵심 행동·반전·완성 결과를 구체적으로 써. 추측·막연히 웃기다/귀엽다/놀랍다 평가는 근거가 아니야. 도입과 결과가 자연스럽게 연결되는 연속 구간을 원본 기준 start/end 초로 고르고 길이 5~30초, peak는 핵심 행동이 일어나는 원본 기준 초. 원본이 30초 이하라도 지루한 앞뒤를 줄일 수 있어. 해당 취향이 아니거나 구체적 hook/payoff가 없고, 맥락이 잘리거나 결과가 나오지 않으면 accepted=false와 reason을 써. 거절하는 경우에도 유효한 5~30초 구간과 그 안의 peak를 반환해. 제목 세 후보와 자막은 반드시 선택한 구간만 근거로 생성해. 아래 자막 지침의 원본 전체 범위 대신 selection.start/end 안에서만 자막을 만들고 최대 5개, 최소 간격 1.5초, 총 노출 40% 이하. 출연자의 관계·직업·정체·국적을 외모로 추측하거나 인터넷 제목을 사실로 믿지 마. 상황극 촬영 자체는 거절 사유가 아니지만 최종 크롭 영역에 남는 합성 자막·모음집·생성 영상 의심 등 품질 검사는 계속 적용해.';

String categoryRules(String topic)=>switch(topic){
 '귀여운 영상'=>'요청 카테고리는 귀여운 영상(cute). 귀여운 표정·작은 행동·애교·다정한 상호작용이 구체적으로 보이면 채택할 수 있어. 억지 반전·놀라운 기술을 요구하지 마. hook/payoff는 실제 귀여운 장면과 볼 지점을 구체적으로 설명해.',
 '웃긴 영상'=>'요청 카테고리는 웃긴 영상(humor). 무해한 실수·오해·절묘한 타이밍·예상 밖 반응이 보이는 장면을 선택해. 괴롭힘·부상·조롱은 제외해.',
 '힐링·감동'=>'요청 카테고리는 힐링·감동(healing). 편안한 자연·공예 과정·다정함·따뜻한 만남·도움 장면을 선택해. 큰 반전이 없어도 구체적인 볼 지점이 있으면 돼. 사연을 지어내지 마.',
 '스포츠·묘기'=>'요청 카테고리는 스포츠·묘기(sports). 실제 운동 기술·정확한 동작·멋진 경기 순간이 보여야 해. 부상·위험 행동을 부추기는 영상은 제외해.',
 '생활·음식'=>'요청 카테고리는 생활·음식(lifestyle). 요리·정리·생활 도구·작업 과정의 구체적인 볼 지점과 결과가 있어야 해. 효능·안전성·과학 원리를 추측하지 마.',
 '사람·관계 반전'=>'요청 카테고리는 사람·관계 반전(people). 실제로 보이는 관계 상황·행동 변화·반응을 선택하고 직업/관계를 추측하지 마.',
 '놀라운 실력'=>'요청 카테고리는 놀라운 실력(skill). 구체적인 손기술·실력·정확한 동작과 결과를 선택해.',
 _=>'요청 카테고리는 기발한 상황(curiosity). 특이한 과정·구조·발명·예상 밖 결과를 구체적으로 확인해.',
};
