import 'package:characters/characters.dart';
import 'package:flutter/services.dart';

const headlineLineMinimum=5;
const headlineLineLimit=11;
List<String> headlineLines(String value)=>value.replaceAll('\r','').split('\n');
bool validHeadline(String value){
 final lines=headlineLines(value);
 return lines.length==2&&lines.every((s)=>s.trim().characters.length>=headlineLineMinimum&&s.characters.length<=headlineLineLimit);
}
String fitHeadline(String value)=>value.replaceAll('\r','');
class HeadlineInputFormatter extends TextInputFormatter {
 const HeadlineInputFormatter();
 @override TextEditingValue formatEditUpdate(TextEditingValue oldValue,TextEditingValue newValue)=>newValue;
}
