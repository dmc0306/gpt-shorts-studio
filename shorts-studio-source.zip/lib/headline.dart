import 'package:characters/characters.dart';
import 'package:flutter/services.dart';

const headlineLineLimit=11;
List<String> headlineLines(String value)=>value.replaceAll('\r','').split('\n');
bool validHeadline(String value){
 final lines=headlineLines(value);
 return lines.length<=2&&lines.every((s)=>s.characters.length<=headlineLineLimit);
}
String fitHeadline(String value)=>headlineLines(value).take(2).map((s)=>s.characters.take(headlineLineLimit).toString()).join('\n');
class HeadlineInputFormatter extends TextInputFormatter {
 const HeadlineInputFormatter();
 @override TextEditingValue formatEditUpdate(TextEditingValue oldValue,TextEditingValue newValue){
  if(newValue.composing.isValid&&!newValue.composing.isCollapsed)return newValue;
  final text=fitHeadline(newValue.text);
  return newValue.copyWith(text:text,selection:TextSelection.collapsed(offset:newValue.selection.extentOffset.clamp(0,text.length)),composing:TextRange.empty);
 }
}
