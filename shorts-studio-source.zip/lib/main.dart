import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'bridge.dart';
import 'model.dart';
import 'input_dialog.dart';
import 'theme.dart';
import 'editor.dart';
import 'auto_batch.dart';
import 'tiktok_download.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const Studio());}
class Studio extends StatelessWidget{
 const Studio({super.key});
 @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Shorts Studio',theme:studioTheme(),home:const LibraryScreen());
}
class LibraryScreen extends StatefulWidget{
 const LibraryScreen({super.key});
 @override State<LibraryScreen> createState()=>_LibraryState();
}
class _LibraryState extends State<LibraryScreen> with WidgetsBindingObserver{
 List<Clip> clips=[]; int page=0; String query=''; bool busy=true,watching=false,loaded=false,scanning=false; Timer? timer; bool draining=false; TikTokDownloader? downloader; String downloadStage=''; double? downloadProgress;
 @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);init();}
 Future<void> init()async{
  try{clips=await Native.load();watching=await Native.call<bool>('watchEnabled')??false;loaded=true;await drain();timer=Timer.periodic(const Duration(seconds:15),(_)=>scan());}
  catch(e){message('프로젝트를 불러오지 못했어요. $e');}
  if(mounted)setState(()=>busy=!loaded);
 }
 @override void dispose(){downloader?.cancel();timer?.cancel();WidgetsBinding.instance.removeObserver(this);super.dispose();}
 @override void didChangeAppLifecycleState(AppLifecycleState state){if(state==AppLifecycleState.resumed&&loaded)scan();}
 void message(String text){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));}
 Future<void> drain()async{
  if(draining||!loaded)return;draining=true;
  try{final incoming=await Native.inbox();for(final c in incoming){if(!clips.any((x)=>x.id==c.id || (c.url.isNotEmpty&&x.url==c.url))){clips.insert(0,c);if(!c.ready&&c.url.isNotEmpty)await downloadClip(c);}}if(incoming.isNotEmpty){await Native.save(clips);await Native.call('ackInbox',{'ids':incoming.map((c)=>c.id).toList()});}if(mounted)setState((){});}finally{draining=false;}
 }
 Future<void> scan()async{if(busy||draining||scanning||!loaded)return;scanning=true;try{if(watching)await Native.call('scanFolder');await drain();}catch(e){message('폴더를 확인하지 못했어요. 다시 연결해 주세요.');}finally{scanning=false;}}
 Future<void> action(Future<void> Function() fn)async{if(busy||downloader!=null)return;setState(()=>busy=true);try{await fn();await drain();}catch(e){message('작업을 완료하지 못했어요. $e');}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> addLink()async{
  final input=TextEditingController();
  final text=await showDialog<String>(context:context,builder:(ctx)=>ManagedInputDialog(controllers:[input],builder:(ctx)=>AlertDialog(title:const Text('TikTok 링크 추가'),content:TextField(controller:input,autofocus:true,decoration:const InputDecoration(hintText:'https://www.tiktok.com/...')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('취소')),FilledButton(onPressed:()=>Navigator.pop(ctx,input.text),child:const Text('원본 가져오기'))])));
  if(!mounted)return;
  if(text==null)return;final url=tiktokUrl(text);if(url==null){message('올바른 TikTok HTTPS 링크를 입력해 주세요.');return;}
  await action(()async{await Native.call('addLink',{'url':url});});
 }
 Future<void> downloadClip(Clip c)async{
  if(downloader!=null)return;
  final task=TikTokDownloader();downloader=task;c.downloadError='';
  try{
    final raw=await task.download(c.url,(value,stage){if(mounted)setState((){downloadProgress=value;downloadStage=stage;});});
    final file=Clip.fromJson(raw);c.path=file.path;c.duration=file.duration;c.end=file.duration;c.thumbnail=file.thumbnail;c.name=file.name;c.creator=file.creator;c.downloadError='';
  }catch(e){c.downloadError=e.toString();}
  finally{downloader=null;if(mounted)setState((){downloadStage='';downloadProgress=null;});}
 }
 Future<void> open(Clip c)async{
  if(!c.ready){
    final choice=await showModalBottomSheet<String>(context:context,showDragHandle:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('원본 영상 가져오기',style:TextStyle(fontSize:24)),const SizedBox(height:12),ConstrainedBox(constraints:const BoxConstraints(maxHeight:240),child:SingleChildScrollView(child:SelectableText(c.downloadError.isEmpty?'TikTok에서 원본 다운로드를 시도하거나 기기 파일을 연결해요.':c.downloadError))),const SizedBox(height:20),FilledButton.icon(onPressed:()=>Navigator.pop(ctx,'retry'),icon:const Icon(Icons.download_rounded),label:const Text('다시 다운로드')),if(c.downloadError.isNotEmpty)TextButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:c.downloadError));if(ctx.mounted)ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content:Text('오류 정보를 복사했어요.')));},icon:const Icon(Icons.copy,size:16),label:const Text('오류 정보 복사')),TextButton(onPressed:()=>Navigator.pop(ctx,'file'),child:const Text('기기 파일 연결'))]))));
    if(choice==null)return;
    await action(()async{
      if(choice=='retry'){await downloadClip(c);}else{
        final raw=await Native.call<Map<dynamic,dynamic>>('pickVideo');
        if(raw!=null){final file=Clip.fromJson(Map<String,dynamic>.from(raw));c.path=file.path;c.duration=file.duration;c.end=file.duration;c.thumbnail=file.thumbnail;c.downloadError='';}
      }
      await Native.save(clips);
    });if(!c.ready)return;
  }
  if(!mounted)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>EditorScreen(clip:c,onSave:()=>Native.save(clips))));
  if(mounted)setState((){});
 }
 Future<void> autoBatch()async{
  if(busy||draining||scanning||downloader!=null)return;
  setState(()=>busy=true);
  try{await Navigator.push(context,MaterialPageRoute(builder:(_)=>AutoBatchScreen(clips:clips,onSave:()=>Native.save(clips))));}
  finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> settings()async{
  await showModalBottomSheet(context:context,showDragHandle:true,isScrollControlled:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(24,8,24,32),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('자동 수집',style:TextStyle(fontSize:28,fontWeight:FontWeight.w300)),const SizedBox(height:12),const Text('선택한 폴더에 새로 저장된 영상을 앱이 열려 있는 동안 15초마다 가져와요. 하위 폴더는 포함하지 않아요.'),const SizedBox(height:24),FilledButton.icon(onPressed:(){Navigator.pop(ctx);action(()async{final enabled=await Native.call<bool>('chooseFolder');if(enabled==true)watching=true;});},icon:const Icon(Icons.folder_open),label:Text(watching?'수집 폴더 변경':'수집 폴더 선택')),if(watching)TextButton(onPressed:(){Navigator.pop(ctx);action(()async{await Native.call('stopWatching');watching=false;});},child:const Text('자동 수집 끄기')),const SizedBox(height:20),const Divider(),const Text('TikTok 링크 추가·공유 시 원본 다운로드를 시도해요. 접근 제한이나 다운로드 주소가 없는 영상은 파일을 직접 연결해 주세요. 혼합 영상 자동 제작은 Google 검색에서 발견된 개별 영상 후보를 사용해요.',style:TextStyle(color:muted,fontSize:13))]))));
 }
 @override Widget build(BuildContext context){
  final shown=clips.where((c)=>(page!=1||c.savedUri.isNotEmpty)&&(c.name+' '+c.headline+' '+c.creator).toLowerCase().contains(query.toLowerCase())).toList();
  return Scaffold(appBar:AppBar(title:Row(children:[Container(width:30,height:30,decoration:const BoxDecoration(color:blue,shape:BoxShape.circle),child:const Icon(Icons.north_east,size:19,color:Colors.white)),const SizedBox(width:8),const Text('shorts / studio',style:TextStyle(fontSize:18,letterSpacing:-.7,fontWeight:FontWeight.w600))]),actions:[IconButton(tooltip:'자동 수집 설정',onPressed:settings,icon:const Icon(Icons.tune_rounded)),const SizedBox(width:8)]),body:SafeArea(child:RefreshIndicator(onRefresh:scan,child:CustomScrollView(slivers:[SliverPadding(padding:const EdgeInsets.fromLTRB(24,24,24,0),sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Text('YOUR NEXT SHORT',style:TextStyle(fontSize:11,letterSpacing:2,color:muted)),const Spacer(),Text('${clips.length.toString().padLeft(2,'0')} CLIPS',style:const TextStyle(fontSize:11,color:muted))]),const SizedBox(height:16),Text(page==1?'완성된 순간.':'발견한 순간을,\n나만의 쇼츠로.',style:Theme.of(context).textTheme.headlineLarge),const SizedBox(height:18),Text(page==1?'저장한 영상을 다시 열고 다듬어 보세요.':'영상을 고르면 편집이 시작돼요.',style:const TextStyle(color:muted)),const SizedBox(height:24),Wrap(spacing:8,runSpacing:8,children:[FilledButton.icon(onPressed:busy?null:()=>action(()async{final raw=await Native.call<Map<dynamic,dynamic>>('pickVideo');if(raw!=null){clips.insert(0,Clip.fromJson(Map<String,dynamic>.from(raw)));await Native.save(clips);}}),icon:const Icon(Icons.add,size:18),label:const Text('영상 가져오기')),OutlinedButton.icon(onPressed:busy?null:addLink,icon:const Icon(Icons.link,size:18),label:const Text('링크 추가'))]),const SizedBox(height:12),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:busy||draining||scanning||downloader!=null?null:autoBatch,icon:const Icon(Icons.auto_awesome,size:18),label:const Text('혼합 영상 5개 자동 제작'))),const SizedBox(height:24),InkWell(onTap:settings,borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xfff5f9fc),borderRadius:BorderRadius.circular(18)),child:Row(children:[Icon(watching?Icons.sync:Icons.folder_outlined,color:blue,size:20),const SizedBox(width:12),Expanded(child:Text(watching?'폴더 자동 수집 켜짐 · 앱 실행 중':'폴더를 연결하면 새 영상을 자동으로',style:const TextStyle(fontSize:12))),const Icon(Icons.arrow_forward,size:18)]))),const SizedBox(height:28),Row(children:[Text(page==1?'저장함':'수집함',style:const TextStyle(fontSize:22)),const Spacer(),Text('${shown.length}개',style:const TextStyle(color:muted))]),const SizedBox(height:16),TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(hintText:'영상 검색',prefixIcon:Icon(Icons.search,size:20))),const SizedBox(height:20),if(downloadStage.isNotEmpty)...[Row(children:[Expanded(child:Text(downloadStage,style:const TextStyle(fontSize:12,color:blue))),TextButton(onPressed:()=>downloader?.cancel(),child:const Text('취소'))]),LinearProgressIndicator(value:downloadProgress,minHeight:3)]else if(busy)const LinearProgressIndicator(minHeight:2)]))),if(shown.isEmpty)SliverFillRemaining(hasScrollBody:false,child:Padding(padding:const EdgeInsets.all(32),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.video_collection_outlined,size:48,color:Color(0xffc6c6c6)),const SizedBox(height:16),Text(query.isNotEmpty?'검색 결과가 없어요':page==1?'완성된 쇼츠가 여기에 모여요':'첫 번째 순간을 가져오세요',style:const TextStyle(fontSize:18)),const SizedBox(height:8),const Text('짧은 영상 하나면 충분해요.',style:TextStyle(color:muted)),if(query.isEmpty&&page==0)TextButton(onPressed:busy?null:()=>action(()async{await Native.call('importDemo');}),child:const Text('샘플 영상으로 시작 →'))]))),if(shown.isNotEmpty)SliverPadding(padding:const EdgeInsets.fromLTRB(24,0,24,24),sliver:SliverLayoutBuilder(builder:(context,constraints)=>SliverGrid(delegate:SliverChildBuilderDelegate((ctx,index)=>clipCard(shown[index]),childCount:shown.length),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:constraints.crossAxisExtent>650?4:2,crossAxisSpacing:12,mainAxisSpacing:20,childAspectRatio:.59))))]))),bottomNavigationBar:NavigationBar(backgroundColor:Colors.white,indicatorColor:const Color(0xffe5f5ff),selectedIndex:page,onDestinationSelected:(i)=>setState(()=>page=i),destinations:const[NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'수집함'),NavigationDestination(icon:Icon(Icons.check_circle_outline_rounded),label:'저장함')]));
 }
 Widget clipCard(Clip c)=>InkWell(onTap:busy||downloader!=null?null:()=>open(c),borderRadius:BorderRadius.circular(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(24),child:Stack(fit:StackFit.expand,children:[Container(color:ink,child:c.thumbnail.isNotEmpty?Image.file(File(c.thumbnail),fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.movie_outlined,color:Colors.white54,size:40)):const Center(child:Icon(Icons.link,color:Colors.white54,size:36))),const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.center,end:Alignment.bottomCenter,colors:[Colors.transparent,Colors.black87]))),Positioned(top:12,left:12,child:Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(99)),child:Text(c.ready?(c.savedUri.isEmpty?'편집 가능':'저장 완료'):(downloader!=null&&!c.ready?'다운로드 중':c.downloadError.isEmpty?'원본 연결':'다운로드 확인'),style:const TextStyle(fontSize:10)))),Positioned(bottom:14,left:14,right:14,child:Row(children:[const Icon(Icons.play_arrow_rounded,color:Colors.white,size:28),const Spacer(),Text(c.ready?'${c.duration.toStringAsFixed(0)}s':'LINK',style:const TextStyle(color:Colors.white,fontSize:12))]))]))),const SizedBox(height:10),Text(c.headline.isEmpty?c.name:c.headline,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w500)),Text(c.creator.isEmpty?'기기에서 가져옴':c.creator,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,color:muted))]));
}
