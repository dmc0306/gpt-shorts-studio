import 'dart:async';
import 'dart:convert';
import 'deletion.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'bridge.dart';
import 'model.dart';
import 'input_dialog.dart';
import 'theme.dart';
import 'editor.dart';
import 'youtube_settings.dart';
import 'youtube_batch_publish_screen.dart';
import 'auto_batch.dart';
import 'daily_headless_runner.dart' as daily_worker;
import 'youtube.dart';
import 'ai_settings.dart';
import 'tiktok_download.dart';
import 'benchmark_ui.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const Studio());}
class Studio extends StatelessWidget{
 const Studio({super.key});
 @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Shorts Studio',theme:studioTheme(),home:const LibraryScreen());
}
class LibraryScreen extends StatefulWidget{
 const LibraryScreen({super.key});
 @override State<LibraryScreen> createState()=>_LibraryState();
}
class _LibraryState extends State<LibraryScreen> with WidgetsBindingObserver{
 final selected=<String>{};bool selecting=false;String category='전체';
 List<Clip> clips=[]; int page=0; String query=''; bool busy=true,watching=false,loaded=false,scanning=false; Timer? timer; bool draining=false; TikTokDownloader? downloader; String downloadStage=''; double? downloadProgress;
 static const localDaily=MethodChannel('studio.local/daily_run');
 @override void initState(){
   super.initState();
   WidgetsBinding.instance.addObserver(this);
   localDaily.setMethodCallHandler(_runScheduled);
   init();
 }
 Future<bool> _runScheduled(MethodCall call)async{
   if(call.method!='startDaily'||!mounted||!loaded||busy||draining||scanning||
      downloader!=null)return false;
   final raw=(call.arguments is Map)?call.arguments as Map:{};
   final allowed=(raw['creators'] is List)
     ?(raw['creators'] as List).whereType<String>().map((s)=>s.toLowerCase()).toSet()
     :<String>{};
   if(allowed.isEmpty)return false;
   try{
     final y=YouTube.instance;
     await y.loadSettings();
     if(!y.automatic||!y.preferences.confirmed||
       (y.preferences.publishMode!='private'&&!y.preferences.publicApproved)){
       return false;
     }
     final done=Completer<bool>();
     if(!mounted||busy)return false;
     setState(()=>busy=true);
     final route=Navigator.of(context).push(MaterialPageRoute(
       builder:(_)=>AutoBatchScreen(
         clips:clips,onSave:()=>Native.save(clips),
         dailyTriggered:true,licensedCreators:allowed,
         onDailyFinished:(ok){if(!done.isCompleted)done.complete(ok);}
       )));
     unawaited(route.then((_){
       if(!done.isCompleted)done.complete(false);
     }));
     final result=await done.future;
     if(mounted)setState(()=>busy=false);
     return result;
   }catch(_){
     if(mounted)setState(()=>busy=false);
     return false;
   }
 }

 Future<void> init()async{
  try{clips=await Native.load();watching=await Native.call<bool>('watchEnabled')??false;loaded=true;
   final report=await Native.call<String>('loadBatchReport');
   if(report!=null&&report.isNotEmpty){final data=jsonDecode(report);if(data is Map&&data['items'] is List){for(final item in data['items']){if(item is Map&&libraryCategories.contains(item['topic'])){for(final c in clips.where((c)=>c.category.isEmpty&&c.url.isNotEmpty&&c.url==item['url'])){c.category=item['topic'] as String;}}}await Native.save(clips);}}
   for(final c in clips.where((c)=>c.category.isEmpty)){c.category='기타';}await Native.save(clips);
   await drain();timer=Timer.periodic(const Duration(seconds:15),(_)=>scan());}
  catch(e){message('프로젝트를 불러오지 못했어요. $e');}
  if(mounted)setState(()=>busy=!loaded);
 }
 @override void dispose(){localDaily.setMethodCallHandler(null);downloader?.cancel();timer?.cancel();WidgetsBinding.instance.removeObserver(this);super.dispose();}
 @override void didChangeAppLifecycleState(AppLifecycleState state){if(state==AppLifecycleState.resumed&&loaded)scan();}
 void message(String text){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));}
 Future<void> drain()async{
  if(draining||!loaded)return;draining=true;
  try{final incoming=await Native.inbox();for(final c in incoming){if(c.category.isEmpty)c.category='기타';if(!clips.any((x)=>x.id==c.id || (c.url.isNotEmpty&&x.url==c.url))){clips.insert(0,c);if(!c.ready&&c.url.isNotEmpty)await downloadClip(c);}}if(incoming.isNotEmpty){await Native.save(clips);await Native.call('ackInbox',{'ids':incoming.map((c)=>c.id).toList()});}if(mounted)setState((){});}finally{draining=false;}
 }
 Future<void> scan()async{if(busy||draining||scanning||!loaded)return;scanning=true;try{if(watching)await Native.call('scanFolder');await drain();}catch(e){message('폴더를 확인하지 못했어요. 다시 연결해 주세요.');}finally{scanning=false;}}
 Future<void> action(Future<void> Function() fn)async{if(busy||downloader!=null)return;setState(()=>busy=true);try{await fn();await drain();}catch(e){message('작업을 완료하지 못했어요. $e');}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> addLink()async{
  final input=TextEditingController();
  final text=await showDialog<String>(context:context,builder:(ctx)=>ManagedInputDialog(controllers:[input],builder:(ctx)=>AlertDialog(title:const Text('TikTok 링크 추가'),content:TextField(controller:input,autofocus:true,decoration:const InputDecoration(hintText:'https://www.tiktok.com/...')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('취소')),FilledButton(onPressed:()=>Navigator.pop(ctx,input.text),child:const Text('원본 가져오기'))])));
  if(!mounted)return;
  if(text==null)return;final url=tiktokUrl(text);if(url==null){message('올바른 TikTok HTTPS 링크를 입력해 주세요.');return;}
  await action(()async{await Native.call('addLink',{'url':url});});
 }
 Future<void> downloadClip(Clip c)async{
  if(downloader!=null)return;
  final task=TikTokDownloader();downloader=task;c.downloadError='';
  try{
    final raw=await task.download(c.url,(value,stage){if(mounted)setState((){downloadProgress=value;downloadStage=stage;});});
    final file=Clip.fromJson(raw);c.path=file.path;c.duration=file.duration;c.end=file.duration;c.thumbnail=file.thumbnail;c.name=file.name;c.creator=file.creator;c.downloadError='';
  }catch(e){c.downloadError=e.toString();}
  finally{downloader=null;if(mounted)setState((){downloadStage='';downloadProgress=null;});}
 }
 Future<void> open(Clip c)async{
  if(!c.ready){
    final choice=await showModalBottomSheet<String>(context:context,showDragHandle:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('원본 영상 가져오기',style:TextStyle(fontSize:24)),const SizedBox(height:12),ConstrainedBox(constraints:const BoxConstraints(maxHeight:240),child:SingleChildScrollView(child:SelectableText(c.downloadError.isEmpty?'TikTok에서 원본 다운로드를 시도하거나 기기 파일을 연결해요.':c.downloadError))),const SizedBox(height:20),FilledButton.icon(onPressed:()=>Navigator.pop(ctx,'retry'),icon:const Icon(Icons.download_rounded),label:const Text('다시 다운로드')),if(c.downloadError.isNotEmpty)TextButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:c.downloadError));if(ctx.mounted)ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content:Text('오류 정보를 복사했어요.')));},icon:const Icon(Icons.copy,size:16),label:const Text('오류 정보 복사')),TextButton(onPressed:()=>Navigator.pop(ctx,'file'),child:const Text('기기 파일 연결'))]))));
    if(choice==null)return;
    await action(()async{
      if(choice=='retry'){await downloadClip(c);}else{
        final raw=await Native.call<Map<dynamic,dynamic>>('pickVideo');
        if(raw!=null){final file=Clip.fromJson(Map<String,dynamic>.from(raw));c.path=file.path;c.duration=file.duration;c.end=file.duration;c.thumbnail=file.thumbnail;c.downloadError='';}
      }
      await Native.save(clips);
    });if(!c.ready)return;
  }
  if(!mounted)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>EditorScreen(clip:c,onSave:()=>Native.save(clips))));
  if(mounted)setState((){});
 }
 Future<void> autoBatch()async{
  if(busy||draining||scanning||downloader!=null)return;
  setState(()=>busy=true);
  try{await Navigator.push(context,MaterialPageRoute(builder:(_)=>AutoBatchScreen(clips:clips,onSave:()=>Native.save(clips))));}
  finally{watching=await Native.call<bool>('watchEnabled')??false;if(mounted)setState(()=>busy=false);}
 }
   Future<void> benchmark() async {
    if(busy||downloader!=null)return;
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>BenchmarkScreen(
      clips:clips,onSave:()=>Native.save(clips))));
    if(mounted)setState((){});
  }
  Future<void> settings()async{
  if(busy||downloader!=null)return;
  await showAiSettings(context);
  watching=await Native.call<bool>('watchEnabled')??false;
  if(mounted)setState((){});
  await scan();
 }
 void toggle(Clip c){setState((){selecting=true;if(!selected.add(c.id))selected.remove(c.id);});}
 Future<void> deleteSelection()async{
  if(busy||downloader!=null||draining||scanning)return;
  final targets=clips.where((c)=>selected.contains(c.id)).toList();
  if(targets.isEmpty||!await confirmDeletion(context,targets.length,saved:page==1))return;
  if(!mounted)return;setState(()=>busy=true);
  final removedUris=<String>{};var removed=0;
  try{
   for(final c in targets){
    if(page==1){final uri=c.savedUri;await deleteSavedClip(c);removedUris.add(uri);c.inCollection=true;}
    else if(c.savedUri.isNotEmpty){c.inCollection=false;}
    else{
     final paths=[c.path,c.thumbnail].where((p)=>p.isNotEmpty&&!clips.any((other)=>other.id!=c.id&&(other.path==p||other.thumbnail==p))).toList();
     await Native.call('deleteLocalVideo',{'paths':paths});clips.remove(c);
    }
    selected.remove(c.id);removed++;
   }
  }catch(_){message('일부 영상을 삭제하지 못했어요. 남은 선택을 다시 시도해 주세요.');}
  finally{
   try{await Native.save(clips);if(removedUris.isNotEmpty)await syncDeletedReports(removedUris);}
   catch(_){message('삭제 결과 저장에 실패했어요.');}
   if(mounted)setState((){busy=false;if(selected.isEmpty)selecting=false;});
  }
  if(removed>0)message('$removed개 삭제했어요.');
 }
 Future<void> categorize(String value)async{
  if(busy)return;setState(()=>busy=true);
  try{for(final c in clips.where((c)=>selected.contains(c.id))){c.category=value;}await Native.save(clips);}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context){
  final shown=clips.where((c)=>(page==1?c.savedUri.isNotEmpty:c.inCollection)&&(category=='전체'||c.category==category)&&(c.name+' '+c.headline+' '+c.creator).toLowerCase().contains(query.toLowerCase())).toList();
  return Scaffold(appBar:AppBar(title:Row(children:[Container(width:30,height:30,decoration:const BoxDecoration(color:blue,shape:BoxShape.circle),child:const Icon(Icons.north_east,size:19,color:Colors.white)),const SizedBox(width:8),const Text('shorts / studio',style:TextStyle(fontSize:18,letterSpacing:-.7,fontWeight:FontWeight.w600))]),actions:[IconButton(tooltip:'벤치마킹 소재 탐색',onPressed:busy?null:benchmark,icon:const Icon(Icons.insights_outlined)),IconButton(tooltip:'저장된 MP4 예약·공개 업로드',
  onPressed:busy?null:()=>Navigator.push(context,MaterialPageRoute(
    builder:(_)=>YouTubeBatchPublishScreen(clips:clips))),
  icon:const Icon(Icons.schedule_send_outlined)),
  IconButton(tooltip:'유튜브 채널 설정',onPressed:busy?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>YouTubeSettingsScreen(clips:clips))),icon:const Icon(Icons.video_call_outlined)),IconButton(tooltip:'앱 설정',onPressed:settings,icon:const Icon(Icons.tune_rounded)),const SizedBox(width:8)]),body:SafeArea(child:RefreshIndicator(onRefresh:scan,child:CustomScrollView(slivers:[SliverPadding(padding:const EdgeInsets.fromLTRB(24,24,24,0),sliver:SliverToBoxAdapter(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Text('YOUR NEXT SHORT',style:TextStyle(fontSize:11,letterSpacing:2,color:muted)),const Spacer(),Text('${clips.length.toString().padLeft(2,'0')} CLIPS',style:const TextStyle(fontSize:11,color:muted))]),const SizedBox(height:16),Text(page==1?'완성된 순간.':'발견한 순간을,\n나만의 쇼츠로.',style:Theme.of(context).textTheme.headlineLarge),const SizedBox(height:18),Text(page==1?'저장한 영상을 다시 열고 다듬어 보세요.':'영상을 고르면 편집이 시작돼요.',style:const TextStyle(color:muted)),const SizedBox(height:24),Wrap(spacing:8,runSpacing:8,children:[FilledButton.icon(onPressed:busy?null:()=>action(()async{final raw=await Native.call<Map<dynamic,dynamic>>('pickVideo');if(raw!=null){final clip=Clip.fromJson(Map<String,dynamic>.from(raw));clip.category='기타';clips.insert(0,clip);await Native.save(clips);}}),icon:const Icon(Icons.add,size:18),label:const Text('영상 가져오기')),OutlinedButton.icon(onPressed:busy?null:addLink,icon:const Icon(Icons.link,size:18),label:const Text('링크 추가'))]),const SizedBox(height:12),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:busy||draining||scanning||downloader!=null?null:autoBatch,icon:const Icon(Icons.auto_awesome,size:18),label:const Text('혼합 영상 5개 자동 제작'))),const SizedBox(height:24),InkWell(onTap:settings,borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xfff5f9fc),borderRadius:BorderRadius.circular(18)),child:Row(children:[Icon(watching?Icons.sync:Icons.folder_outlined,color:blue,size:20),const SizedBox(width:12),Expanded(child:Text(watching?'폴더 자동 수집 켜짐 · 앱 실행 중':'폴더를 연결하면 새 영상을 자동으로',style:const TextStyle(fontSize:12))),const Icon(Icons.arrow_forward,size:18)]))),const SizedBox(height:28),Row(children:[Text(page==1?'저장함':'수집함',style:const TextStyle(fontSize:22)),const Spacer(),Text('${shown.length}개',style:const TextStyle(color:muted))]),const SizedBox(height:12),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[for(final value in libraryCategories)Padding(padding:const EdgeInsets.only(right:6),child:ChoiceChip(label:Text(value,style:const TextStyle(fontSize:12)),selected:category==value,onSelected:busy?null:(_)=>setState((){category=value;selected.clear();selecting=false;})))])),
 if(selecting)Wrap(spacing:8,runSpacing:4,crossAxisAlignment:WrapCrossAlignment.center,children:[Text('${selected.length}개 선택'),TextButton(onPressed:busy?null:()=>setState(()=>selected.addAll(shown.map((c)=>c.id))),child:const Text('전체 선택')),TextButton(onPressed:busy?null:()=>setState((){selected.clear();selecting=false;}),child:const Text('취소')),PopupMenuButton<String>(tooltip:'카테고리 변경',enabled:!busy&&selected.isNotEmpty,onSelected:categorize,itemBuilder:(_)=>[for(final value in libraryCategories.skip(1))PopupMenuItem(value:value,child:Text(value))],child:const Padding(padding:EdgeInsets.all(8),child:Text('분류 변경'))),TextButton.icon(onPressed:busy||selected.isEmpty?null:deleteSelection,icon:const Icon(Icons.delete_outline),label:const Text('선택 삭제'))])else TextButton(onPressed:busy?null:()=>setState(()=>selecting=true),child:const Text('선택 · 전체 삭제')),
 const SizedBox(height:16),TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(hintText:'영상 검색',prefixIcon:Icon(Icons.search,size:20))),const SizedBox(height:20),if(downloadStage.isNotEmpty)...[Row(children:[Expanded(child:Text(downloadStage,style:const TextStyle(fontSize:12,color:blue))),TextButton(onPressed:()=>downloader?.cancel(),child:const Text('취소'))]),LinearProgressIndicator(value:downloadProgress,minHeight:3)]else if(busy)const LinearProgressIndicator(minHeight:2)]))),if(shown.isEmpty)SliverFillRemaining(hasScrollBody:false,child:Padding(padding:const EdgeInsets.all(32),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.video_collection_outlined,size:48,color:Color(0xffc6c6c6)),const SizedBox(height:16),Text(query.isNotEmpty?'검색 결과가 없어요':page==1?'완성된 쇼츠가 여기에 모여요':'첫 번째 순간을 가져오세요',style:const TextStyle(fontSize:18)),const SizedBox(height:8),const Text('짧은 영상 하나면 충분해요.',style:TextStyle(color:muted)),if(query.isEmpty&&page==0)TextButton(onPressed:busy?null:()=>action(()async{await Native.call('importDemo');}),child:const Text('샘플 영상으로 시작 →'))]))),if(shown.isNotEmpty)SliverPadding(padding:const EdgeInsets.fromLTRB(24,0,24,24),sliver:SliverLayoutBuilder(builder:(context,constraints)=>SliverGrid(delegate:SliverChildBuilderDelegate((ctx,index)=>clipCard(shown[index]),childCount:shown.length),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:constraints.crossAxisExtent>650?4:2,crossAxisSpacing:12,mainAxisSpacing:20,childAspectRatio:.59))))]))),bottomNavigationBar:NavigationBar(backgroundColor:Colors.white,indicatorColor:const Color(0xffe5f5ff),selectedIndex:page,onDestinationSelected:(i){if(busy)return;setState((){page=i;selected.clear();selecting=false;});},destinations:const[NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'수집함'),NavigationDestination(icon:Icon(Icons.check_circle_outline_rounded),label:'저장함')]));
 }
 Widget clipCard(Clip c)=>InkWell(onLongPress:busy||downloader!=null?null:()=>toggle(c),onTap:busy||downloader!=null?null:(){if(selecting){toggle(c);}else{open(c);}},borderRadius:BorderRadius.circular(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(24),child:Stack(fit:StackFit.expand,children:[Container(color:ink,child:c.thumbnail.isNotEmpty?Image.file(File(c.thumbnail),fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.movie_outlined,color:Colors.white54,size:40)):const Center(child:Icon(Icons.link,color:Colors.white54,size:36))),if(selecting)Positioned(top:8,right:8,child:Icon(selected.contains(c.id)?Icons.check_circle:Icons.radio_button_unchecked,color:selected.contains(c.id)?blue:Colors.white,size:28)),const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.center,end:Alignment.bottomCenter,colors:[Colors.transparent,Colors.black87]))),Positioned(top:12,left:12,child:Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(99)),child:Text(c.ready?(c.savedUri.isEmpty?'편집 가능':'저장 완료'):(downloader!=null&&!c.ready?'다운로드 중':c.downloadError.isEmpty?'원본 연결':'다운로드 확인'),style:const TextStyle(fontSize:10)))),Positioned(bottom:14,left:14,right:14,child:Row(children:[const Icon(Icons.play_arrow_rounded,color:Colors.white,size:28),const Spacer(),Text(c.ready?'${c.duration.toStringAsFixed(0)}s':'LINK',style:const TextStyle(color:Colors.white,fontSize:12))]))]))),const SizedBox(height:10),Text(c.headline.isEmpty?c.name:c.headline,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w500)),Text('${c.category} · ${c.creator.isEmpty?'기기에서 가져옴':c.creator}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,color:muted))]));
}


// Invoked by a WorkManager-owned FlutterEngine; no Activity or Navigator.
@pragma('vm:entry-point')
void dailyHeadlessMain(){
  WidgetsFlutterBinding.ensureInitialized();
  unawaited(daily_worker.DailyHeadlessRunner().run());
}
