import 'discovery.dart';

// Persisted with the batch report; never contains credentials or signed media URLs.
class DiscoveryStore {
 final queue=<VideoCandidate>[];
 final seen=<String>{};
 final metrics=<String,Map<String,int>>{};
 final accounts=<String,Map<String,int>>{};
 final feedback=<String,Map<String,dynamic>>{};
 static String account(String url)=>Uri.parse(url).pathSegments.first;
 Map<String,int> stats(String query)=>metrics.putIfAbsent(query,()=>{});
 void count(String query,String stage){final s=stats(query);s[stage]=(s[stage]??0)+1;}
 void accountCount(String url,String stage){final s=accounts.putIfAbsent(account(url),()=>{});s[stage]=(s[stage]??0)+1;}
 double preference({String? query,String? creator}){
  var positive=0,negative=0;
  for(final value in feedback.values){
   final url=value['url'];
   if(query!=null&&value['query']!=query)continue;
   if(creator!=null&&(url is! String||account(url)!=creator))continue;
   if(value['label']=='괜찮음')positive++;
   else if(['재미없음','편집본','AI 의심'].contains(value['label']))negative++;
  }
  return (positive+1)/(positive+negative+2);
 }
 bool rejected(String url)=>['재미없음','편집본','AI 의심'].contains(feedback[MixedDiscovery.videoId(url)]?['label']);
 double candidateRank(VideoCandidate c)=>rate(accounts[account(c.url)])*.4+preference(creator:account(c.url))*.4+preference(query:c.query)*.2;
 double rate(Map<String,int>? s)=>((s?['saved']??0)+1)/((s?['attempted']??0)+2);
 Set<String> get excluded=>{...seen,...queue.map((c)=>MixedDiscovery.videoId(c.url)!).toSet()};
 void add(List<VideoCandidate> items){
  final ids=excluded;
  for(final c in items){final id=MixedDiscovery.videoId(c.url);if(id!=null&&ids.add(id)){queue.add(c);count(c.query,'found');}}
 }
 VideoCandidate? next(String topic,{Set<String> skip=const {}}){
  final candidates=queue.where((c)=>c.topic==topic&&!skip.contains(MixedDiscovery.videoId(c.url))&&!rejected(c.url)).toList();
  if(candidates.isEmpty)return null;
  candidates.sort((a,b)=>candidateRank(b).compareTo(candidateRank(a)));
  return candidates.first;
 }
 void finish(VideoCandidate c){queue.removeWhere((e)=>MixedDiscovery.videoId(e.url)==MixedDiscovery.videoId(c.url));seen.add(MixedDiscovery.videoId(c.url)!);}
 List<String> preferredAccounts(int topic){
  final values=<String>{};
  for(final entry in feedback.values){
   final url=entry['url'];
   if(entry['label']!='괜찮음'||url is! String)continue;
   if(entry['topic']!=MixedDiscovery.topics[topic]&&!MixedDiscovery.queries[topic].contains(entry['query']))continue;
   final creator=account(url);
   if(RegExp(r'^@[A-Za-z0-9_.]+$').hasMatch(creator)&&preference(creator:creator)>.5)values.add(creator);
  }
  final ranked=values.toList()..sort((a,b)=>(preference(creator:b)*.6+rate(accounts[b])*.4).compareTo(preference(creator:a)*.6+rate(accounts[a])*.4));
  return ranked;
 }
 String? targetedQuery(int topic,Set<String> used){
  for(final creator in preferredAccounts(topic)){
   final query='site:tiktok.com/$creator ${MixedDiscovery.queries[topic].first} -compilation -montage -edit';
   if(!used.contains(query))return query;
  }
  return null;
 }
 String queryFor(int topic,Set<String> used){
  final available=MixedDiscovery.queries[topic].where((q)=>!used.contains(q)).toList();
  // Untried queries come first, then rank by observed save yield.
  available.sort((a,b){final aN=stats(a)['searches']??0,bN=stats(b)['searches']??0;if(aN==0||bN==0)return aN.compareTo(bN);return (rate(metrics[b])*.5+preference(query:b)*.5).compareTo(rate(metrics[a])*.5+preference(query:a)*.5);});
  return available.first;
 }
 Map<String,dynamic> toJson()=>{'queue':queue.map((c)=>c.toJson()).toList(),'seen':seen.toList(),'metrics':metrics,'accounts':accounts,'feedback':feedback};
 factory DiscoveryStore.fromJson(Map data){
  final store=DiscoveryStore();
  store.seen.addAll((data['seen'] as List? ?? []).whereType<String>());
  for(final raw in (data['queue'] as List? ?? [])){
   if(raw is! Map)continue;
   try{final c=VideoCandidate.fromJson(raw);if(MixedDiscovery.videoUrl(c.url)!=null&&!store.seen.contains(MixedDiscovery.videoId(c.url)))store.add([c]);}catch(_){}
  }
  for(final entry in [(data['metrics'],store.metrics),(data['accounts'],store.accounts)]){
   if(entry.$1 is Map){(entry.$1 as Map).forEach((key,value){if(key is String&&value is Map)entry.$2[key]={for(final e in value.entries)if(e.key is String&&e.value is num)e.key as String:(e.value as num).toInt()};});}
  }
  if(data['feedback'] is Map){(data['feedback'] as Map).forEach((key,value){if(key is String&&value is Map)store.feedback[key]=Map<String,dynamic>.from(value);});}
  return store;
 }
 DiscoveryStore();
}
