import 'discovery.dart';

// Persisted with the batch report; never contains credentials or signed media URLs.
class DiscoveryStore {
 final queue=<VideoCandidate>[];
 final seen=<String>{};
 final metrics=<String,Map<String,int>>{};
 final accounts=<String,Map<String,int>>{};
 final feedback=<String,Map<String,dynamic>>{};
 static String account(String url)=>Uri.parse(url).pathSegments.first;
 Map<String,int> stats(String query)=>metrics.putIfAbsent(query,()=>{});
 void count(String query,String stage){final s=stats(query);s[stage]=(s[stage]??0)+1;}
 void accountCount(String url,String stage){final s=accounts.putIfAbsent(account(url),()=>{});s[stage]=(s[stage]??0)+1;}
 double rate(Map<String,int>? s)=>((s?['saved']??0)+1)/((s?['attempted']??0)+2);
 Set<String> get excluded=>{...seen,...queue.map((c)=>MixedDiscovery.videoId(c.url)!).toSet()};
 void add(List<VideoCandidate> items){
  final ids=excluded;
  for(final c in items){final id=MixedDiscovery.videoId(c.url);if(id!=null&&ids.add(id)){queue.add(c);count(c.query,'found');}}
 }
 VideoCandidate? next(String topic){
  final candidates=queue.where((c)=>c.topic==topic).toList();
  if(candidates.isEmpty)return null;
  candidates.sort((a,b)=>rate(accounts[account(b.url)]).compareTo(rate(accounts[account(a.url)])));
  return candidates.first;
 }
 void finish(VideoCandidate c){queue.removeWhere((e)=>MixedDiscovery.videoId(e.url)==MixedDiscovery.videoId(c.url));seen.add(MixedDiscovery.videoId(c.url)!);}
 String queryFor(int topic,Set<String> used){
  final available=MixedDiscovery.queries[topic].where((q)=>!used.contains(q)).toList();
  // Untried queries come first, then rank by observed save yield.
  available.sort((a,b){final aN=stats(a)['searches']??0,bN=stats(b)['searches']??0;if(aN==0||bN==0)return aN.compareTo(bN);return rate(metrics[b]).compareTo(rate(metrics[a]));});
  return available.first;
 }
 Map<String,dynamic> toJson()=>{'queue':queue.map((c)=>c.toJson()).toList(),'seen':seen.toList(),'metrics':metrics,'accounts':accounts,'feedback':feedback};
 factory DiscoveryStore.fromJson(Map data){
  final store=DiscoveryStore();
  store.seen.addAll((data['seen'] as List? ?? []).whereType<String>());
  for(final raw in (data['queue'] as List? ?? [])){
   if(raw is! Map)continue;
   try{final c=VideoCandidate.fromJson(raw);if(MixedDiscovery.videoUrl(c.url)!=null&&!store.seen.contains(MixedDiscovery.videoId(c.url)))store.add([c]);}catch(_){}
  }
  for(final entry in [(data['metrics'],store.metrics),(data['accounts'],store.accounts)]){
   if(entry.$1 is Map){(entry.$1 as Map).forEach((key,value){if(key is String&&value is Map)entry.$2[key]={for(final e in value.entries)if(e.key is String&&e.value is num)e.key as String:(e.value as num).toInt()};});}
  }
  if(data['feedback'] is Map){(data['feedback'] as Map).forEach((key,value){if(key is String&&value is Map)store.feedback[key]=Map<String,dynamic>.from(value);});}
  return store;
 }
 DiscoveryStore();
}
