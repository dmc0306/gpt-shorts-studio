import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'bridge.dart';
import 'youtube_channel.dart';
import 'youtube_upload.dart';

/// Read-only diagnostic. Tokens are used locally and never included in the report.
class YouTubeAuthorizationProbe {
  YouTubeAuthorizationProbe({http.Client Function()? clientFactory})
      : _factory = clientFactory ?? http.Client.new;
  final http.Client Function() _factory;
  Future<Map<String, dynamic>> run({bool includeUpload = false, bool selectAccount = true}) async {
    final report = <String, dynamic>{'method': 'android_authorization_client', 'uploadAttempted': false, 'scopeMode': includeUpload ? 'read_upload' : 'readonly', 'selectAccount': selectAccount};
    http.Client? client;
    try {
      final raw = await Native.call<Map>('youtubeAuthorizationProbe', {'includeUpload': includeUpload, 'selectAccount': selectAccount});
      if (raw == null || raw['accessToken'] is! String || (raw['accessToken'] as String).isEmpty) {
        throw const YouTubeFailure('권한 응답에서 토큰을 받지 못했어요.');
      }
      copyMetadata(raw, report);
      // No raw native response, account email, access token or OAuth URL in reports.
      client = _factory();
      final channel = await readYouTubeChannel(client, raw['accessToken'] as String);
      report.addAll({'stage': 'complete', 'kind': 'single', 'channelId': channel.id,
        'channelTitle': channel.title, 'message': '채널 조회 성공. 원하는 채널인지 이름과 ID를 확인하세요.'});
    } on PlatformException catch (e) {
      final details = e.details;
      if (details is Map) copyMetadata(details, report);
      report.addAll({'stage': 'authorization', 'kind': 'error', 'code': e.code,
        'message': nativeMessage(e.code)});
    } on YouTubeChannelLookupFailure catch (e) {
      report.addAll({'stage': 'channel_lookup', 'kind': e.diagnostic['kind'], 'message': e.message});
      report['count'] = e.diagnostic['count'];
    } on YouTubeFailure catch (e) {
      report.addAll({'stage': 'channel_lookup', 'kind': 'error', 'message': e.message});
    } catch (_) {
      report.addAll({'stage': 'channel_lookup', 'kind': 'error', 'message': '채널 조회 요청에 실패했어요. 인터넷 연결을 확인해 주세요.'});
    } finally { client?.close(); }
    return report;
  }

  static void copyMetadata(Map raw, Map<String, dynamic> report) {
    for (final key in ['resolutionShown', 'callbackReceived', 'resultDataPresent']) {
      if (raw[key] is bool) report[key] = raw[key];
    }
    for (final key in ['activityResultCode', 'googleStatusCode']) {
      if (raw[key] is int) report[key] = raw[key];
    }
    if (const ['authorize_task', 'activity_result', 'app_cancel', 'activity_destroy'].contains(raw['origin'])) report['origin'] = raw['origin'];
    if (raw['packageName'] is String && RegExp(r'^[A-Za-z0-9_.]+$').hasMatch(raw['packageName'] as String)) report['packageName'] = raw['packageName'];
    if (raw['playServicesVersion'] is String && RegExp(r'^[A-Za-z0-9. ()_-]{1,100}$').hasMatch(raw['playServicesVersion'] as String)) report['playServicesVersion'] = raw['playServicesVersion'];
    if (raw['signingSha1'] is List) report['signingSha1'] = (raw['signingSha1'] as List).whereType<String>().where((s) => RegExp(r'^(?:[A-Fa-f0-9]{2}:){19}[A-Fa-f0-9]{2}$').hasMatch(s)).toList();
  }

  static String nativeMessage(String code) => switch(code) {
    'AUTH_NATIVE_10' => 'Android OAuth의 패키지 이름·설치 APK 서명 SHA-1을 확인해 주세요.',
    'AUTH_NATIVE_7' => 'Google 인증 네트워크 연결을 확인해 주세요.',
    'AUTH_NATIVE_APP_CANCELLED' || 'AUTH_NATIVE_CANCELLED' => '앱에서 권한 테스트를 중단했어요.',
    'AUTH_NATIVE_16' || 'AUTH_NATIVE_12501' => 'Google 권한 절차가 완료되지 않았어요. 직접 취소했는지는 알 수 없어요.',
    'AUTH_NATIVE_NO_RESULT' => 'Google 화면이 인증 결과 없이 종료됐어요. 자동 종료 원인은 아직 확인되지 않았어요.',
    'AUTH_NATIVE_12500' => 'Google 인증이 실패했어요. Android OAuth 설정과 계정 접근 상태를 확인해야 해요.',
    'AUTH_NATIVE_BUSY' => '다른 권한 요청이 진행 중이에요.',
    'AUTH_NATIVE_TIMEOUT' => '권한 요청 시간이 지났어요. 다시 시도해 주세요.',
    'AUTH_NATIVE_SCOPE' => '이번 테스트에서 요청한 YouTube 권한을 허용해 주세요.',
    'AUTH_NATIVE_RESOLUTION' => 'Google 권한 선택 화면을 열지 못했어요.',
    _ => 'Google 권한 요청에 실패했어요. Google Play 서비스와 Android OAuth 설정을 확인해 주세요.',
  };
}

class YouTubeProbeScreen extends StatefulWidget {
  const YouTubeProbeScreen({super.key});
  @override State<YouTubeProbeScreen> createState() => _YouTubeProbeState();
}

class _YouTubeProbeState extends State<YouTubeProbeScreen> {
  bool busy = false, selectAccount = true;
  Map<String, dynamic>? report;
  @override void dispose() {
    if (busy) Native.call('cancelYoutubeAuthorizationProbe').catchError((_) => null);
    super.dispose();
  }
  Future<void> run({bool includeUpload = false}) async {
    setState(() { busy = true; report = null; });
    final result = await YouTubeAuthorizationProbe().run(includeUpload: includeUpload, selectAccount: selectAccount);
    if (mounted) setState(() { report = result; busy = false; });
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Android 채널 연결 테스트')),
    body: ListView(padding: const EdgeInsets.all(24), children: [
      const Text('원하는 브랜드 채널이 보이나요?', style: TextStyle(fontSize: 24)),
      const SizedBox(height: 12),
      const Text('Google 로그인을 먼저 거치지 않고 YouTube 권한을 직접 요청해요. 계정 선택을 요청하지만 브랜드 채널 표시 여부는 Google이 결정합니다.'),
      const SizedBox(height: 12),
      const Text('먼저 조회 권한만 테스트하고, 필요하면 업로드 권한을 함께 요청해 비교하세요. 두 경우 모두 채널 조회만 실행하고 영상 업로드·설정 변경은 하지 않습니다.'),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: busy ? null : () => run(), icon: const Icon(Icons.account_tree_outlined),
        label: const Text('조회 권한만 테스트')),
      OutlinedButton(onPressed: busy ? null : () => run(includeUpload: true), child: const Text('조회 + 업로드 권한 비교')),
      SwitchListTile(contentPadding: EdgeInsets.zero,
        title: const Text('계정 선택창 요청'),
        subtitle: const Text('자동 종료가 반복되면 끈 상태에서도 비교할 수 있어요.'),
        value: selectAccount, onChanged: busy ? null : (value) => setState(() => selectAccount = value)),
      if (busy) ...[
        const LinearProgressIndicator(),
        TextButton(onPressed: () => Native.call('cancelYoutubeAuthorizationProbe'), child: const Text('테스트 중단')),
      ],
      if (report != null) ...[
        const Divider(height: 32),
        Text(report!['message'] as String),
        if (report!['resolutionShown'] != null)
          Text('Google 선택·동의 화면: ${report!['resolutionShown'] == true ? '표시됨' : '표시되지 않음'}'),
        if (report!['channelTitle'] != null) Text(report!['channelTitle'] as String,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        if (report!['channelId'] != null) SelectableText(report!['channelId'] as String),
        if (report!['code'] != null) Text(report!['code'] as String),
        if (report!['googleStatusCode'] != null) Text('Google 상태 코드: ${report!['googleStatusCode']}'),
        ExpansionTile(title: const Text('진단 상세 · 토큰 제외'), children: [
          SelectableText(const JsonEncoder.withIndent('  ').convert(report)),
        ]),
        const SizedBox(height: 12),
        const Text('화면에 원하는 브랜드 채널 선택지가 나왔는지도 함께 알려주세요. 앱은 Google 화면의 선택지 목록을 읽을 수 없어요.'),
        TextButton.icon(onPressed: () async {
          await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(report)));
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('테스트 결과를 복사했어요.')));
        }, icon: const Icon(Icons.copy), label: const Text('테스트 결과 복사')),
      ],
    ]),
  );
}
