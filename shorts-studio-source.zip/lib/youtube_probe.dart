import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'bridge.dart';
import 'youtube_channel.dart';
import 'youtube_upload.dart';

/// Read-only diagnostic. Tokens are used locally and never included in the report.
class YouTubeAuthorizationProbe {
  YouTubeAuthorizationProbe({http.Client Function()? clientFactory})
      : _factory = clientFactory ?? http.Client.new;
  final http.Client Function() _factory;
  Future<Map<String, dynamic>> run() async {
    final report = <String, dynamic>{'method': 'android_authorization_client', 'uploadAttempted': false};
    http.Client? client;
    try {
      final raw = await Native.call<Map>('youtubeAuthorizationProbe');
      if (raw == null || raw['accessToken'] is! String || (raw['accessToken'] as String).isEmpty) {
        throw const YouTubeFailure('권한 응답에서 토큰을 받지 못했어요.');
      }
      report['resolutionShown'] = raw['resolutionShown'] == true;
      // No raw native response, account email, access token or OAuth URL in reports.
      client = _factory();
      final channel = await readYouTubeChannel(client, raw['accessToken'] as String);
      report.addAll({'stage': 'complete', 'kind': 'single', 'channelId': channel.id,
        'channelTitle': channel.title, 'message': '채널 조회 성공. 원하는 채널인지 이름과 ID를 확인하세요.'});
    } on PlatformException catch (e) {
      final details = e.details;
      if (details is Map) report['resolutionShown'] = details['resolutionShown'] == true;
      report.addAll({'stage': 'authorization', 'kind': 'error', 'code': e.code,
        'message': nativeMessage(e.code)});
    } on YouTubeChannelLookupFailure catch (e) {
      report.addAll({'stage': 'channel_lookup', 'kind': e.diagnostic['kind'], 'message': e.message});
      report['count'] = e.diagnostic['count'];
    } on YouTubeFailure catch (e) {
      report.addAll({'stage': 'channel_lookup', 'kind': 'error', 'message': e.message});
    } catch (_) {
      report.addAll({'stage': 'channel_lookup', 'kind': 'error', 'message': '채널 조회 요청에 실패했어요. 인터넷 연결을 확인해 주세요.'});
    } finally { client?.close(); }
    return report;
  }

  static String nativeMessage(String code) => switch(code) {
    'AUTH_NATIVE_10' => 'Android OAuth의 패키지 이름·설치 APK 서명 SHA-1을 확인해 주세요.',
    'AUTH_NATIVE_7' => 'Google 인증 네트워크 연결을 확인해 주세요.',
    'AUTH_NATIVE_CANCELLED' || 'AUTH_NATIVE_16' => '권한 테스트를 중단했어요.',
    'AUTH_NATIVE_BUSY' => '다른 권한 요청이 진행 중이에요.',
    'AUTH_NATIVE_TIMEOUT' => '권한 요청 시간이 지났어요. 다시 시도해 주세요.',
    'AUTH_NATIVE_SCOPE' => '채널 조회·업로드 권한을 모두 허용해 주세요.',
    'AUTH_NATIVE_RESOLUTION' => 'Google 권한 선택 화면을 열지 못했어요.',
    _ => 'Google 권한 요청에 실패했어요. Google Play 서비스와 Android OAuth 설정을 확인해 주세요.',
  };
}

class YouTubeProbeScreen extends StatefulWidget {
  const YouTubeProbeScreen({super.key});
  @override State<YouTubeProbeScreen> createState() => _YouTubeProbeState();
}

class _YouTubeProbeState extends State<YouTubeProbeScreen> {
  bool busy = false;
  Map<String, dynamic>? report;
  @override void dispose() {
    if (busy) Native.call('cancelYoutubeAuthorizationProbe').catchError((_) => null);
    super.dispose();
  }
  Future<void> run() async {
    setState(() { busy = true; report = null; });
    final result = await YouTubeAuthorizationProbe().run();
    if (mounted) setState(() { report = result; busy = false; });
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Android 채널 연결 테스트')),
    body: ListView(padding: const EdgeInsets.all(24), children: [
      const Text('원하는 브랜드 채널이 보이나요?', style: TextStyle(fontSize: 24)),
      const SizedBox(height: 12),
      const Text('Google 로그인을 먼저 거치지 않고 YouTube 권한을 직접 요청해요. 계정 선택을 요청하지만 브랜드 채널 표시 여부는 Google이 결정합니다.'),
      const SizedBox(height: 12),
      const Text('조회·업로드 권한을 요청한 뒤 채널 조회만 실행해요. 영상 업로드와 자동 업로드 설정 변경은 하지 않습니다. PC·인증 서버는 필요 없어요.'),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: busy ? null : run, icon: const Icon(Icons.account_tree_outlined),
        label: const Text('계정 선택 후 채널 조회')),
      if (busy) ...[
        const LinearProgressIndicator(),
        TextButton(onPressed: () => Native.call('cancelYoutubeAuthorizationProbe'), child: const Text('테스트 중단')),
      ],
      if (report != null) ...[
        const Divider(height: 32),
        Text(report!['message'] as String),
        if (report!['resolutionShown'] != null)
          Text('Google 선택·동의 화면: ${report!['resolutionShown'] == true ? '표시됨' : '표시되지 않음'}'),
        if (report!['channelTitle'] != null) Text(report!['channelTitle'] as String,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        if (report!['channelId'] != null) SelectableText(report!['channelId'] as String),
        if (report!['code'] != null) Text(report!['code'] as String),
        const SizedBox(height: 12),
        const Text('화면에 원하는 브랜드 채널 선택지가 나왔는지도 함께 알려주세요. 앱은 Google 화면의 선택지 목록을 읽을 수 없어요.'),
        TextButton.icon(onPressed: () async {
          await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(report)));
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('테스트 결과를 복사했어요.')));
        }, icon: const Icon(Icons.copy), label: const Text('테스트 결과 복사')),
      ],
    ]),
  );
}
