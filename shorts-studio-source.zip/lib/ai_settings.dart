import 'package:flutter/material.dart';
import 'ai.dart';
import 'bridge.dart';
import 'input_dialog.dart';
import 'theme.dart';

Future<bool> showAiSettings(BuildContext context) async {
 final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
 if(!context.mounted)return false;
 final gemini=TextEditingController(text:settings['key'] as String? ?? '');
 final search=TextEditingController(text:settings['searchKey'] as String? ?? '');
 final model=TextEditingController(text:settings['model'] as String? ?? GeminiCaptions.defaultModel);
 String? error;bool saving=false;
 return await showDialog<bool>(context:context,builder:(routeContext)=>ManagedInputDialog(controllers:[gemini,search,model],builder:(ctx)=>StatefulBuilder(builder:(ctx,refresh)=>AlertDialog(
  title:const Text('AI 설정'),
  content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
   const Text('영상 검색 · Tavily',style:TextStyle(fontSize:15,fontWeight:FontWeight.bold)),
   const Text('Researcher 무료 요금제: 월 1,000크레딧, 카드 불필요. 기본 검색 3회로 혼합 주제를 찾아요. 유료 결제·종량제는 켜지 마세요.',style:TextStyle(fontSize:12,color:muted)),
   const SelectableText('https://app.tavily.com',style:TextStyle(fontSize:12,color:blue)),
   TextField(controller:search,enabled:!saving,obscureText:true,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'Tavily 검색 API 키',hintText:'tvly-… · 자동 제작에 필요')),
   const SizedBox(height:18),const Text('제목·자막 생성 · Gemini',style:TextStyle(fontSize:15,fontWeight:FontWeight.bold)),
   const SelectableText('https://aistudio.google.com/apikey',style:TextStyle(fontSize:12,color:blue)),
   TextField(controller:gemini,enabled:!saving,obscureText:true,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'Gemini API 키')),
   TextField(controller:model,enabled:!saving,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'제목·자막 모델',helperText:'추천: gemini-3.5-flash-lite')),
   TextButton(onPressed:saving?null:()=>model.text=GeminiCaptions.defaultModel,child:const Text('추천 모델로 변경')),
   const Text('키는 이 기기에 암호화해 저장해요. 비워서 저장하면 해당 키를 삭제해요. 검색어는 Tavily로, 원본 영상·소리는 Google로 전송돼요. Gemini는 결제를 연결하지 않은 프로젝트 키를 사용하세요. 무료 사용량 한도가 적용돼요.',style:TextStyle(fontSize:12,color:muted)),
   if(error!=null)Padding(padding:const EdgeInsets.only(top:10),child:Text(error!,style:const TextStyle(fontSize:12,color:Colors.red))),
  ])),
  actions:[TextButton(onPressed:saving?null:()=>Navigator.pop(ctx,false),child:const Text('취소')),FilledButton(onPressed:saving?null:()async{
   final name=model.text.trim();
   if(!RegExp(r'^gemini-[a-zA-Z0-9.-]+$').hasMatch(name)){refresh(()=>error='Gemini 모델 이름을 확인해 주세요.');return;}
   refresh((){saving=true;error=null;});
   try{
    await Native.call('saveAiSettings',{'key':gemini.text.trim(),'searchKey':search.text.trim(),'model':name});
    if(ctx.mounted)Navigator.pop(ctx,true);
   }catch(_){if(ctx.mounted)refresh((){saving=false;error='설정을 저장하지 못했어요. 다시 시도해 주세요.';});}
  },child:Text(saving?'저장 중…':'저장'))],
 ))))??false;
}
