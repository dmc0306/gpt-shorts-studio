import 'package:flutter/material.dart';
import 'ai.dart';
import 'bridge.dart';
import 'input_dialog.dart';
import 'theme.dart';

Future<bool> showAiSettings(BuildContext context) async {
 final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
 bool watching=false;
 try{watching=await Native.call<bool>('watchEnabled')??false;}catch(_){/* Folder support is optional. */}
 if(!context.mounted)return false;
 final gemini=TextEditingController(text:settings['key'] as String? ?? '');
 final search=TextEditingController(text:settings['searchKey'] as String? ?? '');
 final model=TextEditingController(text:settings['model'] as String? ?? GeminiCaptions.defaultModel);
 String? error;bool saving=false;
 return await showDialog<bool>(context:context,builder:(routeContext)=>ManagedInputDialog(controllers:[gemini,search,model],builder:(ctx)=>StatefulBuilder(builder:(ctx,refresh)=>AlertDialog(
  title:const Text('앱 설정'),
  content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
   const Text('영상 검색 · Tavily',style:TextStyle(fontSize:15,fontWeight:FontWeight.bold)),
   const Text('혼합 제작에서 부족한 주제만 검색해요. 실행당 검색 최대 9회. 요금제·잔여 크레딧은 Tavily 계정에서 확인하세요.',style:TextStyle(fontSize:12,color:muted)),
   const SelectableText('https://app.tavily.com',style:TextStyle(fontSize:12,color:blue)),
   TextField(controller:search,enabled:!saving,obscureText:true,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'Tavily 검색 API 키',hintText:'tvly-… · 자동 제작에 필요')),
   const SizedBox(height:18),const Text('제목·자막 생성 · Gemini',style:TextStyle(fontSize:15,fontWeight:FontWeight.bold)),
   const SelectableText('https://aistudio.google.com/apikey',style:TextStyle(fontSize:12,color:blue)),
   TextField(controller:gemini,enabled:!saving,obscureText:true,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'Gemini API 키')),
   TextField(controller:model,enabled:!saving,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'제목·자막 모델',helperText:'추천: gemini-3.5-flash-lite')),
   TextButton(onPressed:saving?null:()=>model.text=GeminiCaptions.defaultModel,child:const Text('추천 모델로 변경')),
   const Text('키는 이 기기에 암호화해 저장해요. 비워서 저장하면 해당 키를 삭제해요. 검색어는 Tavily로, 원본 영상·소리는 Google로 전송돼요. Gemini는 결제를 연결하지 않은 프로젝트 키를 사용하세요. 무료 사용량 한도가 적용돼요.',style:TextStyle(fontSize:12,color:muted)),
   const Text('Gemini 무료 티어의 영상·소리는 제품 개선에 사용될 수 있어요.',style:TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:20),const Divider(),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('폴더 자동 수집',style:TextStyle(fontSize:15)),subtitle:Text(watching?'켜짐':'꺼짐',style:const TextStyle(fontSize:12)),children:[
    const Text('앱을 열어 둔 동안 선택한 폴더를 15초마다 확인해요. 하위 폴더는 포함하지 않아요.',style:TextStyle(fontSize:12,color:muted)),
    TextButton.icon(onPressed:saving?null:()async{
     refresh(()=>saving=true);
     try{final enabled=await Native.call<bool>('chooseFolder');if(ctx.mounted)refresh(()=>watching=enabled==true||watching);}catch(_){if(ctx.mounted)refresh(()=>error='수집 폴더를 연결하지 못했어요.');}
     finally{if(ctx.mounted)refresh(()=>saving=false);}
    },icon:const Icon(Icons.folder_open),label:Text(watching?'폴더 변경':'폴더 연결')),
    if(watching)TextButton(onPressed:saving?null:()async{
     refresh(()=>saving=true);
     try{await Native.call('stopWatching');if(ctx.mounted)refresh(()=>watching=false);}catch(_){if(ctx.mounted)refresh(()=>error='자동 수집을 끄지 못했어요.');}
     finally{if(ctx.mounted)refresh(()=>saving=false);}
    },child:const Text('폴더 수집 끄기')),
   ]),
   if(error!=null)Padding(padding:const EdgeInsets.only(top:10),child:Text(error!,style:const TextStyle(fontSize:12,color:Colors.red))),
  ])),
  actions:[TextButton(onPressed:saving?null:()=>Navigator.pop(ctx,false),child:const Text('취소')),FilledButton(onPressed:saving?null:()async{
   final name=model.text.trim();
   if(!RegExp(r'^gemini-[a-zA-Z0-9.-]+$').hasMatch(name)){refresh(()=>error='Gemini 모델 이름을 확인해 주세요.');return;}
   refresh((){saving=true;error=null;});
   try{
    await Native.call('saveAiSettings',{'key':gemini.text.trim(),'searchKey':search.text.trim(),'model':name});
    if(ctx.mounted)Navigator.pop(ctx,true);
   }catch(_){if(ctx.mounted)refresh((){saving=false;error='설정을 저장하지 못했어요. 다시 시도해 주세요.';});}
  },child:Text(saving?'저장 중…':'저장'))],
 ))))??false;
}
