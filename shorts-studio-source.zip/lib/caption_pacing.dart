import 'dart:math' as math;
import 'model.dart';

int captionLimit(double duration)=>(duration/6).ceil().clamp(1,5);
// Enforce sparse AI cues locally without another model request or shifting events.
List<TimedCaption> sparseCaptions(List<TimedCaption> input,double duration){
 if(input.isEmpty)return [];
 final limit=captionLimit(duration);
 final chosen=input.length<=limit?input:[for(var i=0;i<limit;i++)input[limit==1?input.length~/2:(i*(input.length-1)/(limit-1)).round()]];
 final result=<TimedCaption>[];var budget=duration*.4;
 for(final cue in chosen){
  if(result.isNotEmpty&&cue.start-result.last.end<1.5)continue;
  final length=math.min(math.min(cue.end-cue.start,2.5),budget);
  if(length<.2)continue;
  result.add(TimedCaption(start:cue.start,end:cue.start+length,text:cue.text,position:cue.position,avoid:List.of(cue.avoid)));
  budget-=length;
 }
 return result;
}
