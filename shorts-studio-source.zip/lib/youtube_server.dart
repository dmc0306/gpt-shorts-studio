import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'bridge.dart';
import 'youtube_pc.dart';
import 'youtube_upload.dart';

/// Single-owner HTTPS broker. Refresh credentials never enter the app.
class YouTubeServer extends YouTubePc {
  YouTubeServer({http.Client Function()? clientFactory})
      : _factory = clientFactory ?? http.Client.new;
  final http.Client Function() _factory;
  @override
  String get identityPrefix => 'server:';
  String? _cachedToken;
  DateTime? _expires;

  static Uri validateUrl(String url) {
    final uri = Uri.tryParse(url.trim());
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty ||
        uri.userInfo.isNotEmpty || uri.hasQuery || uri.hasFragment ||
        uri.port != 443 || (uri.path.isNotEmpty && uri.path != '/')) {
      throw const YouTubeFailure('인증 서버의 HTTPS 주소를 입력해 주세요. 경로·쿼리는 제외하세요.');
    }
    return uri.replace(path: '');
  }

  Future<void> configure(String url, String key) async {
    final uri = validateUrl(url);
    if (!RegExp(r'^[A-Za-z0-9_-]{43}$').hasMatch(key.trim())) {
      throw const YouTubeFailure('서버에서 발급한 43자 연결 키를 입력해 주세요.');
    }
    await Native.call('saveYoutubeServerConfig', {
      'json': jsonEncode({'url': uri.toString(), 'key': key.trim()}),
    });
    _cachedToken = null;
    _expires = null;
    identity = '';
  }

  Future<String> configuredUrl() async {
    final raw = await Native.call<String>('youtubeServerConfig');
    return raw == null ? '' : (jsonDecode(raw) as Map)['url'] as String;
  }

  @override
  Future<Map<String, dynamic>> request(String method, String path) async {
    final raw = await Native.call<String>('youtubeServerConfig');
    if (raw == null) throw const YouTubeFailure('인증 서버 주소와 연결 키를 먼저 설정해 주세요.');
    final config = jsonDecode(raw) as Map;
    final base = validateUrl(config['url'] as String);
    final client = _factory();
    try {
      final req = http.Request(method, base.replace(path: path))
        ..followRedirects = false
        ..headers['Authorization'] = 'Bearer ${config['key']}';
      final response = await http.Response.fromStream(
        await client.send(req).timeout(const Duration(seconds: 45)),
      ).timeout(const Duration(seconds: 45));
      if (response.statusCode == 401) {
        throw const YouTubeFailure('인증 서버 연결 키가 일치하지 않아요. 설정을 확인해 주세요. [AUTH_KEY]');
      }
      if (response.statusCode == 429) {
        throw const YouTubeFailure('인증 서버 요청이 많아요. 잠시 후 다시 시도해 주세요. [AUTH_RATE]');
      }
      if (response.statusCode != 200) {
        String code = '';
        try { code = (jsonDecode(response.body) as Map)['error'] as String? ?? ''; } catch (_) {}
        if (code.contains('YT_CHANNEL_COUNT')) {
          throw const YouTubeFailure('선택한 권한에서 채널 하나를 찾지 못했어요. 브랜드 계정을 다시 선택해 주세요. [YT_CHANNEL_COUNT]');
        }
        throw YouTubeFailure('인증 서버 요청에 실패했어요 (HTTP ${response.statusCode}). 채널을 다시 연결해 주세요. [AUTH_SERVER]');
      }
      return Map<String, dynamic>.from(jsonDecode(utf8.decode(response.bodyBytes)) as Map);
    } on TimeoutException {
      throw const YouTubeFailure('인증 서버 응답이 늦어요. 잠시 후 다시 시도해 주세요. [AUTH_TIMEOUT]');
    } on http.ClientException {
      throw const YouTubeFailure('인증 서버에 연결하지 못했어요. 주소와 인터넷 연결을 확인해 주세요. [AUTH_NETWORK]');
    } on FormatException {
      throw const YouTubeFailure('인증 서버 응답 형식이 올바르지 않아요. [AUTH_RESPONSE]');
    } finally { client.close(); }
  }

  @override
  Future<void> connect() async {
    _cachedToken = null;
    _expires = null;
    await super.connect();
  }

  @override
  Future<String> token() async {
    if (_cachedToken != null && _expires != null &&
        _expires!.isAfter(DateTime.now().add(const Duration(seconds: 90)))) {
      return _cachedToken!;
    }
    final data = await request('POST', '/api/token');
    final token = data['access_token'], id = data['identity'], expires = data['expires'];
    if (token is! String || token.isEmpty || id is! String ||
        !id.startsWith(identityPrefix) || expires is! num || !expires.isFinite) {
      throw const YouTubeFailure('인증 서버 토큰 응답을 확인하지 못했어요. [AUTH_RESPONSE]');
    }
    final expiry = DateTime.fromMillisecondsSinceEpoch((expires * 1000).round());
    if (!expiry.isAfter(DateTime.now())) {
      throw const YouTubeFailure('인증 토큰이 만료됐어요. 채널을 다시 연결해 주세요. [AUTH_EXPIRED]');
    }
    identity = id;
    _cachedToken = token;
    _expires = expiry;
    return token;
  }

  @override
  Future<void> disconnect() async {
    try { await super.disconnect(); }
    finally { _cachedToken = null; _expires = null; identity = ''; }
  }
}
