import 'package:flutter/material.dart';
import 'model.dart';
import 'youtube.dart';
import 'youtube_settings.dart';

class YouTubePanel extends StatefulWidget {
  const YouTubePanel({
    super.key,
    required this.clip,
    required this.onBusyChanged,
  });
  final Clip clip;
  final void Function(bool) onBusyChanged;
  @override
  State<YouTubePanel> createState() => YouTubePanelState();
}

class YouTubePanelState extends State<YouTubePanel> {
  final youtube = YouTube.instance;
  String? videoId,error,requestMode,scheduledAt;
  bool pending = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      await youtube.loadSettings();
      final state = widget.clip.savedUri.isEmpty
          ? <String, dynamic>{}
          : await youtube.state(widget.clip.savedUri);
      if (mounted)
        setState(() {
          videoId = state['videoId'] as String?;
          requestMode = state['publishMode'] as String?;
          scheduledAt = state['publishAt'] as String?;
          pending = state['session'] != null && videoId == null;
        });
    } catch (e) {
      if (mounted) setState(() => error = youtubeError(e));
    }
  }

  Future<void> afterSave() async {
    if (!mounted) return;
    setState(() {
      videoId = null;
      pending = false;
      error = null;
    });
    await load();
    if (youtube.automatic) await upload();
  }

  Future<void> upload() async {
    if (youtube.uploading) return;
    widget.onBusyChanged(true);
    setState(() => error = null);
    try {
      final id = await youtube.uploadClip(widget.clip);
      if (mounted) setState(() => videoId = id);
    } catch (e) {
      if (mounted) setState(() => error = youtubeError(e));
    } finally {
      await load();
      if (mounted) widget.onBusyChanged(false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: youtube,
    builder: (context, _) {
      final active =
          youtube.uploading && youtube.activeUri == widget.clip.savedUri;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Divider(height: 32),
          const Text('유튜브 공개·예약 업로드',style:TextStyle(fontSize:18)),
          Text(
            youtube.preferences.channelTitle.isEmpty
                ? '업로드 채널을 먼저 연결해 주세요.'
                : '대상: ${youtube.preferences.channelTitle}',
          ),
          Text(
            youtube.automatic
                ? '새 MP4 저장 시 ${youtube.preferences.publishMode=='scheduled'?'유튜브 예약 게시':youtube.preferences.publishMode=='public'?'전체 공개':'비공개'}로 자동 전송'
                : '자동 전송 꺼짐 · 저장한 MP4를 직접 올릴 수 있어요.',
          ),
          TextButton(
            onPressed: youtube.uploading
                ? null
                : () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const YouTubeSettingsScreen(),
                      ),
                    );
                    await load();
                  },
            child: const Text('채널 · 업로드 설정'),
          ),
          if (active) ...[
            LinearProgressIndicator(value: youtube.progress),
            TextButton(
              onPressed: youtube.cancelUpload,
              child: const Text('전송 중단 · 저장본 유지'),
            ),
          ],
          if (videoId != null)
            SelectableText(
              '전송 완료 · ${requestMode=='scheduled'?'공개 예약 ${scheduledAt??''}':requestMode=='public'?'전체 공개 요청':'비공개 전송'}'
              '\nYouTube Studio에서 실제 공개 상태를 확인하세요.'
              '\nhttps://www.youtube.com/watch?v=$videoId',
            ),
          if (error != null)
            Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          if (widget.clip.savedUri.isNotEmpty && videoId == null)
            OutlinedButton.icon(
              onPressed: youtube.uploading || !youtube.preferences.confirmed
                  ? null
                  : upload,
              icon: const Icon(Icons.cloud_upload_outlined),
              label: Text(pending ? '유튜브 이어 올리기' : '저장한 MP4 업로드'),
            ),
          const Text(
            '편집을 바꿨다면 먼저 MP4를 다시 저장하세요. 이전 업로드의 영상은 자동으로 삭제하지 않아요.',
            style: TextStyle(fontSize: 11),
          ),
        ],
      );
    },
  );
}
