import 'package:flutter/services.dart';
import 'bridge.dart';
import 'youtube_upload.dart';

/// Android public client. No web-client secret, PC or authentication server.
class YouTubeChrome {
  static const clientId = '337875283119-som1inoqhtgpf1jvkk4b31tg46rub1ag.apps.googleusercontent.com';
  bool pending = false, hasGrant = false, hasRefreshToken = false;
  bool redirectAttempted = false, redirectSeen = false, redirectPathValid = false, redirectHasCode = false, redirectHasError = false;
  int expiresAt = 0;
  void metadata(Map? value) {
    hasGrant = value?['hasGrant'] == true;
    hasRefreshToken = value?['hasRefreshToken'] == true;
    if (value?.containsKey('redirectAttempted') == true) {
      redirectAttempted = value?['redirectAttempted'] == true;
      redirectSeen = value?['redirectSeen'] == true;
      redirectPathValid = value?['redirectPathValid'] == true;
      redirectHasCode = value?['redirectHasCode'] == true;
      redirectHasError = value?['redirectHasError'] == true;
    }
    expiresAt = value?['expiresAt'] is num ? (value!['expiresAt'] as num).toInt() : 0;
  }
  Future<Map?> call(String method, [Map<String, dynamic>? args]) async {
    try { return await Native.call<Map>(method, args); }
    on PlatformException catch (e) {
      final details = e.details;
      final oauth = details is Map ? details['oauthError'] : null;
      final message = switch (oauth) {
        'invalid_request' || 'redirect_uri_mismatch' => 'Android OAuth 클라이언트의 Custom URI scheme 허용과 복귀 주소 설정을 확인해 주세요.',
        'invalid_client' || 'unauthorized_client' => 'Android OAuth 클라이언트 ID·서명 등록·Custom URI scheme 허용을 확인해 주세요.',
        'invalid_grant' => '인증 권한이 만료되거나 무효화됐어요. Chrome에서 다시 연결해 주세요.',
        'access_denied' => 'YouTube 조회·업로드 권한을 허용한 뒤 다시 연결해 주세요.',
        _ => switch (e.code) {
          'AUTH_CHROME_OPEN' => '휴대폰 Chrome을 설치·활성화한 뒤 다시 시도해 주세요.',
          'AUTH_CHROME_STORAGE' => '휴대폰의 암호화된 인증 정보를 읽거나 저장하지 못했어요. 다시 연결해 주세요.',
          'AUTH_CHROME_NO_REFRESH' => '갱신 권한을 받지 못했어요. Chrome에서 다시 로그인하고 동의해 주세요.',
          'AUTH_CHROME_RECONNECT' => '휴대폰 Chrome에서 채널을 먼저 연결해 주세요.',
          'AUTH_CHROME_SCOPE' => 'YouTube 채널 조회·업로드 권한을 모두 허용해 주세요.',
          'AUTH_CHROME_BUSY' => '다른 Chrome 인증 작업이 진행 중이에요.',
          'AUTH_CHROME_TIMEOUT' => '인증 응답 시간이 지났어요. 다시 시도해 주세요.',
          'AUTH_CHROME_CANCELLED' => 'Chrome 인증 대기를 중단했어요.',
          'AUTH_CHROME_STATE' => '인증 복귀 정보를 확인하지 못했어요. 앱에서 다시 연결해 주세요.',
          'AUTH_CHROME_NO_RESULT' => 'Chrome 복귀 정보가 앱에 전달되지 않았어요. 아래 Chrome 탭 방식으로 다시 시도해 주세요.',
          'AUTH_CHROME_REDIRECT_MISSING' => 'AppAuth가 취소로 종료됐고, Android에 OAuth 복귀 URI가 도착하지 않았어요.',
          'AUTH_CHROME_AFTER_REDIRECT' => 'OAuth 복귀 URI는 도착했지만 AppAuth가 완료하지 못했어요.',
          'AUTH_CHROME_SESSION_LOST' => '인증 요청 정보가 사라졌어요. Chrome에서 다시 연결해 주세요.',
          'AUTH_CHROME_REDIRECT_INVALID' => 'OAuth 복귀 주소 검증에 실패했어요.',
          'AUTH_CHROME_RESPONSE' => '인증 응답을 해석하지 못했어요.',
          'AUTH_CHROME_NO_CODE' => '인증 응답에 코드가 없어요.',
          'AUTH_CHROME_OAUTH' => 'Google에서 인증 오류를 반환했어요.',
          _ => 'Chrome 인증이 완료되지 않았어요. Google Cloud의 Custom URI scheme 허용을 확인하고 다시 시도해 주세요.',
        },
      };
      final safeDiagnostic = <String>[
        if (details is Map && details['oauthType'] is int) 'OAuth 유형 ${details['oauthType']}',
        if (details is Map && details['oauthCode'] is int) 'OAuth 코드 ${details['oauthCode']}',
        if (details is Map && details['returnedIntent'] is bool)
          details['returnedIntent'] == true ? '응답 Intent 있음' : '응답 Intent 없음',
      ].join(' · ');
      throw YouTubeFailure('$message [${e.code}]${safeDiagnostic.isEmpty ? '' : ' ($safeDiagnostic)'}');
    }
  }
  Future<void> load() async => metadata(await call('youtubeChromeStatus'));
  Future<void> connect({bool customTab = false}) async {
    pending = true;
    try {
      metadata(await call('youtubeChromeConnect', {'customTab': customTab}));
      if (!hasGrant) throw const YouTubeFailure('Chrome 인증 결과를 확인하지 못했어요.');
    } finally { pending = false; }
  }
  Future<String> token({bool forceRefresh = false}) async {
    final result = await call('youtubeChromeToken', {'forceRefresh': forceRefresh});
    final token = result?['accessToken'];
    if (token is! String || token.isEmpty) throw const YouTubeFailure('Chrome 인증 토큰을 확인하지 못했어요. 다시 연결해 주세요.');
    metadata(result);
    return token;
  }
  Future<void> cancel() async { await Native.call('youtubeChromeCancel'); }
  Future<bool> disconnect() async {
    final result = await call('youtubeChromeDisconnect');
    metadata(null);
    return result?['revoked'] == true;
  }
}
