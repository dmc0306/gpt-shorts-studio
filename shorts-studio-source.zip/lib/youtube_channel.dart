import 'dart:convert';
import 'package:http/http.dart' as http;
import 'youtube_upload.dart';

class YouTubeChannelLookupFailure extends YouTubeFailure {
  const YouTubeChannelLookupFailure(super.message, this.diagnostic);
  final Map<String, dynamic> diagnostic;
}

class YouTubeChannel {
  const YouTubeChannel(this.id, this.title);
  final String id, title;
  static YouTubeChannel parse(String body) {
    final data = jsonDecode(body) as Map<String, dynamic>;
    final total = data['pageInfo'] is Map
        ? data['pageInfo']['totalResults']
        : null;
    final items = data['items'] ?? (total == 0 ? <dynamic>[] : null);
    final next = data['nextPageToken'];
    final hasNext = next is String && next.trim().isNotEmpty;
    final diagnostic = <String, dynamic>{
      'count': items is List ? items.length : null,
      'total': total is num ? total : null,
      'hasNext': hasNext,
    };
    if (items is! List) {
      throw YouTubeChannelLookupFailure(
        'YouTube 채널 응답 형식을 확인하지 못했어요. [YT_CHANNEL_RESPONSE]',
        {'kind': 'invalid', ...diagnostic},
      );
    }
    if (items.isEmpty) {
      throw YouTubeChannelLookupFailure(
        '현재 로그인 권한으로 조회되는 채널이 0개예요. [YT_CHANNEL_EMPTY] 원하는 채널의 소유 계정·브랜드 계정 권한이 연결됐는지 확인해 주세요. Google Cloud 프로젝트를 다시 만들 필요는 없어요.',
        {'kind': 'empty', ...diagnostic},
      );
    }
    if (items.length > 1 || hasNext || (total is num && total > 1)) {
      final names = items
          .whereType<Map>()
          .map(
            (item) => item['snippet'] is Map ? item['snippet']['title'] : null,
          )
          .whereType<String>()
          .take(5)
          .join(', ');
      throw YouTubeChannelLookupFailure(
        '현재 권한에서 여러 채널이 조회돼 업로드 대상을 확정하지 않았어요. [YT_CHANNEL_MULTIPLE]${names.isEmpty ? '' : ' 조회된 채널: $names'}. 임의로 첫 채널에 전송하지 않아요.',
        {'kind': 'multiple', ...diagnostic},
      );
    }
    final item = items.single as Map;
    final id = item['id'], title = item['snippet']?['title'];
    if (id is! String ||
        !RegExp(r'^UC[A-Za-z0-9_-]{22}$').hasMatch(id) ||
        title is! String ||
        title.trim().isEmpty) {
      throw const YouTubeFailure('채널 정보를 확인하지 못했어요. 계정을 다시 연결해 주세요.');
    }
    return YouTubeChannel(id, title);
  }
}

Future<YouTubeChannel> readYouTubeChannel(
  http.Client client,
  String token,
) async {
  final request = http.Request(
    'GET',
    Uri.https('www.googleapis.com', '/youtube/v3/channels', {
      'part': 'snippet',
      'mine': 'true',
      'maxResults': '2',
    }),
  )..followRedirects = false;
  request.headers['Authorization'] = 'Bearer $token';
  final response = await http.Response.fromStream(
    await client.send(request).timeout(const Duration(seconds: 30)),
  ).timeout(const Duration(seconds: 30));
  YouTubeUpload.check(response);
  return YouTubeChannel.parse(response.body);
}

class YouTubePreferences {
  YouTubePreferences({
    this.email = '',
    this.channelId = '',
    this.channelTitle = '',
    this.automatic = false,
    this.madeForKids,
    this.syntheticMedia = false,
    this.authMode = 'google',
    Map<String, dynamic>? channelDiagnostic,
  }) : channelDiagnostic = channelDiagnostic ?? {};
  Map<String, dynamic> channelDiagnostic;
  String email, channelId, channelTitle;
  String authMode;
  bool automatic, syntheticMedia;
  bool? madeForKids;
  bool get confirmed =>
      email.isNotEmpty && channelId.isNotEmpty && madeForKids != null;
  factory YouTubePreferences.fromJson(Map<String, dynamic> data) {
    final result = YouTubePreferences(
      email: data['email'] as String? ?? '',
      channelId: data['channelId'] as String? ?? '',
      channelTitle: data['channelTitle'] as String? ?? '',
      automatic: data['automatic'] == true,
      madeForKids: data['madeForKids'] as bool?,
      syntheticMedia: data['syntheticMedia'] == true,
      authMode: data['authMode'] == 'pc' ? 'pc' : 'google',
      channelDiagnostic: Map<String, dynamic>.from(
        data['channelDiagnostic'] as Map? ?? {},
      ),
    );
    if (!result.confirmed) result.automatic = false;
    return result;
  }
  Map<String, dynamic> toJson() => {
    'email': email,
    'channelId': channelId,
    'channelTitle': channelTitle,
    'automatic': automatic,
    'madeForKids': madeForKids,
    'syntheticMedia': syntheticMedia,
    'authMode': authMode,
    'channelDiagnostic': channelDiagnostic,
  };
  void requireTarget(String account, YouTubeChannel actual) {
    if (!confirmed)
      throw const YouTubeFailure('유튜브 설정에서 업로드 채널과 아동용 여부를 먼저 확인해 주세요.');
    if (email != account || channelId != actual.id)
      throw const YouTubeFailure(
        '현재 권한의 채널이 확인한 대상과 달라요. 유튜브 설정에서 채널을 다시 확인해 주세요.',
      );
  }
}
