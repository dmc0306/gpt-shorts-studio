import 'package:flutter/material.dart';

const captionStyle=TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:44,height:1.15,color:Colors.white);
class CaptionTextLayout {
 const CaptionTextLayout(this.painter,this.fits);
 final TextPainter painter;
 final bool fits;
}
// Lay out whole space-delimited words explicitly; never let Korean syllables wrap.
CaptionTextLayout layoutCaptionText(String text,double width){
 double measure(String value){
  final p=TextPainter(text:TextSpan(text:value,style:captionStyle),textDirection:TextDirection.ltr)..layout();
  final result=p.width;p.dispose();return result;
 }
 final words=text.trim().split(RegExp(r'\s+')).where((w)=>w.isNotEmpty).toList();
 final lines=<String>[];var line='';var fits=true;
 for(final word in words){
  final next=line.isEmpty?word:'$line $word';
  if(measure(next)<=width){line=next;continue;}
  if(line.isNotEmpty){lines.add(line);line='';}
  if(lines.length>=2||measure(word)>width){fits=false;break;}
  line=word;
 }
 if(line.isNotEmpty&&lines.length<2)lines.add(line);
 if(!fits){
  if(lines.isEmpty)lines.add('…');
  else{
   final last=lines.removeLast().split(' ');
   while(last.isNotEmpty&&measure('${last.join(' ')}…')>width){last.removeLast();}
   lines.add('${last.join(' ')}…');
  }
 }
 final p=TextPainter(text:TextSpan(text:lines.join('\n'),style:captionStyle),textDirection:TextDirection.ltr,textAlign:TextAlign.center)..layout();
 return CaptionTextLayout(p,fits);
}
