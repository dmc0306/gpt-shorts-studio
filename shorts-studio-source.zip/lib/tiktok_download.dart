import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'bridge.dart';

class DownloadFailure implements Exception {
  const DownloadFailure(this.message);
  final String message;
  @override String toString()=>message;
}
class TikTokMedia {
  const TikTokMedia(this.url,this.title,this.creator);
  final Uri url;
  final String title,creator;
}
bool allowedDownloadUri(Uri uri,{bool page=false}) {
  if(uri.scheme!='https'||uri.userInfo.isNotEmpty||(uri.hasPort&&uri.port!=443))return false;
  final domains=page?['tiktok.com']:['tiktok.com','tiktokcdn.com','tiktokcdn-us.com','tiktokcdn-eu.com','tiktokv.com','byteoversea.com','ibytedtos.com','ibyteimg.com'];
  return domains.any((d)=>uri.host==d||uri.host.endsWith('.$d'));
}
TikTokMedia parseTikTokPage(String html,String videoId){
  Map<String,dynamic>? item;
  final scripts=RegExp(r'''<script\b[^>]*\bid\s*=\s*["'](__UNIVERSAL_DATA_FOR_REHYDRATION__|SIGI_STATE)["'][^>]*>([\s\S]*?)</script>''',caseSensitive:false);
  for(final match in scripts.allMatches(html)){
    try{
      final data=jsonDecode(match.group(2)!) as Map<String,dynamic>;
      dynamic candidate;
      if(match.group(1)=='SIGI_STATE'){
        candidate=data['ItemModule']?[videoId];
      }else{
        final detail=data['__DEFAULT_SCOPE__']?['webapp.video-detail'];
        candidate=detail?['itemInfo']?['itemStruct'];
      }
      if(candidate is Map<String,dynamic> && candidate['id'].toString()==videoId){item=candidate;break;}
    }catch(_){/* Other scripts never supply download URLs. */}
  }
  if(item==null)throw const DownloadFailure('TikTok에서 영상 정보를 제공하지 않았어요. 로그인·지역 제한 또는 페이지 변경일 수 있어요.');
  if(item['privateItem']==true||item['isPrivate']==true)throw const DownloadFailure('비공개 영상은 다운로드할 수 없어요.');
  if(item['downloadEnabled']==false)
    throw const DownloadFailure('이 영상의 다운로드가 허용되지 않았어요.');
  final video=item['video'];
  dynamic address=video is Map?video['downloadAddr']:null;
  if(address==null && video is Map)address=video['download']?['url'];
  if(address is Map)address=address['UrlList'] is List?(address['UrlList'] as List).firstOrNull:address['url'];
  final uri=address is String?Uri.tryParse(address.startsWith('//')?'https:$address':address):null;
  if(uri==null||!allowedDownloadUri(uri))throw const DownloadFailure('사용 가능한 다운로드 주소가 없어요. TikTok 저장 기능이나 원본 파일을 연결해 주세요.');
  final author=item['author'];
  return TikTokMedia(uri,(item['desc'] as String? ?? 'TikTok 영상').trim(),author is Map?'@${author['uniqueId']??author['nickname']??'TikTok'}':'TikTok');
}

class TikTokDownloader {
  static const maxBytes=512*1024*1024;
  static const agent='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
  final HttpClient _client=HttpClient()..connectionTimeout=const Duration(seconds:15);
  final Map<String,List<Cookie>> _cookies={};
  bool _cancelled=false;
  void cancel(){_cancelled=true;_client.close(force:true);}
  void _check(){if(_cancelled)throw const DownloadFailure('다운로드를 취소했어요.');}
  Future<(HttpClientResponse,Uri)> _get(Uri uri,{required bool page,Uri? referer})async{
    for(var n=0;n<6;n++){
      _check();
      if(!allowedDownloadUri(uri,page:page))throw const DownloadFailure('지원하지 않는 다운로드 주소예요.');
      final request=await _client.getUrl(uri).timeout(const Duration(seconds:20));
      request.followRedirects=false;
      request.headers.set(HttpHeaders.userAgentHeader,agent);
      if(referer!=null)request.headers.set(HttpHeaders.refererHeader,referer.toString());
      request.cookies.addAll(_cookies[uri.host]??[]);
      final response=await request.close().timeout(const Duration(seconds:20));
      _cookies[uri.host]=response.cookies;
      if([301,302,303,307,308].contains(response.statusCode)){
        final target=response.headers.value(HttpHeaders.locationHeader);
        await response.drain<void>().timeout(const Duration(seconds:10));
        if(target==null)throw const DownloadFailure('TikTok 링크 이동에 실패했어요.');
        uri=uri.resolve(target);continue;
      }
      if(response.statusCode!=200){
        await response.drain<void>().timeout(const Duration(seconds:10));
        throw DownloadFailure(response.statusCode==403||response.statusCode==429?'TikTok이 다운로드 요청을 제한했어요. 파일을 직접 연결해 주세요.':'영상 요청에 실패했어요 (HTTP ${response.statusCode}).');
      }
      return(response,uri);
    }
    throw const DownloadFailure('링크가 너무 여러 번 이동했어요. 영상의 직접 링크를 사용해 주세요.');
  }
  Future<Map<String,dynamic>> download(String link,void Function(double? value,String stage) progress)async{
    File? partial;
    try{
      progress(null,'TikTok 영상 확인 중');
      final (page,canonical)=await _get(Uri.parse(link),page:true);
      final id=RegExp(r'/video/(\d+)').firstMatch(canonical.path)?.group(1);
      if(id==null)throw const DownloadFailure('영상 한 개의 TikTok 링크를 입력해 주세요.');
      final htmlBytes=<int>[];
      await for(final chunk in page.timeout(const Duration(seconds:20))){
        _check();htmlBytes.addAll(chunk);
        if(htmlBytes.length>8*1024*1024)throw const DownloadFailure('영상 정보가 너무 커서 처리할 수 없어요.');
      }
      final media=parseTikTokPage(utf8.decode(htmlBytes,allowMalformed:true),id);
      final (response,_)=await _get(media.url,page:false,referer:canonical);
      if(response.contentLength>maxBytes)throw const DownloadFailure('512MB 이하 영상을 사용해 주세요.');
      final destination=await Native.call<String>('downloadPath');
      if(destination==null)throw const DownloadFailure('다운로드 저장 위치를 만들지 못했어요.');
      partial=File(destination);final sink=partial.openWrite();var total=0;
      final watch=Stopwatch()..start();
      try{
        await for(final chunk in response.timeout(const Duration(seconds:20))){
          _check();total+=chunk.length;
          if(total>maxBytes)throw const DownloadFailure('512MB 이하 영상을 사용해 주세요.');
          if(watch.elapsed>const Duration(minutes:3))throw const DownloadFailure('다운로드 시간이 초과됐어요.');
          sink.add(chunk);await sink.flush();
          progress(response.contentLength>0?total/response.contentLength:null,'원본 다운로드 중');
        }
      }finally{await sink.close();}
      if(total==0||(response.contentLength>0&&total!=response.contentLength))throw const DownloadFailure('영상이 끝까지 다운로드되지 않았어요.');
      _check();progress(null,'영상·썸네일 준비 중');
      final result=await Native.call<Map<dynamic,dynamic>>('inspectDownload',{'path':destination,'name':media.title.isEmpty?'TikTok 영상':media.title});
      if(result==null)throw const DownloadFailure('영상 파일을 확인하지 못했어요.');
      return {...Map<String,dynamic>.from(result),'creator':media.creator};
    }on DownloadFailure{rethrow;}
    on TimeoutException{throw const DownloadFailure('응답 시간이 초과됐어요. 다시 시도해 주세요.');}
    catch(_){throw DownloadFailure(_cancelled?'다운로드를 취소했어요.':'영상을 다운로드하지 못했어요. 연결을 확인하거나 파일을 직접 연결해 주세요.');}
    finally{_client.close(force:true);if(partial!=null&&partial.path.endsWith('.part')&&await partial.exists())await partial.delete();}
  }
}
