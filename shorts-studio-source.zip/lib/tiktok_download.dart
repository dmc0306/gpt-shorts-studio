import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'bridge.dart';

class DownloadFailure implements Exception {
  const DownloadFailure(this.message,{this.code});
  final String message;
  final String? code;
  @override String toString()=>message;
}
class TikTokMedia {
  const TikTokMedia(this.url,this.title,this.creator);
  final Uri url;
  final String title,creator;
}
bool allowedDownloadUri(Uri uri,{bool page=false}) {
  if(uri.scheme!='https'||uri.userInfo.isNotEmpty||(uri.hasPort&&uri.port!=443))return false;
  final domains=page?['tiktok.com']:['tiktok.com','tiktokcdn.com','tiktokcdn-us.com','tiktokcdn-eu.com','tiktokv.com','byteoversea.com','ibytedtos.com','ibyteimg.com'];
  return domains.any((d)=>uri.host==d||uri.host.endsWith('.$d'));
}
TikTokMedia parseTikTokPage(String html,String videoId){
  Map<String,dynamic>? item;
  final scripts=RegExp(r'''<script\b[^>]*\bid\s*=\s*["'](__UNIVERSAL_DATA_FOR_REHYDRATION__|SIGI_STATE)["'][^>]*>([\s\S]*?)</script>''',caseSensitive:false);
  for(final match in scripts.allMatches(html)){
    try{
      final data=jsonDecode(match.group(2)!) as Map<String,dynamic>;
      dynamic candidate;
      if(match.group(1)=='SIGI_STATE'){
        candidate=data['ItemModule']?[videoId];
      }else{
        final scope=data['__DEFAULT_SCOPE__'];
        for(final key in ['webapp.video-detail','webapp.reflow.video.detail']){
          final candidateItem=scope?[key]?['itemInfo']?['itemStruct'];
          if(candidateItem is Map<String,dynamic> && candidateItem['id'].toString()==videoId){candidate=candidateItem;break;}
        }
      }
      if(candidate is Map<String,dynamic> && candidate['id'].toString()==videoId){item=candidate;break;}
    }catch(_){/* Other scripts never supply download URLs. */}
  }
  if(item==null)throw const DownloadFailure('TikTok에서 영상 정보를 제공하지 않았어요. 로그인·지역 제한 또는 페이지 변경일 수 있어요.',code:'PAGE_METADATA');
  if(item['privateItem']==true||item['isPrivate']==true)throw const DownloadFailure('비공개 영상은 다운로드할 수 없어요.',code:'PAGE_PRIVATE');
  if(item['downloadEnabled']==false)
    throw const DownloadFailure('이 영상의 다운로드가 허용되지 않았어요.',code:'PAGE_DOWNLOAD_DISABLED');
  final video=item['video'];
  dynamic address=video is Map?video['downloadAddr']:null;
  if(address==null && video is Map)address=video['download']?['url'];
  if(address is Map)address=address['UrlList'] is List?(address['UrlList'] as List).firstOrNull:address['url'];
  final uri=address is String?Uri.tryParse(address.startsWith('//')?'https:$address':address):null;
  if(uri==null||!allowedDownloadUri(uri))throw const DownloadFailure('사용 가능한 다운로드 주소가 없어요. TikTok 저장 기능이나 원본 파일을 연결해 주세요.',code:'PAGE_DOWNLOAD_URL');
  final author=item['author'];
  return TikTokMedia(uri,(item['desc'] as String? ?? 'TikTok 영상').trim(),author is Map?'@${author['uniqueId']??author['nickname']??'TikTok'}':'TikTok');
}

// Script/configuration references to captcha are not proof of a challenge.
bool hasVisibleVerification(String html){
  final text=html.replaceAll(RegExp(r'<script\b[^>]*>[\s\S]*?</script>',caseSensitive:false),' ')
    .replaceAll(RegExp(r'<style\b[^>]*>[\s\S]*?</style>',caseSensitive:false),' ')
    .replaceAll(RegExp(r'<[^>]+>'),' ').replaceAll(RegExp(r'\s+'),' ').toLowerCase();
  return ['verify you are human','verify that you are human','complete the captcha','보안 확인을 완료','사람인지 확인'].any(text.contains);
}
String pageMetadataSummary(String html,String videoId){
  final scripts=RegExp(r'''<script\b[^>]*\bid\s*=\s*["'](__UNIVERSAL_DATA_FOR_REHYDRATION__|SIGI_STATE)["'][^>]*>([\s\S]*?)</script>''',caseSensitive:false);
  final reports=<String>[];
  for(final m in scripts.allMatches(html)){
    try{
      final data=jsonDecode(m.group(2)!);
      dynamic item,status;
      if(m.group(1)=='SIGI_STATE'){item=data['ItemModule']?[videoId];}
      else{
        final scope=data['__DEFAULT_SCOPE__'];
        for(final key in ['webapp.video-detail','webapp.reflow.video.detail']){
          final detail=scope?[key];
          if(detail==null)continue;
          status=detail['statusCode'];
          final candidate=detail['itemInfo']?['itemStruct'];
          if(candidate is Map && candidate['id'].toString()==videoId){item=candidate;break;}
        }
      }
      final match=item is Map&&item['id'].toString()==videoId;
      final video=match?item['video']:null;
      final addr=video is Map?video['downloadAddr']:null;
      // Only booleans and numeric status codes, never script values or signed URLs.
      reports.add('${m.group(1)}: JSON 정상 · 영상 일치=$match · downloadAddr=${addr!=null} · 상태=${status is num?status:'unknown'}');
    }catch(_){reports.add('${m.group(1)}: JSON 해석 실패');}
  }
  return reports.isEmpty?'PAGE 메타데이터 스크립트: 없음':reports.join('\n');
}

class DownloadCookies {
  final Map<String,(Cookie,bool)> _cookies={};
  void update(Uri origin,List<Cookie> cookies){
    for(final cookie in cookies){
      final hostOnly=cookie.domain==null;
      final domain=(cookie.domain??origin.host).replaceFirst(RegExp(r'^\.'),'').toLowerCase();
      if(origin.host!=domain&&!origin.host.endsWith('.$domain'))continue;
      final key='$domain|${cookie.path??'/'}|${cookie.name}';
      if(cookie.maxAge==0 || (cookie.expires?.isBefore(DateTime.now().toUtc())??false)){
        _cookies.remove(key);
      }else{
        cookie.domain=domain;cookie.path??='/';
        if(cookie.maxAge!=null)cookie.expires=DateTime.now().toUtc().add(Duration(seconds:cookie.maxAge!));
        _cookies[key]=(cookie,hostOnly);
      }
    }
  }
  List<Cookie> forUri(Uri uri)=>_cookies.values.where((entry){
    final (c,hostOnly)=entry;
    final domain=c.domain!;final path=c.path??'/';
    final hostMatches=uri.host==domain||(!hostOnly&&uri.host.endsWith('.$domain'));
    final pathMatches=uri.path==path||(uri.path.startsWith(path)&&(path.endsWith('/')||uri.path.substring(path.length).startsWith('/')));
    return hostMatches&&pathMatches&&!(c.expires?.isBefore(DateTime.now().toUtc())??false);
  }).map((entry)=>entry.$1).toList();
}
class TikTokDownloader {
  static const maxBytes=512*1024*1024;
  static const agent='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
  final HttpClient _client=HttpClient()..connectionTimeout=const Duration(seconds:15);
  final DownloadCookies _cookies=DownloadCookies();
  final List<String> _diagnostics=[];
  String _stage='PAGE';
  bool _timedOut=false;
  String get diagnostics=>_diagnostics.join('\n');
  DownloadFailure _failure(String message,String code)=>DownloadFailure('$message\n[$code]\n$diagnostics');
  bool _cancelled=false;
  void cancel(){_cancelled=true;_client.close(force:true);}
  void _check(){if(_cancelled)throw _failure(_timedOut?'TikTok 응답 대기시간이 초과됐어요.':'다운로드를 취소했어요.',_timedOut?'${_stage}_TIMEOUT':'CANCELLED');}
  Future<(HttpClientResponse,Uri)> _get(Uri uri,{required bool page,Uri? referer})async{
    for(var n=0;n<6;n++){
      _check();
      if(!allowedDownloadUri(uri,page:page))throw _failure('지원하지 않는 다운로드 주소예요.','${_stage}_HOST');
      final request=await _client.getUrl(uri).timeout(const Duration(seconds:20));
      request.followRedirects=false;
      request.headers.set(HttpHeaders.userAgentHeader,agent);
      if(referer!=null)request.headers.set(HttpHeaders.refererHeader,referer.toString());
      request.cookies.addAll(_cookies.forUri(uri));
      final response=await request.close().timeout(const Duration(seconds:20));
      _cookies.update(uri,response.cookies);
      _diagnostics.add('$_stage 요청 ${n+1}: ${uri.host} · HTTP ${response.statusCode} · ${response.headers.contentType?.mimeType??'unknown'}');
      if([301,302,303,307,308].contains(response.statusCode)){
        final target=response.headers.value(HttpHeaders.locationHeader);
        await response.drain<void>().timeout(const Duration(seconds:10));
        if(target==null)throw const DownloadFailure('TikTok 링크 이동에 실패했어요.');
        uri=uri.resolve(target);continue;
      }
      if(response.statusCode!=200){
        await response.drain<void>().timeout(const Duration(seconds:10));
        throw _failure(response.statusCode==403||response.statusCode==429?'TikTok이 다운로드 요청을 제한했어요.':'영상 요청에 실패했어요 (HTTP ${response.statusCode}).','${_stage}_HTTP_${response.statusCode}');
      }
      return(response,uri);
    }
    throw const DownloadFailure('링크가 너무 여러 번 이동했어요. 영상의 직접 링크를 사용해 주세요.');
  }
  Future<Map<String,dynamic>> download(String link,void Function(double? value,String stage) progress)async{
    File? partial;
    var deadline=Timer(const Duration(seconds:45),(){_timedOut=true;cancel();});
    try{
      progress(null,'TikTok 영상 확인 중');
      final (page,canonical)=await _get(Uri.parse(link),page:true);
      final id=RegExp(r'/video/(\d+)').firstMatch(canonical.path)?.group(1);
      if(id==null)throw _failure('영상 한 개의 TikTok 링크를 입력해 주세요.','PAGE_VIDEO_ID');
      final htmlBytes=<int>[];
      await for(final chunk in page.timeout(const Duration(seconds:20))){
        _check();htmlBytes.addAll(chunk);
        if(htmlBytes.length>8*1024*1024)throw const DownloadFailure('영상 정보가 너무 커서 처리할 수 없어요.');
      }
      _diagnostics.add('PAGE 본문: ${htmlBytes.length} bytes');
      final html=utf8.decode(htmlBytes,allowMalformed:true);
      final TikTokMedia media;
      try{media=parseTikTokPage(html,id);}on DownloadFailure catch(e){
        _diagnostics.add(pageMetadataSummary(html,id));
        final challenge=e.code=='PAGE_METADATA'&&hasVisibleVerification(html);
        throw _failure(challenge?'TikTok 페이지에 사람 인증 안내가 있어요.':e.message,challenge?'PAGE_VERIFICATION':e.code??'PAGE_METADATA');
      }
      _check();deadline.cancel();_stage='MEDIA';
      deadline=Timer(const Duration(minutes:3),(){_timedOut=true;cancel();});
      final (response,_)=await _get(media.url,page:false,referer:canonical);
      if(response.headers.contentType?.mimeType=='text/html')throw _failure('영상 대신 HTML 페이지가 반환됐어요.','MEDIA_HTML');
      if(response.contentLength>maxBytes)throw const DownloadFailure('512MB 이하 영상을 사용해 주세요.');
      final destination=await Native.call<String>('downloadPath');
      if(destination==null)throw const DownloadFailure('다운로드 저장 위치를 만들지 못했어요.');
      partial=File(destination);final sink=partial.openWrite();var total=0;
      final watch=Stopwatch()..start();
      try{
        await for(final chunk in response.timeout(const Duration(seconds:20))){
          _check();total+=chunk.length;
          if(total>maxBytes)throw const DownloadFailure('512MB 이하 영상을 사용해 주세요.');
          if(watch.elapsed>const Duration(minutes:3))throw const DownloadFailure('다운로드 시간이 초과됐어요.');
          sink.add(chunk);await sink.flush();
          progress(response.contentLength>0?total/response.contentLength:null,'원본 다운로드 중');
        }
      }finally{await sink.close();}
      if(total==0||(response.contentLength>0&&total!=response.contentLength))throw const DownloadFailure('영상이 끝까지 다운로드되지 않았어요.');
      _check();_stage='FILE';_diagnostics.add('MEDIA 저장: $total bytes');progress(null,'영상·썸네일 준비 중');
      final result=await Native.call<Map<dynamic,dynamic>>('inspectDownload',{'path':destination,'name':media.title.isEmpty?'TikTok 영상':media.title});
      if(result==null)throw const DownloadFailure('영상 파일을 확인하지 못했어요.');
      return {...Map<String,dynamic>.from(result),'creator':media.creator};
    }on DownloadFailure{rethrow;}
    on TimeoutException{throw _failure('응답 시간이 초과됐어요. 다시 시도해 주세요.','${_stage}_TIMEOUT');}
    on PlatformException catch(e){throw _failure(e.message??'영상 파일 처리에 실패했어요.','FILE_${e.code}');}
    on SocketException{_check();throw _failure('네트워크 연결 또는 주소 조회에 실패했어요.','${_stage}_NETWORK');}
    on HandshakeException{throw _failure('보안 연결을 완료하지 못했어요.','${_stage}_TLS');}
    on FileSystemException{throw _failure('파일 쓰기에 실패했어요. 저장 공간을 확인해 주세요.','FILE_WRITE');}
    catch(e){_check();throw _failure('영상을 다운로드하지 못했어요.','${_stage}_${e.runtimeType}');}
    finally{deadline.cancel();_client.close(force:true);if(partial!=null&&partial.path.endsWith('.part')&&await partial.exists())await partial.delete();}
  }
}
