import 'dart:convert';
import 'package:flutter/services.dart';
import 'model.dart';
class Native {
  static const channel=MethodChannel('studio.local/media');
  static Future<T?> call<T>(String name,[Map<String,dynamic>? args])=>channel.invokeMethod<T>(name,args);
  static Future<List<Clip>> load() async {
    final raw=await call<String>('loadProjects');
    if(raw==null||raw.isEmpty)return [];
    return (jsonDecode(raw) as List).map((x)=>Clip.fromJson(Map<String,dynamic>.from(x))).toList();
  }
  static Future<void> save(List<Clip> clips) async {await call('saveProjects',{'json':jsonEncode(clips.map((c)=>c.toJson()).toList())});}
  static Future<List<Clip>> inbox() async {
    final data=await call<List<dynamic>>('drainInbox')??[];
    return data.map((x)=>Clip.fromJson(Map<String,dynamic>.from(x))).toList();
  }
}
