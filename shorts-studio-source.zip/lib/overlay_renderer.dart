import 'caption_layout.dart';
import 'headline.dart';
import 'model.dart';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

// The same painter serves the preview and exports, without requiring UI frames.
class ShortsOverlayPainter extends CustomPainter {
 const ShortsOverlayPainter({required this.headline,required this.caption,required this.style,this.cue,this.clip});
 final String headline,caption;
 final int style;
 final TimedCaption? cue;
 final Clip? clip;
 @override void paint(Canvas canvas,Size size){
  canvas.save();canvas.scale(size.width/1080);
  canvas.drawRect(const Rect.fromLTWH(0,0,1080,420),Paint()..color=Colors.black);
  canvas.drawRect(const Rect.fromLTWH(0,1500,1080,420),Paint()..color=Colors.black);
  if(headline.trim().isNotEmpty){
   final raw=fitHeadline(headline.trim()).split('\n');
   final lines=raw.length>1?[raw.first,raw.skip(1).join(' ')]:raw;
   for(var i=0;i<lines.length;i++){
    final p=TextPainter(text:TextSpan(text:lines[i],style:TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:112,height:1,color:style==1?Colors.white:style==2?const Color(0xffffdf00):i==0?Colors.white:const Color(0xffffdf00))),textDirection:TextDirection.ltr)..layout();
    final scale=math.min(1.0,math.min(960/math.max(p.width,1),116/math.max(p.height,1)));
    final top=164+(232-lines.length*116)/2+i*116;
    canvas.save();canvas.translate((1080-p.width*scale)/2,top+(116-p.height*scale)/2);canvas.scale(scale);p.paint(canvas,Offset.zero);canvas.restore();p.dispose();
   }
  }
  if(caption.trim().isNotEmpty){
   final placement=placeCaption(caption,cue:cue,clip:clip);
   if(!placement.visible){canvas.restore();return;}
   final p=TextPainter(text:TextSpan(text:caption,style:const TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:44,height:1.15,color:Colors.white)),textDirection:TextDirection.ltr,textAlign:TextAlign.center,maxLines:2,ellipsis:'…')..layout(maxWidth:placement.rect.width-24);
   final left=placement.rect.left,top=placement.rect.top;
   canvas.drawRect(Rect.fromLTWH(left,top,p.width+24,p.height+16),Paint()..color=Colors.black);
   p.paint(canvas,Offset(left+12,top+8));p.dispose();
  }
  canvas.restore();
 }
 @override bool shouldRepaint(ShortsOverlayPainter old)=>true;
}

Future<Uint8List> renderOverlayPng({required String headline,required String caption,required int style,bool subtitleOnly=false,TimedCaption? cue,Clip? clip})async{
 final recorder=ui.PictureRecorder();final canvas=Canvas(recorder);
 if(subtitleOnly)canvas.translate(0,-placeCaption(caption,cue:cue,clip:clip).stripTop);
 ShortsOverlayPainter(headline:headline,caption:caption,style:style,cue:cue,clip:clip).paint(canvas,const Size(1080,1920));
 final picture=recorder.endRecording();
 final image=await picture.toImage(1080,subtitleOnly?200:1920);
 picture.dispose();
 try{final bytes=await image.toByteData(format:ui.ImageByteFormat.png);if(bytes==null)throw StateError('자막 이미지 생성 실패');return bytes.buffer.asUint8List();}finally{image.dispose();}
}
