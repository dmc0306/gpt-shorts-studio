import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'model.dart';

const captionPositions=['auto','top','bottom','left','right','outside','legacy'];
const captionPositionLabels={'auto':'AI 자동 배치','top':'영상 위쪽','bottom':'영상 아래쪽','left':'왼쪽 여백','right':'오른쪽 여백','outside':'영상 밖 검정 여백','legacy':'기존 위치'};
class CaptionPlacement {
 const CaptionPlacement(this.rect,this.stripTop);
 final Rect rect;
 final double stripTop;
}
// AI returns the union of all important subjects throughout each cue in source
// coordinates. Convert it through the same centered crop/fit as the video.
Rect? subjectRect(TimedCaption cue,Clip? clip){
 if(cue.avoid.length!=4||cue.avoid.any((v)=>!v.isFinite)||clip==null||clip.videoWidth<=0||clip.videoHeight<=0)return null;
 final a=cue.avoid;final w=clip.videoWidth,h=clip.videoHeight;
 final scale=clip.crop?math.max(1080/w,1080/h):math.min(1080/w,1080/h);
 final rect=Rect.fromLTWH((1080-w*scale)/2+a[0]*w*scale,420+(1080-h*scale)/2+a[1]*h*scale,a[2]*w*scale,a[3]*h*scale);
 return rect.inflate(32);
}
CaptionPlacement placeCaption(String text,{TimedCaption? cue,Clip? clip}){
 var sideFits=true;
 Size measure(double width){
  final p=TextPainter(text:TextSpan(text:text,style:const TextStyle(fontFamily:'GmarketSans',fontWeight:FontWeight.w700,fontSize:44,height:1.15)),textDirection:TextDirection.ltr,textAlign:TextAlign.center,maxLines:2,ellipsis:'…')..layout(maxWidth:width-24);
  if(width==440)sideFits=!p.didExceedMaxLines;
  final size=Size(p.width+24,p.height+16);p.dispose();return size;
 }
 final wide=measure(960),side=measure(440);
 Rect center(double top)=>Rect.fromLTWH((1080-wide.width)/2,top,wide.width,wide.height);
 final choices=<String,Rect>{
  'top':center(456),'bottom':center(1464-wide.height),
  if(sideFits)'left':Rect.fromLTWH(36,960-side.height/2,side.width,side.height),
  if(sideFits)'right':Rect.fromLTWH(1044-side.width,960-side.height/2,side.width,side.height),
 };
 if(cue==null||cue.position=='legacy')return CaptionPlacement(center(1200),1200);
 final subject=subjectRect(cue,clip);
 final order=[if(choices.containsKey(cue.position))cue.position,...choices.keys.where((s)=>s!=cue.position)];
 if(subject==null&&choices.containsKey(cue.position))return CaptionPlacement(choices[cue.position]!,choices[cue.position]!.top);
 if(cue.position!='outside'&&subject!=null){
  for(final key in order){final rect=choices[key]!;if(!rect.overlaps(subject))return CaptionPlacement(rect,rect.top);}
 }
 // Missing/uncertain geometry never falls back on top of the subject.
 return CaptionPlacement(center(1560),1560);
}
