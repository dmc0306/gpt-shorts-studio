import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'youtube.dart';
import 'youtube_probe.dart';
import 'youtube_upload.dart';
import 'youtube_publish_plan.dart';
import 'youtube_batch_publish_screen.dart';
import 'model.dart';

class YouTubeSettingsScreen extends StatefulWidget {
  const YouTubeSettingsScreen({super.key,this.clips=const []});
  final List<Clip> clips;
  @override State<YouTubeSettingsScreen> createState() => _YouTubeSettingsState();
}
class _YouTubeSettingsState extends State<YouTubeSettingsScreen> {
  final youtube = YouTube.instance;
  final serverUrl = TextEditingController(), serverKey = TextEditingController();
  bool busy = true;
  String? error, notice;
  @override void initState() {
    super.initState();
    run(() async {
      // Opening settings should not authenticate a personal Google identity first.
      await youtube.loadSettings();
      if (youtube.chromeMode) await youtube.initialize();
      final url = await youtube.server.configuredUrl();
      if (mounted) serverUrl.text = url;
    });
  }
  @override void dispose() {
    youtube.pc.cancelled = true;
    youtube.server.cancelled = true;
    if (youtube.chrome.pending) youtube.chrome.cancel().catchError((_) {});
    serverUrl.dispose(); serverKey.dispose();
    super.dispose();
  }
  Future<void> run(Future<void> Function() action) async {
    setState(() { busy = true; error = null; notice = null; });
    try { await action(); }
    catch (e) {
      if (youtube.chromeMode) {
        try { await youtube.chrome.load(); } catch (_) {}
      }
      if (mounted) setState(() => error = youtubeError(e));
    }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> selectMode(String mode)async{
    if(mode=='private'){
      await run(()=>youtube.setPublishMode('private',approved:true));
      return;
    }
    if(!youtube.preferences.confirmed){
      setState(()=>error='먼저 실제 채널과 아동용 여부를 확인해 주세요.');
      return;
    }
    final accepted=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:Text(mode=='scheduled'?'자동 예약 공개 활성화':'전체 공개 업로드 활성화'),
      content:Text('대상 채널: ${youtube.preferences.channelTitle}\n\n'
        '새 MP4를 ${mode=='scheduled'?'예약한 날짜에 전체 공개':'업로드 직후 전체 공개'}합니다. '
        '유튜브에 이미 올라간 과거 비공개 영상은 자동으로 공개 전환되지 않습니다.\n\n'
        '직접 제작했거나 게시·재이용 권한을 가진 영상만 업로드하고 '
        '기존 자막, 원제작자 및 저작권을 확인하겠습니다.'),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('취소')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),
          child:const Text('확인하고 활성화')),
      ]));
    if(accepted!=true||!mounted)return;
    await run(()=>youtube.setPublishMode(mode,approved:true));
  }
  Future<void> pickPublishTime()async{
    final p=youtube.preferences;
    final picked=await showTimePicker(context:context,
      initialTime:TimeOfDay(hour:p.publishHour,minute:p.publishMinute));
    if(picked==null||!mounted)return;
    await run(()async{
      p.publishHour=picked.hour;
      p.publishMinute=picked.minute;
      await youtube.saveSettings();
    });
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('유튜브 채널 · 자동 업로드')),
    body: ListenableBuilder(listenable: youtube, builder: (context, _) {
      final p = youtube.preferences;
      final locked = busy || youtube.uploading;
      return ListView(padding: const EdgeInsets.all(24), children: [
        const Text('휴대폰 Chrome으로 연결', style: TextStyle(fontSize: 24)),
        const SizedBox(height: 12),
        const Text('휴대폰에 설치된 Chrome에서 Google 계정·브랜드 채널을 선택하면 앱으로 돌아와요. PC·ADB·별도 인증 서버는 필요 없어요.'),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: locked ? null : () => run(youtube.connectChrome),
          icon: const Icon(Icons.open_in_browser), label: const Text('Chrome에서 로그인 · 브랜드 채널 선택')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: locked ? null : () => run(() => youtube.connectChrome(customTab: true)),
          icon: const Icon(Icons.tab), label: const Text('Chrome 탭으로 로그인 · 복귀 오류 대안')),
        const Text('최초 설정: Google Cloud Android 클라이언트의 Custom URI scheme 허용을 켜고 저장하세요.'),
        if (busy) const LinearProgressIndicator(),
        if (youtube.chrome.pending || youtube.pc.pending || youtube.server.pending)
          TextButton(onPressed: () {
            youtube.pc.cancelled = true; youtube.server.cancelled = true;
            if (youtube.chrome.pending) youtube.chrome.cancel();
          }, child: const Text('브라우저 인증 대기 중단')),
        if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        if (youtube.chrome.redirectAttempted) Text(
          youtube.chrome.redirectSeen
            ? (youtube.chrome.redirectPathValid
              ? (youtube.chrome.redirectHasCode ? '최근 Chrome 복귀: 인증 코드 포함 URI 수신'
                : (youtube.chrome.redirectHasError ? '최근 Chrome 복귀: 오류 URI 수신' : '최근 Chrome 복귀: URI 수신, 코드 없음'))
              : '최근 Chrome 복귀: URI 수신, 경로 불일치')
            : '최근 Chrome 복귀: Android 콜백 수신 안 됨',
        ),
        if (notice != null) Text(notice!),
        if (youtube.chromeMode && youtube.chrome.hasGrant) ...[
          Text(youtube.chrome.hasRefreshToken ? '인증 정보 암호화 저장됨 · 갱신 권한 있음' : '갱신 권한 없음 · 인증 만료 시 재연결 필요'),
          OutlinedButton.icon(onPressed: locked ? null : () => run(() async {
            await youtube.verifyChromeRefresh();
            if (mounted) setState(() => notice = '인증 갱신과 채널 재조회에 성공했어요.');
          }), icon: const Icon(Icons.refresh), label: const Text('인증 갱신 확인 · 업로드 없음')),
        ],
        if (youtube.channel != null) ...[
          const Divider(height: 32), const Text('현재 권한의 실제 채널'),
          Text(youtube.channel!.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          SelectableText(youtube.channel!.id),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.confirmChannel), child: const Text('이 채널로 업로드 확인')),
        ],
        if (p.channelId.isNotEmpty) ...[
          const SizedBox(height: 12), Text('확인한 업로드 대상: ${p.channelTitle}'), SelectableText(p.channelId),
        ],
        if (youtube.connected) ...[
          TextButton(onPressed: locked ? null : () => run(youtube.refreshChannel), child: const Text('실제 채널 다시 조회')),
          TextButton(onPressed: locked ? null : () => run(youtube.disconnect), child: const Text('연결 해제')),
        ],
        const Divider(height: 32),
        DropdownButtonFormField<bool>(initialValue: p.madeForKids,
          decoration: const InputDecoration(labelText: '앞으로 업로드할 영상의 아동용 여부 (필수)'),
          items: const [DropdownMenuItem(value: false, child: Text('아니요, 아동용이 아닙니다')), DropdownMenuItem(value: true, child: Text('예, 아동용입니다'))],
          onChanged: locked ? null : (value) => run(() async { p.madeForKids = value; await youtube.saveSettings(); })),
        SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
          title: const Text('사실적인 AI 생성·변형 콘텐츠'),
          subtitle: const Text('실제 인물·사건처럼 보이도록 생성·변형한 영상이면 켜세요.'),
          value: p.syntheticMedia, onChanged: locked ? null : (value) => run(() async { p.syntheticMedia = value; await youtube.saveSettings(); })),
        const Divider(height: 28),
        const Text('업로드 공개 방식',style:TextStyle(fontSize:19,fontWeight:FontWeight.w600)),
        const SizedBox(height:8),
        const Text('새 MP4 공개 범위'),
        DropdownButton<String>(
          value:p.publishMode,
          isExpanded:true,
          items:const [
            DropdownMenuItem(value:'private',child:Text('비공개 (기본값)')),
            DropdownMenuItem(value:'public',child:Text('업로드 후 즉시 전체 공개')),
            DropdownMenuItem(value:'scheduled',child:Text('주기별 예약 공개')),
          ],
          onChanged:locked?null:(mode){if(mode!=null)selectMode(mode);},
        ),
        if(p.publishMode=='scheduled')...[
          const SizedBox(height:10),
          DropdownButtonFormField<int>(
            key:ValueKey('cadence_${p.cadenceHours}'),
            initialValue:p.cadenceHours,
            decoration:const InputDecoration(labelText:'공개 주기'),
            items:const [
              DropdownMenuItem(value:24,child:Text('매일')),
              DropdownMenuItem(value:48,child:Text('2일마다')),
              DropdownMenuItem(value:72,child:Text('3일마다')),
              DropdownMenuItem(value:168,child:Text('매주')),
            ],
            onChanged:locked?null:(interval)async{
              if(interval==null)return;
              await run(()async{p.cadenceHours=interval;await youtube.saveSettings();});
            },
          ),
          TextButton.icon(onPressed:locked?null:pickPublishTime,
            icon:const Icon(Icons.schedule_outlined),
            label:Text('게시 시각 ${p.publishHour.toString().padLeft(2,'0')}:'
              '${p.publishMinute.toString().padLeft(2,'0')} (휴대폰 현지시간)')),
          Builder(builder:(context){
            final next=YouTubeCadence.nextUtc(now:DateTime.now(),
              intervalHours:p.cadenceHours,hour:p.publishHour,minute:p.publishMinute,
              previousUtc:DateTime.tryParse(p.lastScheduledAtUtc)).toLocal();
            return Text('다음 자동 게시 예정: ${next.toString().substring(0,16)}');
          }),
          const Text('영상은 지금 YouTube에 비공개로 올리고, '
            '예약 날짜에 YouTube에서 자동 공개합니다. '
            '새 영상 자동 제작은 앱 실행 또는 제작 프로세스가 필요합니다.',
            style:TextStyle(fontSize:12)),
        ],
        const Divider(height: 28),
        const Text('매일 자동 검색·제작·업로드',
          style:TextStyle(fontSize:19,fontWeight:FontWeight.w600)),
        const SizedBox(height:7),
        const Text('위의 예약 공개는 이미 만들어진 영상을 업로드한 뒤 '
          'YouTube가 공개할 시각만 예약하는 기능이에요. '
          '매일 새 영상 검색부터 Gemini 편집, MP4 제작, 업로드까지 '
          '앱을 닫은 상태에서 실행하려면 별도의 GitHub 클라우드 자동화를 설정해야 합니다.',
          style:TextStyle(fontSize:12)),
        const SizedBox(height:8),
        OutlinedButton.icon(
          onPressed:locked?null:()async{
            const url='https://github.com/dmc0306/gpt-shorts-studio/'
              'actions/workflows/configure-daily-publish.yml';
            await Clipboard.setData(const ClipboardData(text:url));
            if(!mounted)return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content:Text('클라우드 자동화 설정 링크를 복사했어요. '
                '브라우저에 붙여넣어 GitHub에서 예약 시각을 설정하세요.')));
          },
          icon:const Icon(Icons.content_copy),
          label:const Text('매일 자동 검색·업로드 설정 링크 복사'),
        ),
        const Text('새 클라우드 자동화는 기본적으로 꺼져 있으며, '
          'Gemini·Tavily·YouTube 연결과 재사용 권한 확인 뒤에만 동작해요.',
          style:TextStyle(fontSize:12)),
        if(widget.clips.any((c)=>c.savedUri.isNotEmpty))...[
          const SizedBox(height:10),
          OutlinedButton.icon(
            onPressed:locked?null:()=>Navigator.of(context).push(
              MaterialPageRoute(builder:(_)=>YouTubeBatchPublishScreen(clips:widget.clips))),
            icon:const Icon(Icons.queue_play_next),
            label:const Text('저장된 MP4 여러 개 공개·예약 업로드')),
        ],
        SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,title:const Text('완성 MP4 자동 업로드'),
          subtitle:const Text('켜면 앞으로 저장하는 MP4가 선택한 공개 방식으로 업로드돼요. '
            '이미 비공개로 올린 영상은 자동으로 공개되지 않습니다.'),
          value: p.automatic, onChanged: locked || !p.confirmed ? null : (value) => run(() => youtube.setAutomatic(value))),
        if (!p.confirmed) const Text('실제 채널 확인과 아동용 여부 선택 후 자동 업로드를 켤 수 있어요.'),
        const Text('연결·전송에 실패해도 저장한 MP4는 유지돼요.'),
        const Divider(height: 32),
        ExpansionTile(title: const Text('다른 연결 방식·이전 진단'), children: [
          OutlinedButton.icon(onPressed: locked ? null : () => Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => const YouTubeProbeScreen())),
            icon: const Icon(Icons.science_outlined), label: const Text('Android 직접 인증 테스트 · PC 없이')),
          TextField(controller: serverUrl, enabled: !locked, keyboardType: TextInputType.url, autocorrect: false,
            decoration: const InputDecoration(labelText: '인증 서버 주소', hintText: 'https://auth.example.com')),
          TextField(controller: serverKey, enabled: !locked, obscureText: true, autocorrect: false, enableSuggestions: false,
            decoration: const InputDecoration(labelText: '서버 연결 키', helperText: '기존 서버 방식을 사용할 때만 입력하세요.')),
          OutlinedButton(onPressed: locked ? null : () => run(() async {
            if (serverKey.text.trim().isEmpty) {
              final saved = await youtube.server.configuredUrl();
              if (saved != serverUrl.text.trim().replaceAll(RegExp(r'/$'), '')) throw const YouTubeFailure('서버를 변경할 때는 연결 키가 필요해요.');
              await youtube.reconnectServer();
            } else { await youtube.connectServer(serverUrl.text, serverKey.text); }
            serverKey.clear();
          }), child: const Text('기존 인증 서버로 연결')),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.connectBrowser), child: const Text('기존 PC 중계 방식으로 연결')),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.connect), child: const Text('기존 Google 계정 연결')),
        ]),
      ]);
    }),
  );
}
