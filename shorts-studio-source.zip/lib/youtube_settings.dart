import 'package:flutter/material.dart';
import 'youtube.dart';
import 'youtube_upload.dart';
import 'youtube_probe.dart';

class YouTubeSettingsScreen extends StatefulWidget {
  const YouTubeSettingsScreen({super.key});
  @override
  State<YouTubeSettingsScreen> createState() => _YouTubeSettingsState();
}

class _YouTubeSettingsState extends State<YouTubeSettingsScreen> {
  final youtube = YouTube.instance;
  final serverUrl = TextEditingController();
  final serverKey = TextEditingController();
  bool busy = true;
  String? error;
  @override
  void dispose() {
    youtube.pc.cancelled = true;
    youtube.server.cancelled = true;
    serverUrl.dispose();
    serverKey.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    run(() async {
      await youtube.initialize();
      final url = await youtube.server.configuredUrl();
      if (mounted) serverUrl.text = url;
    });
  }

  Future<void> run(Future<void> Function() action) async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await action();
    } catch (e) {
      if (mounted) setState(() => error = youtubeError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('유튜브 채널 · 자동 업로드')),
    body: ListenableBuilder(
      listenable: youtube,
      builder: (context, _) {
        final p = youtube.preferences;
        final locked = busy || youtube.uploading;
        return ListView(
          padding: const EdgeInsets.all(24),
          children: [
            OutlinedButton.icon(
              onPressed: locked ? null : () => Navigator.of(context).push<void>(
                MaterialPageRoute(builder: (_) => const YouTubeProbeScreen())),
              icon: const Icon(Icons.science_outlined),
              label: const Text('Android 직접 인증 테스트 · PC 없이'),
            ),
            const Text('업로드할 채널을 확인하세요', style: TextStyle(fontSize: 24)),
            const SizedBox(height: 12),
            const Text('모든 영상은 비공개로 전송해요. 공개·예약은 YouTube Studio에서 설정하세요.'),
            const SizedBox(height: 20),
            TextField(
              controller: serverUrl,
              enabled: !locked,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(labelText: '인증 서버 주소', hintText: 'https://auth.example.com'),
            ),
            TextField(
              controller: serverKey,
              enabled: !locked,
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(labelText: '서버 연결 키', helperText: '최초 연결·서버 변경 때 입력해요. 암호화해 보관합니다.'),
            ),
            FilledButton.icon(
              onPressed: locked ? null : () => run(() async {
                if (serverKey.text.trim().isEmpty) {
                  final saved = await youtube.server.configuredUrl();
                  if (saved != serverUrl.text.trim().replaceAll(RegExp(r'/$'), '')) {
                    throw const YouTubeFailure('서버를 변경할 때는 연결 키가 필요해요.');
                  }
                  // Reuse the encrypted key without exposing it in the UI.
                  await youtube.reconnectServer();
                } else {
                  await youtube.connectServer(serverUrl.text, serverKey.text);
                }
                serverKey.clear();
              }),
              icon: const Icon(Icons.cloud_outlined),
              label: const Text('인증 서버로 채널 연결 · PC 없이 사용'),
            ),
            const Text('처음에 브라우저에서 채널을 선택하면 서버가 인증을 갱신해요. 영상은 휴대폰에서 YouTube로 직접 전송합니다.'),
            const Divider(height: 32),
            Text(
              youtube.serverMode ? '인증 서버 연결'
                  : youtube.pcMode
                  ? '휴대폰 브라우저 인증 · PC 중계'
                  : youtube.user?.email ?? '연결된 계정이 없어요',
            ),
            FilledButton.icon(
              onPressed: locked ? null : () => run(youtube.connectBrowser),
              icon: const Icon(Icons.open_in_browser),
              label: const Text('기존 PC 중계 방식으로 연결'),
            ),
            const Text(
              'PC 중계 방식을 선택한 경우에만 PC 인증 도구와 ADB가 필요해요. 위의 인증 서버 방식은 PC 연결 없이 사용합니다.',
            ),
            if (busy) const LinearProgressIndicator(),
            if (error != null)
              Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            if (youtube.pc.pending || youtube.server.pending)
              TextButton(
                onPressed: () {
                  youtube.pc.cancelled = true;
                  youtube.server.cancelled = true;
                },
                child: const Text('브라우저 인증 대기 중단'),
              ),
            FilledButton.icon(
              onPressed: locked ? null : () => run(youtube.connect),
              icon: const Icon(Icons.account_circle_outlined),
              label: Text(
                youtube.user == null
                    ? '기존 Google 계정 연결'
                    : '채널 변경 · 권한 초기화 후 재연결',
              ),
            ),
            if (youtube.connected)
              TextButton(
                onPressed: locked ? null : () => run(youtube.disconnect),
                child: const Text('연결 해제'),
              ),
            if (youtube.channel != null) ...[
              const Divider(height: 32),
              const Text('현재 권한의 실제 채널'),
              Text(
                youtube.channel!.title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SelectableText(youtube.channel!.id),
              OutlinedButton(
                onPressed: locked ? null : () => run(youtube.confirmChannel),
                child: const Text('이 채널로 업로드 확인'),
              ),
            ],
            if (p.channelId.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text('확인한 업로드 대상: ${p.channelTitle}'),
              SelectableText(p.channelId),
            ],
            if (youtube.connected)
              TextButton(
                onPressed: locked ? null : () => run(youtube.refreshChannel),
                child: const Text('실제 채널 다시 조회'),
              ),
            const SizedBox(height: 12),
            const Text(
              '브라우저에서 원하는 브랜드 계정을 선택하고, 아래에 표시되는 실제 채널 이름과 ID를 확인하세요. 데스크톱 사이트 설정만으로 채널 선택이 보장되지는 않아요.',
            ),
            const Divider(height: 32),
            DropdownButtonFormField<bool>(
              initialValue: p.madeForKids,
              decoration: const InputDecoration(
                labelText: '앞으로 업로드할 영상의 아동용 여부 (필수)',
              ),
              items: const [
                DropdownMenuItem(value: false, child: Text('아니요, 아동용이 아닙니다')),
                DropdownMenuItem(value: true, child: Text('예, 아동용입니다')),
              ],
              onChanged: locked
                  ? null
                  : (value) => run(() async {
                      p.madeForKids = value;
                      await youtube.saveSettings();
                    }),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('사실적인 AI 생성·변형 콘텐츠'),
              subtitle: const Text(
                '다음 업로드부터 적용해요. 실제 인물·사건처럼 보이도록 생성·변형한 영상이면 켜세요.',
              ),
              value: p.syntheticMedia,
              onChanged: locked
                  ? null
                  : (value) => run(() async {
                      p.syntheticMedia = value;
                      await youtube.saveSettings();
                    }),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('완성 MP4 자동 업로드'),
              subtitle: const Text(
                '수동 저장과 자동 제작의 새 완성본을 모두 전송해요. 모바일 데이터가 사용될 수 있어요.',
              ),
              value: p.automatic,
              onChanged: locked || !p.confirmed
                  ? null
                  : (value) => run(() => youtube.setAutomatic(value)),
            ),
            if (!p.confirmed)
              const Text('채널 확인과 아동용 여부 선택을 완료하면 자동 업로드를 켤 수 있어요.'),
            const Text('전송 실패 시 완성 MP4는 유지돼요. 저장함에서 영상을 열어 이어 올릴 수 있어요.'),
          ],
        );
      },
    ),
  );
}
