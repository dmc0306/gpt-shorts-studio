import 'package:flutter/material.dart';
import 'youtube.dart';
import 'youtube_probe.dart';
import 'youtube_upload.dart';

class YouTubeSettingsScreen extends StatefulWidget {
  const YouTubeSettingsScreen({super.key});
  @override State<YouTubeSettingsScreen> createState() => _YouTubeSettingsState();
}
class _YouTubeSettingsState extends State<YouTubeSettingsScreen> {
  final youtube = YouTube.instance;
  final serverUrl = TextEditingController(), serverKey = TextEditingController();
  bool busy = true;
  String? error, notice;
  @override void initState() {
    super.initState();
    run(() async {
      // Opening settings should not authenticate a personal Google identity first.
      await youtube.loadSettings();
      if (youtube.chromeMode) await youtube.initialize();
      final url = await youtube.server.configuredUrl();
      if (mounted) serverUrl.text = url;
    });
  }
  @override void dispose() {
    youtube.pc.cancelled = true;
    youtube.server.cancelled = true;
    if (youtube.chrome.pending) youtube.chrome.cancel().catchError((_) {});
    serverUrl.dispose(); serverKey.dispose();
    super.dispose();
  }
  Future<void> run(Future<void> Function() action) async {
    setState(() { busy = true; error = null; notice = null; });
    try { await action(); }
    catch (e) { if (mounted) setState(() => error = youtubeError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('유튜브 채널 · 자동 업로드')),
    body: ListenableBuilder(listenable: youtube, builder: (context, _) {
      final p = youtube.preferences;
      final locked = busy || youtube.uploading;
      return ListView(padding: const EdgeInsets.all(24), children: [
        const Text('휴대폰 Chrome으로 연결', style: TextStyle(fontSize: 24)),
        const SizedBox(height: 12),
        const Text('휴대폰에 설치된 Chrome에서 Google 계정·브랜드 채널을 선택하면 앱으로 돌아와요. PC·ADB·별도 인증 서버는 필요 없어요.'),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: locked ? null : () => run(youtube.connectChrome),
          icon: const Icon(Icons.open_in_browser), label: const Text('Chrome에서 로그인 · 브랜드 채널 선택')),
        const Text('최초 설정: Google Cloud Android 클라이언트의 Custom URI scheme 허용을 켜고 저장하세요.'),
        if (busy) const LinearProgressIndicator(),
        if (youtube.chrome.pending || youtube.pc.pending || youtube.server.pending)
          TextButton(onPressed: () {
            youtube.pc.cancelled = true; youtube.server.cancelled = true;
            if (youtube.chrome.pending) youtube.chrome.cancel();
          }, child: const Text('브라우저 인증 대기 중단')),
        if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        if (notice != null) Text(notice!),
        if (youtube.chromeMode && youtube.chrome.hasGrant) ...[
          Text(youtube.chrome.hasRefreshToken ? '인증 정보 암호화 저장됨 · 갱신 권한 있음' : '갱신 권한 없음 · 인증 만료 시 재연결 필요'),
          OutlinedButton.icon(onPressed: locked ? null : () => run(() async {
            await youtube.verifyChromeRefresh();
            if (mounted) setState(() => notice = '인증 갱신과 채널 재조회에 성공했어요.');
          }), icon: const Icon(Icons.refresh), label: const Text('인증 갱신 확인 · 업로드 없음')),
        ],
        if (youtube.channel != null) ...[
          const Divider(height: 32), const Text('현재 권한의 실제 채널'),
          Text(youtube.channel!.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          SelectableText(youtube.channel!.id),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.confirmChannel), child: const Text('이 채널로 업로드 확인')),
        ],
        if (p.channelId.isNotEmpty) ...[
          const SizedBox(height: 12), Text('확인한 업로드 대상: ${p.channelTitle}'), SelectableText(p.channelId),
        ],
        if (youtube.connected) ...[
          TextButton(onPressed: locked ? null : () => run(youtube.refreshChannel), child: const Text('실제 채널 다시 조회')),
          TextButton(onPressed: locked ? null : () => run(youtube.disconnect), child: const Text('연결 해제')),
        ],
        const Divider(height: 32),
        DropdownButtonFormField<bool>(initialValue: p.madeForKids,
          decoration: const InputDecoration(labelText: '앞으로 업로드할 영상의 아동용 여부 (필수)'),
          items: const [DropdownMenuItem(value: false, child: Text('아니요, 아동용이 아닙니다')), DropdownMenuItem(value: true, child: Text('예, 아동용입니다'))],
          onChanged: locked ? null : (value) => run(() async { p.madeForKids = value; await youtube.saveSettings(); })),
        SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
          title: const Text('사실적인 AI 생성·변형 콘텐츠'),
          subtitle: const Text('실제 인물·사건처럼 보이도록 생성·변형한 영상이면 켜세요.'),
          value: p.syntheticMedia, onChanged: locked ? null : (value) => run(() async { p.syntheticMedia = value; await youtube.saveSettings(); })),
        SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, title: const Text('완성 MP4 자동 업로드'),
          subtitle: const Text('수동 저장과 자동 제작의 새 완성본을 비공개로 전송해요. 공개·예약은 YouTube Studio에서 설정하세요.'),
          value: p.automatic, onChanged: locked || !p.confirmed ? null : (value) => run(() => youtube.setAutomatic(value))),
        if (!p.confirmed) const Text('실제 채널 확인과 아동용 여부 선택 후 자동 업로드를 켤 수 있어요.'),
        const Text('연결·전송에 실패해도 저장한 MP4는 유지돼요.'),
        const Divider(height: 32),
        ExpansionTile(title: const Text('다른 연결 방식·이전 진단'), children: [
          OutlinedButton.icon(onPressed: locked ? null : () => Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => const YouTubeProbeScreen())),
            icon: const Icon(Icons.science_outlined), label: const Text('Android 직접 인증 테스트 · PC 없이')),
          TextField(controller: serverUrl, enabled: !locked, keyboardType: TextInputType.url, autocorrect: false,
            decoration: const InputDecoration(labelText: '인증 서버 주소', hintText: 'https://auth.example.com')),
          TextField(controller: serverKey, enabled: !locked, obscureText: true, autocorrect: false, enableSuggestions: false,
            decoration: const InputDecoration(labelText: '서버 연결 키', helperText: '기존 서버 방식을 사용할 때만 입력하세요.')),
          OutlinedButton(onPressed: locked ? null : () => run(() async {
            if (serverKey.text.trim().isEmpty) {
              final saved = await youtube.server.configuredUrl();
              if (saved != serverUrl.text.trim().replaceAll(RegExp(r'/$'), '')) throw const YouTubeFailure('서버를 변경할 때는 연결 키가 필요해요.');
              await youtube.reconnectServer();
            } else { await youtube.connectServer(serverUrl.text, serverKey.text); }
            serverKey.clear();
          }), child: const Text('기존 인증 서버로 연결')),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.connectBrowser), child: const Text('기존 PC 중계 방식으로 연결')),
          OutlinedButton(onPressed: locked ? null : () => run(youtube.connect), child: const Text('기존 Google 계정 연결')),
        ]),
      ]);
    }),
  );
}
