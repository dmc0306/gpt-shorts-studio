class Clip {
  Clip({required this.id, required this.name, this.path='', this.thumbnail='', this.url='', this.creator='', this.duration=15, this.headline='', this.caption='', this.style=0, this.mute=false, this.crop=false, this.start=0, double? end, this.savedUri='', this.savedAt=''}) : end=end??duration;
  final String id;
  String name,path,thumbnail,url,creator,headline,caption,savedUri,savedAt;
  double duration,start,end;
  int style;
  bool mute,crop;
  bool get ready=>path.isNotEmpty;
  factory Clip.fromJson(Map<String,dynamic> j)=>Clip(id:j['id'] as String,name:j['name'] as String? ?? '새 영상',path:j['path'] as String? ?? '',thumbnail:j['thumbnail'] as String? ?? '',url:j['url'] as String? ?? '',creator:j['creator'] as String? ?? '',duration:(j['duration'] as num? ?? 15).toDouble(),headline:j['headline'] as String? ?? '',caption:j['caption'] as String? ?? '',style:j['style'] as int? ?? 0,mute:j['mute'] as bool? ?? false,crop:j['crop'] as bool? ?? false,start:(j['start'] as num? ?? 0).toDouble(),end:(j['end'] as num?)?.toDouble(),savedUri:j['savedUri'] as String? ?? '',savedAt:j['savedAt'] as String? ?? '');
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'path':path,'thumbnail':thumbnail,'url':url,'creator':creator,'duration':duration,'headline':headline,'caption':caption,'style':style,'mute':mute,'crop':crop,'start':start,'end':end,'savedUri':savedUri,'savedAt':savedAt};
}
String? tiktokUrl(String text) {
  for(final match in RegExp(r'https://[^\s<>]+').allMatches(text)){
    final value=match.group(0)!.replaceAll(RegExp(r'[),.!]+$'),'');
    final uri=Uri.tryParse(value);
    if(uri!=null && (uri.host=='tiktok.com'||uri.host.endsWith('.tiktok.com')) && uri.userInfo.isEmpty && (!uri.hasPort||uri.port==443)) return value;
  }
  return null;
}
