class TimedCaption {
 TimedCaption({required this.start,required this.end,required this.text});
 double start,end;
 String text;
 factory TimedCaption.fromJson(Map<String,dynamic> j)=>TimedCaption(start:(j['start'] as num).toDouble(),end:(j['end'] as num).toDouble(),text:j['text'] as String);
 Map<String,dynamic> toJson()=>{'start':start,'end':end,'text':text};
}
class Clip {
  Clip({required this.id, required this.name, this.path='', this.thumbnail='', this.url='', this.creator='', this.duration=15, this.headline='', this.caption='', this.style=0, this.mute=false, this.crop=true, this.start=0, double? end, this.savedUri='', this.savedAt='', this.downloadError='',List<TimedCaption>? timedCaptions}) : end=end??duration,timedCaptions=timedCaptions??[];
  final String id;
  List<TimedCaption> timedCaptions;
  String name,path,thumbnail,url,creator,headline,caption,savedUri,savedAt,downloadError;
  double duration,start,end;
  int style;
  bool mute,crop;
  bool get ready=>path.isNotEmpty;
  factory Clip.fromJson(Map<String,dynamic> j)=>Clip(id:j['id'] as String,name:j['name'] as String? ?? '새 영상',path:j['path'] as String? ?? '',thumbnail:j['thumbnail'] as String? ?? '',url:j['url'] as String? ?? '',creator:j['creator'] as String? ?? '',duration:(j['duration'] as num? ?? 15).toDouble(),headline:j['headline'] as String? ?? '',caption:j['caption'] as String? ?? '',style:j['style'] as int? ?? 0,mute:j['mute'] as bool? ?? false,crop:j['crop'] as bool? ?? true,start:(j['start'] as num? ?? 0).toDouble(),end:(j['end'] as num?)?.toDouble(),savedUri:j['savedUri'] as String? ?? '',savedAt:j['savedAt'] as String? ?? '',downloadError:j['downloadError'] as String? ?? '',timedCaptions:(j['timedCaptions'] as List? ?? []).map((v)=>TimedCaption.fromJson(Map<String,dynamic>.from(v as Map))).toList());
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'path':path,'thumbnail':thumbnail,'url':url,'creator':creator,'duration':duration,'headline':headline,'caption':caption,'style':style,'mute':mute,'crop':crop,'start':start,'end':end,'savedUri':savedUri,'savedAt':savedAt,'downloadError':downloadError,'timedCaptions':timedCaptions.map((t)=>t.toJson()).toList()};
}
String? tiktokUrl(String text) {
  for(final match in RegExp(r'https://[^\s<>]+').allMatches(text)){
    final value=match.group(0)!.replaceAll(RegExp(r'[),.!]+$'),'');
    final uri=Uri.tryParse(value);
    if(uri!=null && (uri.host=='tiktok.com'||uri.host.endsWith('.tiktok.com')) && uri.userInfo.isEmpty && (!uri.hasPort||uri.port==443)) return value;
  }
  return null;
}
