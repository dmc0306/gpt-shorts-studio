import 'dart:convert';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'ai.dart';
import 'ai_settings.dart';
import 'bridge.dart';
import 'discovery.dart';
import 'discovery_store.dart';
import 'overlay_renderer.dart';
import 'model.dart';
import 'theme.dart';
import 'tiktok_download.dart';

class AutoBatchScreen extends StatefulWidget {
 const AutoBatchScreen({super.key,required this.clips,required this.onSave});
 final List<Clip> clips;
 final Future<void> Function() onSave;
 @override State<AutoBatchScreen> createState()=>_AutoBatchState();
}
class _AutoBatchState extends State<AutoBatchScreen> {
 final keyInput=TextEditingController();
 static const batchChannel=MethodChannel('studio.local/batch');
 Timer? stopPoll;
 int savedCount=0,searchRound=0;
 bool pollBusy=false;
 final reports=<Map<String,dynamic>>[];
 DiscoveryStore store=DiscoveryStore();
 String searchKey='';
 bool starting=false,notifications=true,loading=true,running=false,stopping=false,rendering=false;
 String status='혼합 주제 영상 5개를 자동 제작해요.',model=GeminiCaptions.defaultModel;
 MixedDiscovery? finder;TikTokDownloader? downloader;GeminiCaptions? analyzer;
 @override void initState(){super.initState();batchChannel.setMethodCallHandler((call)async{if(call.method=='stop'&&running)await stop();});load();}
 Future<void> load()async{
  try{
   final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
   keyInput.text=settings['key'] as String? ?? '';searchKey=settings['searchKey'] as String? ?? '';model=settings['model'] as String? ?? model;
   final raw=await Native.call<String>('loadBatchReport')??'{}';
   final report=jsonDecode(raw) as Map;
   store=DiscoveryStore.fromJson(report['discovery'] as Map? ?? {});
   savedCount=(report['saved'] as num?)?.toInt()??0;status=report['status'] as String? ?? status;
   reports.addAll((report['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)));
   if(report['running']==true){status='이전 작업이 중단됐어요. 완료한 영상은 저장함에 남아 있어요.';for(final item in reports){if(!['저장 완료','실패','제외'].contains(item['state']))item['state']='중단';}}
  }catch(_){status='이전 작업 정보를 불러오지 못했어요. 새 작업을 시작할 수 있어요.';}
  if(mounted)setState(()=>loading=false);
 }
 Future<void> settings()async{
  if(running||loading)return;
  if(!await showAiSettings(context)||!mounted)return;
  final values=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
  if(!mounted)return;
  setState((){keyInput.text=values['key'] as String? ?? '';searchKey=values['searchKey'] as String? ?? '';model=values['model'] as String? ?? GeminiCaptions.defaultModel;status='AI 설정을 저장했어요.';});
 }
 @override void dispose(){stopPoll?.cancel();batchChannel.setMethodCallHandler(null);finder?.cancel();downloader?.cancel();analyzer?.cancel();keyInput.dispose();super.dispose();}
 Future<void> saveReport()async{await Native.call('saveBatchReport',{'json':jsonEncode({'running':running,'status':status,'saved':savedCount,'searchRound':searchRound,'updatedAt':DateTime.now().toIso8601String(),'items':reports,'discovery':store.toJson()})});}
 void update(String value){if(mounted)setState(()=>status=value);if(running)unawaited(Native.call('batchStatus',{'status':value,'saved':savedCount}).catchError((_)=>null));}
 void check(){if(stopping||!mounted)throw const AiFailure('작업을 중단했어요.');}
 Future<void> stop()async{
  if(stopping)return;setState(()=>stopping=true);finder?.cancel();downloader?.cancel();analyzer?.cancel();
  if(rendering){try{await Native.call('cancelExport');}catch(_){/* Publishing finishes safely before the queue stops. */}}
  update('진행 중인 작업을 정리한 뒤 중단해요.');
 }
 Future<void> render(Clip clip)async{
  check();
  final title=await renderOverlayPng(headline:clip.headline,caption:'',style:clip.style);
  final overlays=<Map<String,dynamic>>[];
  for(final t in clip.timedCaptions){
   check();
   overlays.add({'startUs':((t.start-clip.start)*1000000).round(),'endUs':((t.end-clip.start)*1000000).round(),'png':await renderOverlayPng(headline:clip.headline,caption:t.text,style:clip.style,subtitleOnly:true)});
  }
  check();rendering=true;
  try{
   final uri=await Native.call<String>('export',{'path':clip.path,'overlay':title,'timedOverlays':overlays,'startMs':(clip.start*1000).round(),'endMs':(clip.end*1000).round(),'mute':clip.mute,'crop':clip.crop});
   if(uri==null)throw StateError('저장 결과를 받지 못했어요.');
   clip.savedUri=uri;clip.savedAt=DateTime.now().toIso8601String();await widget.onSave();
  }finally{rendering=false;}
 }
 Future<void> start()async{
  final key=keyInput.text.trim();if(running||loading||starting)return;
  if(key.isEmpty||searchKey.isEmpty){update('AI 설정에서 Gemini 키와 Tavily 검색 키를 입력해 주세요.');await settings();return;}
  FocusScope.of(context).unfocus();
  setState(()=>starting=true);
  try{notifications=await Native.call<bool>('batchNotifications')??false;}catch(e){update('알림 준비에 실패했어요: $e');if(mounted)setState(()=>starting=false);return;}
  if(!mounted)return;
  setState(()=>starting=false);
  setState((){running=true;stopping=false;savedCount=0;searchRound=0;reports.clear();status='혼합 주제 탐색 시작';});
  var saved=0;var fatal=false;
  store.seen.addAll(widget.clips.where((c)=>c.savedUri.isNotEmpty).map((c)=>MixedDiscovery.videoId(c.url)).whereType<String>());
  store.queue.removeWhere((c)=>store.seen.contains(MixedDiscovery.videoId(c.url)));
  final usedQueries=<String>{};var cursor=0;var processed=0;
  final exhausted=<String>{};
  try{
   await Native.call('saveAiSettings',{'key':key,'model':model});
   await Native.call('batchStart');await saveReport();
   stopPoll=Timer.periodic(const Duration(seconds:2),(_)async{
    if(pollBusy||!running||stopping)return;pollBusy=true;
    try{if(await Native.call<bool>('batchShouldStop')==true&&mounted&&running)await stop();}catch(_){}finally{pollBusy=false;}
   });
   while(saved<5&&!stopping&&!fatal&&processed<60){
    check();
    VideoCandidate? selected;
    for(var offset=0;offset<3;offset++){
     final index=(cursor+offset)%3;final topic=MixedDiscovery.topics[index];
     selected=store.next(topic);
     if(selected==null&&!exhausted.contains(topic)&&searchRound<9){
      final available=MixedDiscovery.queries[index].where((q)=>!usedQueries.contains(q));
      if(available.isEmpty){exhausted.add(topic);continue;}
      final query=store.queryFor(index,usedQueries);usedQueries.add(query);searchRound++;
      store.count(query,'searches');await saveReport();
      finder=MixedDiscovery();
      final found=await finder!.discover(key:searchKey,excluded:store.excluded,query:query,topic:topic,onStatus:(s)=>update('$saved/5 저장 완료 · 검색 $searchRound/9 · $s'));finder=null;check();
      store.add(found);await saveReport();selected=store.next(topic);
     }
     if(selected!=null){cursor=(index+1)%3;break;}
    }
    if(selected==null){
     if(searchRound>=9||exhausted.length==3)break;
     continue;
    }
    final candidate=selected;processed++;
    store.count(candidate.query,'attempted');store.accountCount(candidate.url,'attempted');
    final item=<String,dynamic>{'url':candidate.url,'topic':candidate.topic,'title':candidate.title,'state':'다운로드','error':'','query':candidate.query};
    setState(()=>reports.add(item));await saveReport();
    try{
     check();update('${saved}/5 저장 완료 · ${candidate.topic} 원본 다운로드');
     Clip? clip=widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(candidate.url)).firstOrNull;
     if(clip==null||!clip.ready){
      downloader=TikTokDownloader();
      final raw=await downloader!.download(candidate.url,(progress,stage)=>update('${saved}/5 완료 · $stage'));downloader=null;check();
      final downloaded=Clip.fromJson(raw);
      if(clip==null){clip=downloaded;clip.url=candidate.url;widget.clips.insert(0,clip);}
      else{clip.path=downloaded.path;clip.thumbnail=downloaded.thumbnail;clip.duration=downloaded.duration;clip.name=downloaded.name;clip.creator=downloaded.creator;clip.downloadError='';}
      await widget.onSave();
     }
     store.count(candidate.query,'downloaded');
     final current=clip;
     if(current.duration<5||current.duration>30){item['state']='제외';item['error']='길이 ${current.duration.toStringAsFixed(1)}초 · 사용 범위 5~30초';await saveReport();continue;}
     current.start=0;current.end=current.duration;current.crop=true;current.style=0;current.mute=false;
     item['state']='AI 생성';item['title']=current.name;await saveReport();
     analyzer=GeminiCaptions();
     final draft=await analyzer!.generate(clip:current,key:key,model:model,assessEntertainment:true,onStatus:(s)=>update('${saved}/5 완료 · $s'));analyzer=null;check();
     item['score']=draft.entertainmentScore;item['quality']=draft.quality.toJson();
     if(!draft.quality.acceptable){item['state']='제외';item['error']='${draft.quality.edited?'편집본':draft.quality.aiSuspected?'AI 영상 의심':'원본 판단 불확실'} · ${draft.quality.reason}';await saveReport();continue;}
     if(draft.entertainmentScore<55){item['state']='제외';item['error']='AI 혼합 주제 적합도 부족 (인기도 측정값이 아니에요)';await saveReport();continue;}
     store.count(candidate.query,'passed');
     current.headline=draft.headline;current.caption='';current.timedCaptions=draft.captions;await widget.onSave();
     item['state']='MP4 저장';await saveReport();update('${saved}/5 완료 · MP4 저장 중');
     await render(current);store.count(candidate.query,'saved');store.accountCount(candidate.url,'saved');saved++;savedCount=saved;item['state']='저장 완료';item['title']=current.headline;item['savedUri']=current.savedUri;update('$saved/5개 저장 완료');await saveReport();
    }catch(e){
     item['state']=stopping?'중단':'실패';item['error']=e.toString();await saveReport();
     // Quota and credential errors would affect every remaining candidate.
     if(stopping||(e is AiFailure&&(e.message.contains('한도')||e.message.contains('권한')||e.message.contains('모델')))){fatal=true;break;}
    }finally{downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;if(!stopping&&!fatal)store.finish(candidate);await saveReport();}
   }
   update(stopping?'작업 중단 · $saved개 저장 완료':saved==5?'혼합 영상 5개 저장 완료':'$saved/5개 저장 완료 · ${fatal?'API 오류로 중단했어요':'검색·처리 한도에 도달했어요'}. 아래 결과를 확인하세요.');
  }catch(e){update(stopping?'작업 중단 · $saved개 저장 완료':'$saved/5개 저장 완료 · $e');}
  finally{
   stopPoll?.cancel();stopPoll=null;
   finder?.cancel();finder=null;downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;
   if(mounted)setState(()=>running=false);else running=false;
   try{await saveReport();}catch(_){}
   try{await Native.call('batchFinish',{'status':status,'saved':savedCount});}catch(_){}
  }
 }
 Future<void> recordFeedback(Map<String,dynamic> item,String label)async{
  final id=MixedDiscovery.videoId(item['url'] as String);if(id==null)return;
  setState(()=>store.feedback[id]={'label':label,'url':item['url'],'query':item['query'],'score':item['score'],'quality':item['quality'],'headline':item['title'],'updatedAt':DateTime.now().toIso8601String()});
  try{await saveReport();}catch(_){update('평가 저장에 실패했어요. 다시 눌러 주세요.');}
 }
 @override Widget build(BuildContext context)=>PopScope(canPop:!running,child:Scaffold(appBar:AppBar(title:const Text('혼합 영상 자동 제작',style:TextStyle(fontSize:18)),actions:[IconButton(tooltip:'AI 설정',onPressed:running||loading?null:settings,icon:const Icon(Icons.settings_outlined))]),body:SafeArea(child:ListView(padding:const EdgeInsets.all(24),children:[
   const Text('한 번에 5개',style:TextStyle(fontSize:30)),const SizedBox(height:12),
   const Text('웃긴 상황·반전 / 귀여운 동물 / 아기·가족\n주제별 공개 링크 탐색 → 다운로드 → AI 제목·자막 → MP4 저장',style:TextStyle(fontSize:14)),
   const SizedBox(height:16),OutlinedButton.icon(onPressed:running||loading?null:settings,icon:const Icon(Icons.settings_outlined),label:const Text('AI 설정 · 검색 키 / 생성 모델')),
   Text('검색: Tavily · ${searchKey.isEmpty?'키 필요':'키 등록됨'}\n제목·자막: $model · ${keyInput.text.isEmpty?'키 필요':'키 등록됨'}',style:const TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:12),const Text('원본 영상·소리를 Google로 전송해요. 무료 티어 데이터는 제품 개선에 사용될 수 있어요. 결제를 연결하지 않은 키를 사용하세요. Tavily 무료 요금제는 월 1,000크레딧, 실행당 검색은 최대 9회예요. 무료 사용량 한도가 적용돼요.',style:TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:16),const Text('한 편당 5~30초 · 제외·실패로 부족하면 새 후보를 찾아요. 대기 후보를 먼저 재사용하고 부족한 주제만 검색해요. 검색당 최대 20개를 보관하며 실행당 검색 9회·처리 60개까지 시도해요. 검색 색인·접근 제한으로 5개보다 적게 저장될 수 있어요. 편집본·AI 의심·판단 불확실 영상은 건너뛰어요. AI 판정은 틀릴 수 있으며 실제 인기도를 보장하지 않아요.',style:TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:20),if(loading)const LinearProgressIndicator(),if(running)LinearProgressIndicator(value:savedCount/5),const SizedBox(height:12),Text(status,style:const TextStyle(fontSize:14,color:blue)),
   if(running&&!notifications)const Text('작업 알림이 꺼져 있어요. 앱 설정에서 알림을 허용하면 진행 상황을 볼 수 있어요.',style:TextStyle(fontSize:12,color:muted)),
   if(running)const Padding(padding:EdgeInsets.only(top:8),child:Text('홈으로 나가거나 화면을 꺼도 계속 작업해요. 알림에서 진행 확인·중단할 수 있어요. 앱 강제 종료·최근 앱에서 제거하면 중단돼요.',style:TextStyle(fontSize:12,color:muted))),
   const SizedBox(height:12),ExpansionTile(tilePadding:EdgeInsets.zero,title:Text('대기 ${store.queue.length}개 · 검색 효율',style:const TextStyle(fontSize:14)),children:[for(final entry in store.metrics.entries)Padding(padding:const EdgeInsets.only(bottom:8),child:Text('${entry.key}\n검색 ${entry.value['searches']??0} · 신규 ${entry.value['found']??0} → 다운로드 ${entry.value['downloaded']??0} → 적합 ${entry.value['passed']??0} → 저장 ${entry.value['saved']??0}',style:const TextStyle(fontSize:12,color:muted)))]),
   const SizedBox(height:20),for(final item in reports)Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${item['state']} · ${item['topic']}',style:TextStyle(color:item['state']=='저장 완료'?blue:muted,fontSize:12)),const SizedBox(height:6),Text(item['title'] as String? ?? '',style:const TextStyle(fontSize:14)),if((item['error'] as String? ?? '').isNotEmpty)Text(item['error'] as String,style:const TextStyle(fontSize:12,color:muted)),if(['저장 완료','제외'].contains(item['state']))Wrap(spacing:6,children:[for(final label in ['괜찮음','재미없음','편집본','AI 의심'])ChoiceChip(label:Text(label,style:const TextStyle(fontSize:11)),selected:store.feedback[MixedDiscovery.videoId(item['url'] as String)]?['label']==label,onSelected:running?null:(_)=>recordFeedback(item,label))]),const SizedBox(height:6),SelectableText(item['url'] as String? ?? '',style:const TextStyle(fontSize:10,color:muted))])))
  ])),bottomNavigationBar:SafeArea(child:Padding(padding:const EdgeInsets.all(20),child:FilledButton.icon(onPressed:loading||starting||stopping?null:running?stop:start,icon:Icon(running?Icons.stop_rounded:Icons.auto_awesome),label:Text(running?'중단':'혼합 영상 5개 자동 제작'))))));
}

