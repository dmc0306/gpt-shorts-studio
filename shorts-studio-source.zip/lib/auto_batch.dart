import 'scene_selection.dart';
import 'deletion.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'editor.dart';
import 'playback.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'ai.dart';
import 'ai_settings.dart';
import 'bridge.dart';
import 'discovery.dart';
import 'discovery_store.dart';
import 'overlay_renderer.dart';
import 'caption_layout.dart';
import 'headline.dart';
import 'conversion_funnel.dart';
import 'original_text.dart';
import 'model.dart';
import 'theme.dart';
import 'tiktok_download.dart';

class AutoBatchScreen extends StatefulWidget {
 const AutoBatchScreen({super.key,required this.clips,required this.onSave});
 final List<Clip> clips;
 final Future<void> Function() onSave;
 @override State<AutoBatchScreen> createState()=>_AutoBatchState();
}
class _AutoBatchState extends State<AutoBatchScreen> {
 final keyInput=TextEditingController();
 static const batchChannel=MethodChannel('studio.local/batch');
 Timer? stopPoll;
 int savedCount=0,searchRound=0,previewCount=0;
 bool previewing=false;
 bool pollBusy=false,exitRequested=false,exitDialog=false;
 final reports=<Map<String,dynamic>>[];
 final searchLog=<Map<String,dynamic>>[];
 final checkpoints=<String,Map<String,dynamic>>{};
 DiscoveryStore store=DiscoveryStore();
 String searchKey='',resultFilter='전체',searchCategory='혼합 추천';
 bool starting=false,notifications=true,loading=true,running=false,stopping=false,rendering=false;
 String status='혼합 주제 영상 5개를 자동 제작해요.',model=GeminiCaptions.defaultModel;
 MixedDiscovery? finder;TikTokDownloader? downloader;GeminiCaptions? analyzer;
 @override void initState(){super.initState();batchChannel.setMethodCallHandler((call)async{if(call.method=='stop'&&running)await stop();});load();}
 Future<void> load()async{
  try{
   final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
   keyInput.text=settings['key'] as String? ?? '';searchKey=settings['searchKey'] as String? ?? '';model=settings['model'] as String? ?? model;
   final raw=await Native.call<String>('loadBatchReport')??'{}';
   final report=jsonDecode(raw) as Map;
   store=DiscoveryStore.fromJson(report['discovery'] as Map? ?? {});
   if(report['checkpoints'] is Map){(report['checkpoints'] as Map).forEach((id,value){if(id is String&&value is Map)checkpoints[id]=Map<String,dynamic>.from(value);});}
   final category=report['searchCategory'];if(category=='혼합 추천'||MixedDiscovery.topics.contains(category))searchCategory=category as String;
   previewing=report['previewing']==true;previewCount=(report['previewCount'] as num?)?.toInt()??0;
   searchRound=(report['searchRound'] as num?)?.toInt()??0;
   searchLog.addAll((report['searchLog'] as List? ?? []).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)));
   savedCount=(report['saved'] as num?)?.toInt()??0;status=report['status'] as String? ?? status;
   reports.addAll((report['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)));
   if(report['running']==true){status='이전 작업이 중단됐어요. 완료한 영상은 저장함에 남아 있어요.';for(final item in reports){if(!['저장 완료','실패','제외'].contains(item['state']))item['state']='중단';}}
  }catch(_){status='이전 작업 정보를 불러오지 못했어요. 새 작업을 시작할 수 있어요.';}
  if(mounted)setState(()=>loading=false);
 }
 Future<void> settings()async{
  if(running||loading)return;
  if(!await showAiSettings(context)||!mounted)return;
  final values=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
  if(!mounted)return;
  setState((){keyInput.text=values['key'] as String? ?? '';searchKey=values['searchKey'] as String? ?? '';model=values['model'] as String? ?? GeminiCaptions.defaultModel;status='앱 설정을 저장했어요.';});
 }
 @override void dispose(){stopPoll?.cancel();batchChannel.setMethodCallHandler(null);finder?.cancel();downloader?.cancel();analyzer?.cancel();keyInput.dispose();super.dispose();}
 Future<void> saveReport()async{await Native.call('saveBatchReport',{'json':jsonEncode({'running':running,'status':status,'saved':savedCount,'previewing':previewing,'previewCount':previewCount,'searchCategory':searchCategory,'searchRound':searchRound,'searchLog':searchLog,'updatedAt':DateTime.now().toIso8601String(),'items':reports,'checkpoints':checkpoints,'discovery':store.toJson()})});}
 void update(String value){if(mounted)setState(()=>status=value);if(running)unawaited(Native.call('batchStatus',{'status':value,'saved':savedCount}).catchError((_)=>null));}
 void check(){if(stopping||!mounted)throw const AiFailure('작업을 중단했어요.');}
 Future<void> requestExit()async{
  if(exitRequested||exitDialog)return;
  if(!running){if(!starting)Navigator.pop(context);return;}
  exitDialog=true;
  final leave=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('제작을 중단하고 나갈까요?'),content:const Text('완료한 영상은 유지하고, 진행 상황을 저장한 뒤 이전 화면으로 돌아갑니다. 나중에 남은 제작을 재개할 수 있어요.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('계속 제작')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('중단하고 나가기'))]));
  exitDialog=false;if(!mounted||leave!=true)return;
  if(!running){Navigator.pop(context);return;}
  exitRequested=true;await stop();
 }
 Future<void> stop()async{
  if(stopping)return;setState(()=>stopping=true);finder?.cancel();downloader?.cancel();analyzer?.cancel();
  try{await Native.call('cancelTextScan');}catch(_){}
  if(rendering){try{await Native.call('cancelExport');}catch(_){/* Publishing finishes safely before the queue stops. */}}
  update('진행 중인 작업을 정리한 뒤 중단해요.');
 }
 Future<void> render(Clip clip)async{
  check();
  final title=await renderOverlayPng(headline:clip.headline,caption:'',style:clip.style);
  final overlays=<Map<String,dynamic>>[];
  for(final t in clip.timedCaptions){
   check();
   overlays.add({'startUs':((t.start-clip.start)*1000000).round(),'endUs':((t.end-clip.start)*1000000).round(),'topPx':placeCaption(t.text,cue:t,clip:clip).stripTop,'png':await renderOverlayPng(headline:'',caption:t.text,style:clip.style,subtitleOnly:true,cue:t,clip:clip)});
  }
  check();rendering=true;
  try{
   final uri=await Native.call<String>('export',{'path':clip.path,'overlay':title,'timedOverlays':overlays,'startMs':(clip.start*1000).round(),'endMs':(clip.end*1000).round(),'mute':clip.mute,'crop':clip.crop});
   if(uri==null)throw StateError('저장 결과를 받지 못했어요.');
   clip.savedUri=uri;clip.savedAt=DateTime.now().toIso8601String();await widget.onSave();
  }finally{rendering=false;}
 }
 Future<Map<dynamic,dynamic>> scanVisible(Clip clip,double start,double end)async{
  update('사용 구간 ${start.toStringAsFixed(1)}~${end.toStringAsFixed(1)}초 · 중앙 크롭 글자 검사');
  Map<dynamic,dynamic> scan;
  try{scan=await Native.call<Map<dynamic,dynamic>>('scanOriginalText',{'path':clip.path,'startMs':(start*1000).round(),'endMs':(end*1000).round(),'crop':clip.crop})??{};}catch(_){check();throw const AiFailure('크롭 글자 검사를 완료하지 못했어요. [SOURCE_TEXT_SCAN]',retryable:true);}
  check();
  if(scan['complete']!=true||scan['cropped']!=clip.crop||scan['scanStart'] is! num||scan['scanEnd'] is! num||((scan['scanStart'] as num)-start).abs()>.05||((scan['scanEnd'] as num)-end).abs()>.05)throw const AiFailure('사용 구간·크롭 글자 검사 범위를 확인하지 못했어요. [SOURCE_TEXT_SCOPE]',retryable:true);
  clip.videoWidth=(scan['videoWidth'] as num).toDouble();clip.videoHeight=(scan['videoHeight'] as num).toDouble();return scan;
 }
 Future<void> start({bool resume=false,bool previewOnly=false})async{
  final key=keyInput.text.trim();if(running||loading||starting)return;
  if((!previewOnly&&key.isEmpty)||searchKey.isEmpty){update('AI 설정에서 Gemini 키와 Tavily 검색 키를 입력해 주세요.');await settings();return;}
  FocusScope.of(context).unfocus();
  setState(()=>starting=true);
  try{notifications=await Native.call<bool>('batchNotifications')??false;}catch(e){update('알림 준비에 실패했어요: $e');if(mounted)setState(()=>starting=false);return;}
  if(!mounted)return;
  setState(()=>starting=false);
  setState((){running=true;stopping=false;previewing=previewOnly;previewCount=0;savedCount=resume?reports.where((r)=>r['state']=='저장 완료').length.clamp(0,5).toInt():0;searchRound=0;resultFilter='전체';if(!resume)reports.clear();searchLog.clear();status=resume?'남은 영상 제작 재개':'혼합 주제 탐색 시작';});
  var saved=savedCount;var fatal=false;
  store.seen.addAll(widget.clips.where((c)=>c.savedUri.isNotEmpty).map((c)=>MixedDiscovery.videoId(c.url)).whereType<String>());
  store.queue.removeWhere((c)=>store.seen.contains(MixedDiscovery.videoId(c.url)));
  final usedQueries=<String>{};final tried=<String>{};var cursor=0;var processed=0;
  final exhausted=<String>{};final topicSearches=<int,int>{};
  final activeTopics=MixedDiscovery.indicesFor(searchCategory);
  try{
   await Native.call('batchStart');await saveReport();
   stopPoll=Timer.periodic(const Duration(seconds:2),(_)async{
    if(pollBusy||!running||stopping)return;pollBusy=true;
    try{if(await Native.call<bool>('batchShouldStop')==true&&mounted&&running)await stop();}catch(_){}finally{pollBusy=false;}
   });
   while(saved<5&&(!previewOnly||previewCount<5)&&!stopping&&!fatal&&processed<60){
    check();
    VideoCandidate? selected;
    // Reuse every topic's pending candidates before spending a search request.
    for(var offset=0;offset<activeTopics.length;offset++){
     final index=activeTopics[(cursor+offset)%activeTopics.length];
     selected=store.next(MixedDiscovery.topics[index],skip:tried);
     if(selected!=null){cursor=(cursor+offset+1)%activeTopics.length;break;}
    }
    if(selected==null)for(var offset=0;offset<activeTopics.length;offset++){
     final index=activeTopics[(cursor+offset)%activeTopics.length];final topic=MixedDiscovery.topics[index];
     selected=store.next(topic,skip:tried);
     if(selected==null&&!exhausted.contains(topic)&&searchRound<9){
      final available=MixedDiscovery.queries[index].where((q)=>!usedQueries.contains(q));
      final targeted=(topicSearches[index]??0)%3<2?store.targetedQuery(index,usedQueries):null;
      if(available.isEmpty&&targeted==null){exhausted.add(topic);continue;}
      final query=targeted??store.queryFor(index,usedQueries);topicSearches[index]=(topicSearches[index]??0)+1;usedQueries.add(query);searchRound++;
      store.count(query,'searches');await saveReport();
      finder=MixedDiscovery();
      List<VideoCandidate> found;
      try{found=await finder!.discover(key:searchKey,excluded:store.excluded,query:query,topic:topic,onStatus:(s)=>update('$saved/5 저장 완료 · 검색 $searchRound/9 · $s'));searchLog.add({'query':query,'topic':topic,'http':200,...finder!.diagnostics});}
      catch(e){searchLog.add({'query':query,'topic':topic,'error':e.toString()});await saveReport();rethrow;}
      finder=null;check();
      if(found.isEmpty)store.count(query,'emptySearches');
      store.add(found);await saveReport();selected=store.next(topic,skip:tried);
     }
     if(selected!=null){cursor=(cursor+offset+1)%activeTopics.length;break;}
    }
    if(selected==null){
     if(searchRound>=9||exhausted.length==activeTopics.length)break;
     continue;
    }
    final candidate=selected;processed++;tried.add(MixedDiscovery.videoId(candidate.url)!);var retain=false;
    final candidateId=MixedDiscovery.videoId(candidate.url)!;
    if(resume)reports.removeWhere((r)=>MixedDiscovery.videoId(r['url'] as String? ?? '')==candidateId&&['실패','중단'].contains(r['state']));
    store.count(candidate.query,'attempted');store.accountCount(candidate.url,'attempted');
    final item=<String,dynamic>{'url':candidate.url,'topic':candidate.topic,'title':candidate.title,'state':'다운로드','error':'','query':candidate.query};
    setState(()=>reports.add(item));await saveReport();
    try{
     check();update('${saved}/5 저장 완료 · ${candidate.topic} 원본 다운로드');
     Clip? clip=widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(candidate.url)).firstOrNull;
     if(clip==null||!clip.ready||!await File(clip.path).exists()){
      downloader=TikTokDownloader();
      final raw=await downloader!.download(candidate.url,(progress,stage)=>update('${saved}/5 완료 · $stage'),minDuration:5,maxDuration:60);downloader=null;check();
      final downloaded=Clip.fromJson(raw);
      if(clip==null){clip=downloaded;clip.url=candidate.url;widget.clips.insert(0,clip);}
      else{clip.path=downloaded.path;clip.thumbnail=downloaded.thumbnail;clip.duration=downloaded.duration;clip.videoWidth=downloaded.videoWidth;clip.videoHeight=downloaded.videoHeight;clip.name=downloaded.name;clip.creator=downloaded.creator;clip.downloadError='';}
      await widget.onSave();
     }
     item['downloaded']=true;store.count(candidate.query,'downloaded');
     final current=clip;current.category=candidate.topic;
     if(current.duration<5||current.duration>60){item['state']='제외';item['error']='길이 ${current.duration.toStringAsFixed(1)}초 · 원본 허용 범위 5~60초';await saveReport();continue;}
     item['lengthPassed']=true;
     current.start=0;current.end=current.duration;current.crop=true;current.style=0;current.mute=false;
     final sourceStat=await File(current.path).stat();
     final signature='${current.id}|${current.path}|${sourceStat.size}|${sourceStat.modified.millisecondsSinceEpoch}|${current.duration}|$model|crop-v6-categories|${candidate.topic}';
     final checkpoint=checkpoints[candidateId];
     final cached=checkpoint?['signature']==signature?checkpoint:null;
     if(!previewOnly&&cached?['cropTextClear']==true&&cached?['aiReady']==true&&cached?['selection'] is Map&&activeTopics.map((i)=>MixedDiscovery.kinds[i]).contains((cached!['selection'] as Map)['kind'])&&validHeadline(current.headline)&&current.timedCaptions.isNotEmpty){
      final selection=SceneSelection.fromJson(cached!['selection'] as Map,sourceStart:0,sourceEnd:current.duration);
      if(!selection.usable)throw const AiFailure('저장된 장면 근거가 유효하지 않아요. [AI_SELECTION]',retryable:true);
      current.start=selection.start;current.end=selection.end;item['selection']=selection.toJson();
      item['textClear']=true;item['aiPassed']=true;item['score']=cached['score'];item['quality']=cached['quality'];
      item['state']='MP4 저장';item['title']=current.headline;await saveReport();
      update('$saved/5 완료 · 생성 결과 재사용, 저장 재개');
      await render(current);store.count(candidate.query,'saved');store.accountCount(candidate.url,'saved');saved++;savedCount=saved;item['state']='저장 완료';item['savedUri']=current.savedUri;checkpoints.remove(candidateId);update('$saved/5개 저장 완료');await saveReport();continue;
     }
     if(previewOnly){
      if(cached?['previewScanned']!=true){
       item['state']='크롭 글자 검사';await saveReport();
       final scan=await scanVisible(current,0,current.duration);
       final overlay=OriginalTextPolicy.hasOverlay(scan,start:0,end:current.duration);item['previewOverlay']=overlay;
       checkpoints[candidateId]={'signature':signature,'previewScanned':true,'previewOverlay':overlay};await widget.onSave();
      }
      final overlay=item['previewOverlay']==true||cached?['previewOverlay']==true;
      item['textClear']=!overlay;if(overlay)item['error']='크롭 영역에 글자 의심 · 사용할 구간은 제작 때 다시 검사해요.';
      item['state']='후보 확인';retain=true;previewCount++;update('후보 $previewCount/5개 준비 · 원본을 재생하고 평가해 주세요.');await saveReport();continue;
     }
     item['state']='AI 생성';item['title']=current.name;await saveReport();
     analyzer=GeminiCaptions();
     final draft=await analyzer!.generate(clip:current,onContext:widget.onSave,key:key,model:model,assessEntertainment:true,selectHighlight:true,preferenceBrief:store.contentPreferences(),contentCategory:candidate.topic,onStatus:(s)=>update('${saved}/5 완료 · $s'));analyzer=null;check();
     item['score']=draft.entertainmentScore;item['quality']=draft.quality.toJson();
     if(!draft.quality.acceptable){item['state']='제외';item['error']='${draft.quality.sourceText=='present'?'기존 자막 포함':draft.quality.sourceText=='uncertain'?'기존 자막 판단 불확실':draft.quality.edited?'편집본':draft.quality.aiSuspected?'AI 영상 의심':'원본 판단 불확실'} · ${draft.quality.reason}';await saveReport();continue;}
     item['selection']=draft.selection?.toJson();
     if(draft.selection?.usable!=true){item['state']='제외';item['error']='핵심 장면 부족 · ${draft.selection?.reason??"구체적 도입·결과 없음"}';await saveReport();continue;}
     if(!activeTopics.map((i)=>MixedDiscovery.kinds[i]).contains(draft.selection!.kind)){item['state']='제외';item['error']='선택한 카테고리와 다른 소재';await saveReport();continue;}
     if(draft.entertainmentScore<55){item['state']='제외';item['error']='AI 혼합 주제 적합도 부족 (인기도 측정값이 아니에요)';await saveReport();continue;}
     item['state']='크롭 글자 검사';await saveReport();
     final scan=await scanVisible(current,draft.selection!.start,draft.selection!.end);
     item['textScanFrames']=scan['frames'];
     if(OriginalTextPolicy.hasOverlay(scan,start:draft.selection!.start,end:draft.selection!.end)){item['state']='제외';item['error']='사용 구간의 크롭 영역에 원본 자막·제목 의심';await saveReport();continue;}
     item['textClear']=true;item['aiPassed']=true;store.count(candidate.query,'passed');
     current.start=draft.selection!.start;current.end=draft.selection!.end;
     current.titleCandidates=draft.titles;current.headline=draft.headline;current.caption='';current.timedCaptions=draft.captions;await widget.onSave();
     checkpoints[candidateId]={'signature':signature,'cropTextClear':true,'aiReady':true,'selection':draft.selection!.toJson(),'score':draft.entertainmentScore,'quality':draft.quality.toJson()};await saveReport();
     item['state']='MP4 저장';await saveReport();update('${saved}/5 완료 · MP4 저장 중');
     await render(current);store.count(candidate.query,'saved');store.accountCount(candidate.url,'saved');saved++;savedCount=saved;item['state']='저장 완료';item['title']=current.headline;item['savedUri']=current.savedUri;checkpoints.remove(candidateId);update('$saved/5개 저장 완료');await saveReport();
    }catch(e){
     retain=stopping||item['state']=='MP4 저장'||(e is AiFailure&&e.retryable)||(item['state']=='다운로드'&&e is! DownloadLengthFailure&&!(e is DownloadFailure&&['PAGE_UNAVAILABLE','PAGE_METADATA','PAGE_HTTP_400','PAGE_PRIVATE','PAGE_DOWNLOAD_DISABLED','PAGE_DOWNLOAD_URL','PAGE_VERIFICATION','PAGE_HTTP_403','PAGE_HTTP_429'].contains(e.code)));
     item['failedStage']=item['state'];
     item['state']=stopping?'중단':e is DownloadLengthFailure||(e is DownloadFailure&&e.code=='PAGE_UNAVAILABLE')?'제외':'실패';
     item['error']=e is DownloadLengthFailure?'다운로드 전 확인 · 길이 ${e.duration.toStringAsFixed(1)}초 · 원본 허용 범위 5~60초':e.toString();await saveReport();
     // Quota and credential errors would affect every remaining candidate.
     if(stopping||(e is AiFailure&&(e.message.contains('한도')||e.message.contains('권한')||e.message.contains('모델')||e.message.contains('/CLIENT]')))){fatal=true;break;}
    }finally{downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;if(!stopping&&!fatal&&!retain){store.finish(candidate);checkpoints.remove(candidateId);}await saveReport();}
   }
   update(stopping?'작업 중단 · $saved개 저장 완료':previewOnly?'후보 $previewCount개 준비 · 원본 재생·평가 후 남은 제작을 재개할 수 있어요.':saved==5?'혼합 영상 5개 저장 완료':'$saved/5개 저장 완료 · ${fatal?'API 오류로 중단했어요':processed>=60?'후보 처리 60개 제한에 도달했어요':searchRound>=9?'검색 9회 완료 · 새 후보가 부족해요':'사용 가능한 검색어에서 새 후보를 얻지 못했어요'}. 아래 결과를 확인하세요.');
  }catch(e){update(stopping?'작업 중단 · $saved개 저장 완료':'$saved/5개 저장 완료 · $e');}
  finally{
   stopPoll?.cancel();stopPoll=null;
   finder?.cancel();finder=null;downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;
   if(mounted)setState(()=>running=false);else running=false;
   try{await saveReport();}catch(_){}
   try{await Native.call('batchFinish',{'status':status,'saved':savedCount});}catch(_){}
   if(exitRequested&&mounted)Navigator.pop(context);
  }
 }
 Future<void> recordFeedback(Map<String,dynamic> item,String label)async{
  final id=MixedDiscovery.videoId(item['url'] as String);if(id==null)return;
  setState(()=>store.feedback[id]={'label':label,'url':item['url'],'query':item['query'],'topic':item['topic'],'score':item['score'],'quality':item['quality'],'kind':(item['selection'] as Map?)?['kind']??({'사람·관계 반전':'people','놀라운 실력':'skill','기발한 상황':'curiosity'}[item['topic']]),'headline':item['title'],'updatedAt':DateTime.now().toIso8601String()});
  await saveReport();
 }

 Future<void> reviewCandidates()async{
  final items=reports.where((r)=>r['state']=='후보 확인'&&clipFor(r)?.ready==true).toList();
  if(items.isEmpty)return;
  await showReviewPlayback(context,entries:[for(final r in items)PlaybackEntry(uri:clipFor(r)!.path,title:r['title'] as String? ?? '원본 후보',id:MixedDiscovery.videoId(r['url'] as String)!)],ratings:{for(final r in items)MixedDiscovery.videoId(r['url'] as String)!:store.feedback[MixedDiscovery.videoId(r['url'] as String)]?['label'] as String? ?? ''},onRate:(id,label)async{await recordFeedback(items.firstWhere((r)=>MixedDiscovery.videoId(r['url'] as String)==id),label);});
  if(mounted)setState((){});
 }
 Future<void> reviewAll()async{
  final items=reports.where((r)=>r['state']=='저장 완료'&&(r['savedUri'] as String? ?? '').isNotEmpty).toList();
  if(items.isEmpty)return;
  await showReviewPlayback(context,entries:[for(final r in items)PlaybackEntry(uri:r['savedUri'] as String,title:r['title'] as String? ?? '완성 영상',id:MixedDiscovery.videoId(r['url'] as String)!)],ratings:{for(final r in items)MixedDiscovery.videoId(r['url'] as String)!:store.feedback[MixedDiscovery.videoId(r['url'] as String)]?['label'] as String? ?? ''},onRate:(id,label)async{final item=items.firstWhere((r)=>MixedDiscovery.videoId(r['url'] as String)==id);await recordFeedback(item,label);},onDelete:(id)async{final item=items.firstWhere((r)=>MixedDiscovery.videoId(r['url'] as String)==id);final clip=clipFor(item);if(clip!=null){await deleteSavedClip(clip);}else{await Native.call('deleteSavedVideo',{'uri':item['savedUri']});}item['savedUri']='';item['state']='삭제';savedCount=reports.where((r)=>r['state']=='저장 완료').length;await widget.onSave();await saveReport();});
  if(mounted)setState((){});
 }
 Future<void> replaceRejected()async{
  if(running)return;
  final rejected=reports.where((r)=>r['state']=='저장 완료'&&store.rejected(r['url'] as String)).toList();
  if(rejected.isEmpty)return;
  setState((){for(final item in rejected){item['state']='교체 대상';item['error']='평가에 따라 새 영상으로 교체 · 기존 저장 파일은 유지';}savedCount=reports.where((r)=>r['state']=='저장 완료').length;});
  await saveReport();await start(resume:true);
 }
 Clip? clipFor(Map<String,dynamic> item)=>widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(item['url'] as String? ?? '')).firstOrNull;
 Future<void> playItem(Map<String,dynamic> item,{bool saved=false})async{
  final clip=clipFor(item);final uri=item['savedUri'] as String? ?? clip?.savedUri??'';
  if(saved&&uri.isNotEmpty){await showPlayback(context,uri:uri,title:item['title'] as String? ?? '저장한 영상');}
  else if(clip!=null&&clip.ready){await showPlayback(context,path:clip.path,title:clip.name);}
 }
 Future<void> editItem(Clip clip)async{
  if(running)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>EditorScreen(clip:clip,onSave:widget.onSave)));
  if(mounted)setState((){});
 }
 Widget conversionPanel(){
  final funnel=ConversionFunnel.fromResults(reports,store.queue.map((c)=>c.url));
  return ExpansionTile(tilePadding:EdgeInsets.zero,initiallyExpanded:true,title:Text('영상 전환율 ${funnel.overall} · 단계별 현황',style:const TextStyle(fontSize:14,fontWeight:FontWeight.w600)),children:[
   const Text('현재 후보·결과 기준 · 중복 영상은 1건. 괄호는 직전 단계 대비 통과율이며 대기 중인 후보도 포함합니다.',style:TextStyle(fontSize:12,color:muted)),const SizedBox(height:12),
   for(var i=0;i<funnel.counts.length;i++)Padding(padding:const EdgeInsets.only(bottom:10),child:Column(children:[
    Row(children:[Expanded(child:Text(ConversionFunnel.labels[i],style:const TextStyle(fontSize:13))),Text('${funnel.counts[i]}개${i==0?'':' · ${funnel.stepRate(i)}'}',style:const TextStyle(fontSize:12,color:blue))]),const SizedBox(height:4),
    LinearProgressIndicator(value:funnel.counts.first==0?0:funnel.counts[i]/funnel.counts.first,minHeight:4,borderRadius:BorderRadius.circular(4)),
   ])),
   const Text('이전 버전에서 검사 기록이 없는 결과는 해당 단계 수치에서 빠질 수 있어요. 콘텐츠 제외와 기술 실패는 결과 카드에서 구분해요.',style:TextStyle(fontSize:11,color:muted)),const SizedBox(height:12),
  ]);
 }
 Widget countTile(String label,int value,Color color)=>Expanded(child:Column(children:[Text('$value',style:TextStyle(fontSize:24,fontWeight:FontWeight.w600,color:color)),const SizedBox(height:4),Text(label,style:const TextStyle(fontSize:12,color:muted))]));
 Widget resultCard(Map<String,dynamic> item){
  final state=item['state'] as String? ?? '';final clip=clipFor(item);final ready=clip?.ready==true;
  final saved=(item['savedUri'] as String? ?? clip?.savedUri??'').isNotEmpty;
  final message=item['error'] as String? ?? '';
  final complete=state=='저장 완료';final active=!['저장 완료','실패','제외','중단','후보 확인'].contains(state);
  final color=complete?blue:state=='실패'?const Color(0xffb44734):muted;
  return Card(margin:const EdgeInsets.only(bottom:12),color:Colors.white,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[Icon(complete?Icons.check_circle_outline:active?Icons.hourglass_top_rounded:state=='제외'?Icons.skip_next_rounded:Icons.info_outline,size:18,color:color),const SizedBox(width:6),Text(state,style:TextStyle(color:color,fontSize:12,fontWeight:FontWeight.w600)),const Spacer(),Text(item['topic'] as String? ?? '',style:const TextStyle(color:muted,fontSize:11))]),
   const SizedBox(height:12),Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
    if(ready)Padding(padding:const EdgeInsets.only(right:12),child:InkWell(onTap:()=>playItem(item,saved:complete),borderRadius:BorderRadius.circular(12),child:ClipRRect(borderRadius:BorderRadius.circular(12),child:SizedBox(width:72,height:96,child:Stack(fit:StackFit.expand,children:[Container(color:ink,child:clip!.thumbnail.isNotEmpty?Image.file(File(clip.thumbnail),fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.movie,color:Colors.white54)):const Icon(Icons.movie,color:Colors.white54)),const Center(child:Icon(Icons.play_circle_fill,color:Colors.white,size:32))]))))),
    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(item['title'] as String? ?? '',maxLines:3,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w500)),if(ready)Padding(padding:const EdgeInsets.only(top:6),child:Text('${clip!.duration.toStringAsFixed(1)}초',style:const TextStyle(fontSize:12,color:muted))),if(message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text(message.split('\n').first.split(' · 단계').first,style:TextStyle(fontSize:12,color:color)))])),
   ]),
   if(ready||saved)Padding(padding:const EdgeInsets.only(top:12),child:Wrap(spacing:8,runSpacing:4,children:[if(saved)FilledButton.tonalIcon(onPressed:()=>playItem(item,saved:true),icon:const Icon(Icons.play_arrow_rounded,size:18),label:const Text('저장본 재생')),if(ready)OutlinedButton.icon(onPressed:()=>playItem(item),icon:const Icon(Icons.play_arrow_rounded,size:18),label:const Text('원본 재생')),if(ready&&!running)TextButton.icon(onPressed:()=>editItem(clip!),icon:const Icon(Icons.edit_outlined,size:16),label:const Text('편집'))])),
   if(complete||state=='제외'||state=='후보 확인')ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('영상 평가',style:TextStyle(fontSize:12,color:muted)),children:[Wrap(spacing:6,runSpacing:4,children:[for(final label in ['괜찮음','재미없음','편집본','AI 의심'])ChoiceChip(label:Text(label,style:const TextStyle(fontSize:11)),selected:store.feedback[MixedDiscovery.videoId(item['url'] as String)]?['label']==label,onSelected:running?null:(_)async{try{await recordFeedback(item,label);}catch(_){update('평가 저장에 실패했어요. 다시 눌러 주세요.');}})])]),
   if(item['selection'] is Map)ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('선택한 장면',style:TextStyle(fontSize:12,color:muted)),children:[Text('도입: ${(item['selection'] as Map)['hook']}\n핵심: ${(item['selection'] as Map)['payoff']}\n구간 ${(item['selection'] as Map)['start']}~${(item['selection'] as Map)['end']}초 · 핵심 ${(item['selection'] as Map)['peak']}초',style:const TextStyle(fontSize:12,color:muted))]),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:Text(message.isEmpty?'원본 링크':'상세 정보',style:const TextStyle(fontSize:12,color:muted)),children:[if(message.isNotEmpty)SelectableText(message,style:const TextStyle(fontSize:12,color:muted)),const SizedBox(height:8),SelectableText(item['url'] as String? ?? '',style:const TextStyle(fontSize:11,color:muted)),if(message.isNotEmpty)TextButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:message));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('오류 정보를 복사했어요.')));},icon:const Icon(Icons.copy,size:14),label:const Text('오류 복사'))]),
  ])));
 }
 @override Widget build(BuildContext context){
  final excluded=reports.where((r)=>r['state']=='제외').length;
  final failed=reports.where((r)=>r['state']=='실패').length;
  final shown=reports.reversed.where((r)=>resultFilter=='전체'||(resultFilter=='완료'?r['state']=='저장 완료':['실패','제외','중단'].contains(r['state']))).toList();
  final configured=keyInput.text.isNotEmpty&&searchKey.isNotEmpty;
  return PopScope(canPop:!running&&!starting,onPopInvokedWithResult:(didPop,result){if(!didPop)unawaited(requestExit());},child:Scaffold(appBar:AppBar(leading:IconButton(tooltip:'뒤로',onPressed:starting?null:requestExit,icon:const Icon(Icons.arrow_back)),title:const Text('혼합 영상 제작',style:TextStyle(fontSize:18)),actions:[IconButton(tooltip:'앱 설정',onPressed:running||loading?null:settings,icon:const Icon(Icons.settings_outlined))]),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,12,20,24),children:[
   const Text('웃긴 순간, 한 번에 5개',style:TextStyle(fontSize:26,fontWeight:FontWeight.w600)),const SizedBox(height:8),
   const Text('원하는 소재를 선택해서 검색하고 제작해요.',style:TextStyle(fontSize:13,color:muted)),const SizedBox(height:12),const Text('검색 카테고리',style:TextStyle(fontSize:13,fontWeight:FontWeight.w600)),const SizedBox(height:6),
   Wrap(spacing:6,runSpacing:6,children:[for(final category in ['혼합 추천',...MixedDiscovery.topics])ChoiceChip(label:Text(category,style:const TextStyle(fontSize:12)),selected:searchCategory==category,onSelected:loading||running||starting?null:(_)async{setState(()=>searchCategory=category);await saveReport();})]),const SizedBox(height:20),
   Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xfff2f9ff),borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Text(previewing?'후보 확인':running?'자동 제작 중':savedCount==5?'제작 완료':'제작 현황',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600)),const Spacer(),Text('${previewing?previewCount:savedCount} / 5개',style:const TextStyle(fontSize:18,color:blue,fontWeight:FontWeight.w600))]),const SizedBox(height:14),
    if(loading)const LinearProgressIndicator()else LinearProgressIndicator(value:(previewing?previewCount:savedCount)/5,minHeight:6,borderRadius:BorderRadius.circular(6)),const SizedBox(height:12),Text(status,style:const TextStyle(fontSize:13)),const SizedBox(height:18),
    Row(children:[countTile('저장',savedCount,blue),countTile('제외',excluded,muted),countTile('실패',failed,const Color(0xffb44734))]),
    if(running)Padding(padding:const EdgeInsets.only(top:14),child:Text(notifications?'홈으로 나가거나 화면을 꺼도 계속해요. 알림에서 중단할 수 있어요.':'알림이 꺼져 있어요. 홈·화면 잠금 중에도 작업을 계속해요.',style:const TextStyle(fontSize:12,color:muted))),
   ])),
   if(!configured&&!loading)Padding(padding:const EdgeInsets.only(top:12),child:ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.settings_outlined,color:blue),title:const Text('제작 전에 앱 설정을 완료하세요',style:TextStyle(fontSize:14)),subtitle:const Text('Gemini · Tavily API 키',style:TextStyle(fontSize:12)),trailing:const Icon(Icons.chevron_right),onTap:settings)),
   const SizedBox(height:16),
   ExpansionTile(tilePadding:EdgeInsets.zero,initiallyExpanded:reports.isEmpty&&searchLog.isNotEmpty,title:Text('검색 $searchRound/9회 · 응답·제외 이유',style:const TextStyle(fontSize:14,fontWeight:FontWeight.w600)),children:[for(final row in searchLog)Padding(padding:const EdgeInsets.only(bottom:12),child:Text('${row['topic']} · ${row['query']}\n${row['error']??"Tavily HTTP 200 · 응답 ${row['received']??0}개 → 새 후보 ${row['accepted']??0}개\n중복 ${row['duplicate']??0} · 개별 영상 아님 ${row['nonVideo']??0} · 모음집 ${row['compilation']??0} · 잘못된 항목 ${row['invalid']??0}"}',style:const TextStyle(fontSize:12,color:muted)))]),
   conversionPanel(),
   if(!loading&&!running&&!starting)Wrap(spacing:8,runSpacing:8,children:[
    if(reports.any((r)=>r['state']=='후보 확인'))FilledButton.tonalIcon(onPressed:reviewCandidates,icon:const Icon(Icons.playlist_play),label:const Text('후보 연속 재생·평가')),
    OutlinedButton.icon(onPressed:()=>start(previewOnly:true),icon:const Icon(Icons.video_library_outlined),label:const Text('후보 5개 먼저 보기')),
    if(reports.any((r)=>r['state']=='저장 완료'))FilledButton.tonalIcon(onPressed:reviewAll,icon:const Icon(Icons.playlist_play),label:const Text('완성본 연속 재생·평가')),
    if(reports.any((r)=>r['state']=='저장 완료'&&store.rejected(r['url'] as String)))OutlinedButton.icon(onPressed:replaceRejected,icon:const Icon(Icons.autorenew),label:const Text('평가한 영상 교체')),
    if(savedCount<5&&(store.queue.isNotEmpty||reports.any((r)=>['실패','중단','교체 대상'].contains(r['state']))))OutlinedButton.icon(onPressed:()=>start(resume:true),icon:const Icon(Icons.play_arrow_rounded),label:const Text('남은 제작 재개')),
   ]),
   const SizedBox(height:20),Row(children:[const Text('제작 결과',style:TextStyle(fontSize:18,fontWeight:FontWeight.w600)),const Spacer(),Text('${reports.length}개 확인',style:const TextStyle(fontSize:12,color:muted))]),const SizedBox(height:10),
   Wrap(spacing:8,children:[for(final label in ['전체','완료','제외·실패'])FilterChip(label:Text(label),selected:resultFilter==label,onSelected:(_)=>setState(()=>resultFilter=label))]),const SizedBox(height:14),
   if(shown.isEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:32),child:Column(children:[const Icon(Icons.video_library_outlined,size:36,color:muted),const SizedBox(height:12),Text(reports.isEmpty?(searchLog.isEmpty?'시작하면 영상 탐색부터 저장까지 진행해요.':'새 영상 후보가 없어요. 위 검색 기록에서 이유를 확인하세요.'):'해당하는 결과가 아직 없어요.',style:const TextStyle(fontSize:13,color:muted)),const SizedBox(height:6),const Text('완료된 영상은 여기에서 바로 재생할 수 있어요.',style:TextStyle(fontSize:12,color:muted))])),
   for(final item in shown)resultCard(item),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('제작 방식과 제한',style:TextStyle(fontSize:13,color:muted)),children:[const Text('페이지 길이를 먼저 확인해 5~60초 원본만 다운로드해요. AI가 도입과 핵심 결과가 이어지는 5~30초 구간을 골라요. 길이가 없으면 다운로드 후 확인해요. 편집본·AI 의심·판단 불확실 후보는 건너뛰고 다음 후보를 찾습니다. 선택 카테고리의 한국어·영어 검색어를 순환해요. 자막 검사는 실제 사용할 시간과 중앙 크롭 영역을 기준으로 해요. 검색 최대 9회·후보 처리 최대 60개. 5개보다 적게 저장될 수 있어요. AI 판정은 틀릴 수 있어요. 앱 강제 종료 시 작업은 중단되지만 다음 실행에서 남은 제작을 재개할 수 있어요. 저장 실패 시 생성 결과를 재사용합니다. 부정 평가 영상은 다시 선택하지 않으며 평가가 검색어·계정 우선순위에 반영됩니다.',style:TextStyle(fontSize:12,color:muted))]),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:Text('대기 ${store.queue.length}개 · 검색 효율',style:const TextStyle(fontSize:13,color:muted)),children:[for(final entry in store.metrics.entries)Padding(padding:const EdgeInsets.only(bottom:8),child:Text('${entry.key}\n검색 ${entry.value['searches']??0} · 후보 ${entry.value['found']??0} → 다운로드 ${entry.value['downloaded']??0} → 적합 ${entry.value['passed']??0} → 저장 ${entry.value['saved']??0}',style:const TextStyle(fontSize:12,color:muted)))]),
  ])),bottomNavigationBar:SafeArea(child:Container(padding:const EdgeInsets.fromLTRB(20,12,20,16),decoration:const BoxDecoration(color:Colors.white,border:Border(top:BorderSide(color:line))),child:FilledButton.icon(onPressed:loading||starting||stopping?null:running?stop:()=>start(),icon:Icon(running?Icons.stop_rounded:Icons.auto_awesome),label:Text(stopping?'중단하는 중…':running?'자동 제작 중단':'영상 5개 자동 제작'))))));
 }
}
