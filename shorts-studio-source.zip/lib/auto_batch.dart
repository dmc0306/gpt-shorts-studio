import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'ai.dart';
import 'bridge.dart';
import 'discovery.dart';
import 'editor.dart';
import 'model.dart';
import 'theme.dart';
import 'tiktok_download.dart';

class AutoBatchScreen extends StatefulWidget {
 const AutoBatchScreen({super.key,required this.clips,required this.onSave});
 final List<Clip> clips;
 final Future<void> Function() onSave;
 @override State<AutoBatchScreen> createState()=>_AutoBatchState();
}
class _AutoBatchState extends State<AutoBatchScreen> {
 final keyInput=TextEditingController();
 final renderKey=GlobalKey();
 final reports=<Map<String,dynamic>>[];
 final searches=<WebViewController>[];
 bool loading=true,running=false,stopping=false,rendering=false;
 String status='혼합 주제 영상 5개를 자동 제작해요.',model=GeminiCaptions.defaultModel;
 Clip? renderClip;String renderCaption='';
 MixedDiscovery? finder;TikTokDownloader? downloader;GeminiCaptions? analyzer;
 @override void initState(){super.initState();load();}
 Future<void> load()async{
  try{
   final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
   keyInput.text=settings['key'] as String? ?? '';model=settings['model'] as String? ?? model;
   final raw=await Native.call<String>('loadBatchReport')??'{}';
   final report=jsonDecode(raw) as Map;
   reports.addAll((report['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)));
   if(report['running']==true){status='이전 작업이 중단됐어요. 완료한 영상은 저장함에 남아 있어요.';for(final item in reports){if(!['저장 완료','실패','제외'].contains(item['state']))item['state']='중단';}}
  }catch(_){status='이전 작업 정보를 불러오지 못했어요. 새 작업을 시작할 수 있어요.';}
  if(mounted)setState(()=>loading=false);
 }
 @override void dispose(){finder?.cancel();downloader?.cancel();analyzer?.cancel();keyInput.dispose();super.dispose();}
 Future<void> saveReport()async{await Native.call('saveBatchReport',{'json':jsonEncode({'running':running,'status':status,'updatedAt':DateTime.now().toIso8601String(),'items':reports})});}
 void update(String value){if(mounted)setState(()=>status=value);}
 void check(){if(stopping||!mounted)throw const AiFailure('작업을 중단했어요.');}
 Future<void> stop()async{
  if(stopping)return;setState(()=>stopping=true);finder?.cancel();downloader?.cancel();analyzer?.cancel();
  if(rendering){try{await Native.call('cancelExport');}catch(_){/* Publishing finishes safely before the queue stops. */}}
  update('진행 중인 작업을 정리한 뒤 중단해요.');
 }
 Future<Uint8List> capture({bool subtitleOnly=false})async{
  await WidgetsBinding.instance.endOfFrame;check();
  final boundary=renderKey.currentContext?.findRenderObject();
  if(boundary is! RenderRepaintBoundary)throw StateError('자동 저장용 자막 레이어가 준비되지 않았어요.');
  final source=await boundary.toImage(pixelRatio:1080/boundary.size.width);
  ui.Image image=source;
  if(subtitleOnly){final recorder=ui.PictureRecorder();ui.Canvas(recorder).drawImage(source,const ui.Offset(0,-1200),ui.Paint());final picture=recorder.endRecording();image=await picture.toImage(1080,200);picture.dispose();source.dispose();}
  final bytes=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();
  if(bytes==null)throw StateError('자막 이미지 생성 실패');return bytes.buffer.asUint8List();
 }
 Future<void> render(Clip clip)async{
  setState((){renderClip=clip;renderCaption='';});
  final title=await capture();final overlays=<Map<String,dynamic>>[];
  for(final t in clip.timedCaptions){
   check();setState(()=>renderCaption=t.text);
   overlays.add({'startUs':((t.start-clip.start)*1000000).round(),'endUs':((t.end-clip.start)*1000000).round(),'png':await capture(subtitleOnly:true)});
  }
  check();rendering=true;
  try{
   final uri=await Native.call<String>('export',{'path':clip.path,'overlay':title,'timedOverlays':overlays,'startMs':(clip.start*1000).round(),'endMs':(clip.end*1000).round(),'mute':clip.mute,'crop':clip.crop});
   if(uri==null)throw StateError('저장 결과를 받지 못했어요.');
   clip.savedUri=uri;clip.savedAt=DateTime.now().toIso8601String();await widget.onSave();
  }finally{rendering=false;if(mounted)setState(()=>renderClip=null);}
 }
 Future<void> start()async{
  final key=keyInput.text.trim();if(running||loading)return;
  if(key.isEmpty){update('먼저 Gemini API 키를 입력해 주세요.');return;}
  FocusScope.of(context).unfocus();setState((){running=true;stopping=false;reports.clear();searches.clear();status='혼합 주제 탐색 시작';});
  var saved=0;
  try{
   await Native.call('saveAiSettings',{'key':key,'model':model});
   await Native.call('batchKeepAwake',{'enabled':true});await saveReport();
   finder=MixedDiscovery();
   final candidates=await finder!.discover(key:key,excluded:widget.clips.where((c)=>c.savedUri.isNotEmpty).map((c)=>c.url).toSet(),onStatus:update,onSearchHtml:(html){
    if(mounted)setState(()=>searches.add(WebViewController()..setJavaScriptMode(JavaScriptMode.disabled)..loadHtmlString('<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>$html</body></html>')));
   });finder=null;check();
   for(final candidate in candidates){
    if(saved==5||stopping)break;
    final item=<String,dynamic>{'url':candidate.url,'topic':candidate.topic,'title':candidate.title,'state':'다운로드','error':''};
    setState(()=>reports.add(item));await saveReport();
    try{
     check();update('${saved}/5 저장 완료 · ${candidate.topic} 원본 다운로드');
     Clip? clip=widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(candidate.url)).firstOrNull;
     if(clip==null||!clip.ready){
      downloader=TikTokDownloader();
      final raw=await downloader!.download(candidate.url,(progress,stage)=>update('${saved}/5 완료 · $stage'));downloader=null;check();
      final downloaded=Clip.fromJson(raw);
      if(clip==null){clip=downloaded;clip.url=candidate.url;widget.clips.insert(0,clip);}
      else{clip.path=downloaded.path;clip.thumbnail=downloaded.thumbnail;clip.duration=downloaded.duration;clip.name=downloaded.name;clip.creator=downloaded.creator;clip.downloadError='';}
      await widget.onSave();
     }
     final current=clip;
     if(current.duration<5||current.duration>30){item['state']='제외';item['error']='5~30초 범위 밖의 영상';await saveReport();continue;}
     current.start=0;current.end=current.duration;current.crop=true;current.style=0;current.mute=false;
     item['state']='AI 생성';item['title']=current.name;await saveReport();
     analyzer=GeminiCaptions();
     final draft=await analyzer!.generate(clip:current,key:key,model:model,assessEntertainment:true,onStatus:(s)=>update('${saved}/5 완료 · $s'));analyzer=null;check();
     item['score']=draft.entertainmentScore;
     if(draft.entertainmentScore<55){item['state']='제외';item['error']='AI 혼합 주제 적합도 부족 (인기도 측정값이 아니에요)';await saveReport();continue;}
     current.headline=draft.headline;current.caption='';current.timedCaptions=draft.captions;await widget.onSave();
     item['state']='MP4 저장';await saveReport();update('${saved}/5 완료 · MP4 저장 중');
     await render(current);saved++;item['state']='저장 완료';item['title']=current.headline;item['savedUri']=current.savedUri;await saveReport();
    }catch(e){
     item['state']=stopping?'중단':'실패';item['error']=e.toString();await saveReport();
     // Quota and credential errors would affect every remaining candidate.
     if(stopping||(e is AiFailure&&(e.message.contains('한도')||e.message.contains('권한')||e.message.contains('모델'))))break;
    }finally{downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;}
   }
   update(stopping?'작업 중단 · $saved개 저장 완료':saved==5?'혼합 영상 5개 저장 완료':'$saved/5개 저장 완료 · 후보 부족 또는 오류. 아래 결과를 확인하세요.');
  }catch(e){update(stopping?'작업 중단 · $saved개 저장 완료':'$saved/5개 저장 완료 · $e');}
  finally{
   finder?.cancel();finder=null;downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;
   if(mounted)setState(()=>running=false);else running=false;
   try{await saveReport();}catch(_){}
   try{await Native.call('batchKeepAwake',{'enabled':false});}catch(_){}
  }
 }
 @override Widget build(BuildContext context)=>Stack(children:[
  if(renderClip!=null)Positioned(top:0,left:0,width:270,height:480,child:IgnorePointer(child:RepaintBoundary(key:renderKey,child:Material(type:MaterialType.transparency,child:ClipOverlay(headline:renderClip!.headline,caption:renderCaption,style:renderClip!.style))))),
  PopScope(canPop:!running,child:Scaffold(appBar:AppBar(title:const Text('혼합 영상 자동 제작',style:TextStyle(fontSize:18))),body:SafeArea(child:ListView(padding:const EdgeInsets.all(24),children:[
   const Text('한 번에 5개',style:TextStyle(fontSize:30)),const SizedBox(height:12),
   const Text('웃긴 상황·반전 / 귀여운 동물 / 아기·가족\n주제별 공개 링크 탐색 → 다운로드 → AI 제목·자막 → MP4 저장',style:TextStyle(fontSize:14)),
   const SizedBox(height:16),TextField(controller:keyInput,enabled:!running&&!loading,obscureText:true,autocorrect:false,enableSuggestions:false,decoration:const InputDecoration(labelText:'Gemini API 키',helperText:'기존 AI 설정의 키를 함께 사용해요.')),
   const SizedBox(height:12),const Text('원본 영상·소리를 Google로 전송해요. 무료 티어 데이터는 제품 개선에 사용될 수 있어요. 결제를 연결하지 않은 키를 사용하세요. 검색·생성 무료 한도가 적용돼요.',style:TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:16),const Text('한 편당 5~30초 · 실패/부적합 영상은 다음 후보로 넘어가요. 최대 12개 후보에서 5개 저장을 시도해요. 검색 색인·접근 제한으로 5개보다 적게 저장될 수 있어요. AI 적합도는 실제 인기도를 보장하지 않아요.',style:TextStyle(fontSize:12,color:muted)),
   const SizedBox(height:20),if(running||loading)const LinearProgressIndicator(),const SizedBox(height:12),Text(status,style:const TextStyle(fontSize:14,color:blue)),
   if(running)const Padding(padding:EdgeInsets.only(top:8),child:Text('완료할 때까지 앱을 켜두세요. 완료된 파일은 Movies/ShortsStudio에 저장돼요.',style:TextStyle(fontSize:12,color:muted))),
   const SizedBox(height:20),for(final item in reports)Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${item['state']} · ${item['topic']}',style:TextStyle(color:item['state']=='저장 완료'?blue:muted,fontSize:12)),const SizedBox(height:6),Text(item['title'] as String? ?? '',style:const TextStyle(fontSize:14)),if((item['error'] as String? ?? '').isNotEmpty)Text(item['error'] as String,style:const TextStyle(fontSize:12,color:muted)),const SizedBox(height:6),SelectableText(item['url'] as String? ?? '',style:const TextStyle(fontSize:10,color:muted))]))),
   if(searches.isNotEmpty)...[const SizedBox(height:16),const Text('Google 검색 출처·추천 검색',style:TextStyle(fontSize:13)),for(final controller in searches)SizedBox(height:180,child:WebViewWidget(controller:controller))]
  ])),bottomNavigationBar:SafeArea(child:Padding(padding:const EdgeInsets.all(20),child:FilledButton.icon(onPressed:loading||stopping?null:running?stop:start,icon:Icon(running?Icons.stop_rounded:Icons.auto_awesome),label:Text(running?'중단':'혼합 영상 5개 자동 제작'))))))
 ]);
}
