import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'editor.dart';
import 'playback.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'ai.dart';
import 'ai_settings.dart';
import 'bridge.dart';
import 'discovery.dart';
import 'discovery_store.dart';
import 'overlay_renderer.dart';
import 'caption_layout.dart';
import 'original_text.dart';
import 'model.dart';
import 'theme.dart';
import 'tiktok_download.dart';

class AutoBatchScreen extends StatefulWidget {
 const AutoBatchScreen({super.key,required this.clips,required this.onSave});
 final List<Clip> clips;
 final Future<void> Function() onSave;
 @override State<AutoBatchScreen> createState()=>_AutoBatchState();
}
class _AutoBatchState extends State<AutoBatchScreen> {
 final keyInput=TextEditingController();
 static const batchChannel=MethodChannel('studio.local/batch');
 Timer? stopPoll;
 int savedCount=0,searchRound=0;
 bool pollBusy=false;
 final reports=<Map<String,dynamic>>[];
 DiscoveryStore store=DiscoveryStore();
 String searchKey='',resultFilter='전체';
 bool starting=false,notifications=true,loading=true,running=false,stopping=false,rendering=false;
 String status='혼합 주제 영상 5개를 자동 제작해요.',model=GeminiCaptions.defaultModel;
 MixedDiscovery? finder;TikTokDownloader? downloader;GeminiCaptions? analyzer;
 @override void initState(){super.initState();batchChannel.setMethodCallHandler((call)async{if(call.method=='stop'&&running)await stop();});load();}
 Future<void> load()async{
  try{
   final settings=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
   keyInput.text=settings['key'] as String? ?? '';searchKey=settings['searchKey'] as String? ?? '';model=settings['model'] as String? ?? model;
   final raw=await Native.call<String>('loadBatchReport')??'{}';
   final report=jsonDecode(raw) as Map;
   store=DiscoveryStore.fromJson(report['discovery'] as Map? ?? {});
   savedCount=(report['saved'] as num?)?.toInt()??0;status=report['status'] as String? ?? status;
   reports.addAll((report['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)));
   if(report['running']==true){status='이전 작업이 중단됐어요. 완료한 영상은 저장함에 남아 있어요.';for(final item in reports){if(!['저장 완료','실패','제외'].contains(item['state']))item['state']='중단';}}
  }catch(_){status='이전 작업 정보를 불러오지 못했어요. 새 작업을 시작할 수 있어요.';}
  if(mounted)setState(()=>loading=false);
 }
 Future<void> settings()async{
  if(running||loading)return;
  if(!await showAiSettings(context)||!mounted)return;
  final values=await Native.call<Map<dynamic,dynamic>>('loadAiSettings')??{};
  if(!mounted)return;
  setState((){keyInput.text=values['key'] as String? ?? '';searchKey=values['searchKey'] as String? ?? '';model=values['model'] as String? ?? GeminiCaptions.defaultModel;status='앱 설정을 저장했어요.';});
 }
 @override void dispose(){stopPoll?.cancel();batchChannel.setMethodCallHandler(null);finder?.cancel();downloader?.cancel();analyzer?.cancel();keyInput.dispose();super.dispose();}
 Future<void> saveReport()async{await Native.call('saveBatchReport',{'json':jsonEncode({'running':running,'status':status,'saved':savedCount,'searchRound':searchRound,'updatedAt':DateTime.now().toIso8601String(),'items':reports,'discovery':store.toJson()})});}
 void update(String value){if(mounted)setState(()=>status=value);if(running)unawaited(Native.call('batchStatus',{'status':value,'saved':savedCount}).catchError((_)=>null));}
 void check(){if(stopping||!mounted)throw const AiFailure('작업을 중단했어요.');}
 Future<void> stop()async{
  if(stopping)return;setState(()=>stopping=true);finder?.cancel();downloader?.cancel();analyzer?.cancel();
  try{await Native.call('cancelTextScan');}catch(_){}
  if(rendering){try{await Native.call('cancelExport');}catch(_){/* Publishing finishes safely before the queue stops. */}}
  update('진행 중인 작업을 정리한 뒤 중단해요.');
 }
 Future<void> render(Clip clip)async{
  check();
  final title=await renderOverlayPng(headline:clip.headline,caption:'',style:clip.style);
  final overlays=<Map<String,dynamic>>[];
  for(final t in clip.timedCaptions){
   check();
   overlays.add({'startUs':((t.start-clip.start)*1000000).round(),'endUs':((t.end-clip.start)*1000000).round(),'topPx':placeCaption(t.text,cue:t,clip:clip).stripTop,'png':await renderOverlayPng(headline:'',caption:t.text,style:clip.style,subtitleOnly:true,cue:t,clip:clip)});
  }
  check();rendering=true;
  try{
   final uri=await Native.call<String>('export',{'path':clip.path,'overlay':title,'timedOverlays':overlays,'startMs':(clip.start*1000).round(),'endMs':(clip.end*1000).round(),'mute':clip.mute,'crop':clip.crop});
   if(uri==null)throw StateError('저장 결과를 받지 못했어요.');
   clip.savedUri=uri;clip.savedAt=DateTime.now().toIso8601String();await widget.onSave();
  }finally{rendering=false;}
 }
 Future<void> start()async{
  final key=keyInput.text.trim();if(running||loading||starting)return;
  if(key.isEmpty||searchKey.isEmpty){update('AI 설정에서 Gemini 키와 Tavily 검색 키를 입력해 주세요.');await settings();return;}
  FocusScope.of(context).unfocus();
  setState(()=>starting=true);
  try{notifications=await Native.call<bool>('batchNotifications')??false;}catch(e){update('알림 준비에 실패했어요: $e');if(mounted)setState(()=>starting=false);return;}
  if(!mounted)return;
  setState(()=>starting=false);
  setState((){running=true;stopping=false;savedCount=0;searchRound=0;resultFilter='전체';reports.clear();status='혼합 주제 탐색 시작';});
  var saved=0;var fatal=false;
  store.seen.addAll(widget.clips.where((c)=>c.savedUri.isNotEmpty).map((c)=>MixedDiscovery.videoId(c.url)).whereType<String>());
  store.queue.removeWhere((c)=>store.seen.contains(MixedDiscovery.videoId(c.url)));
  final usedQueries=<String>{};final tried=<String>{};var cursor=0;var processed=0;
  final exhausted=<String>{};
  try{
   await Native.call('batchStart');await saveReport();
   stopPoll=Timer.periodic(const Duration(seconds:2),(_)async{
    if(pollBusy||!running||stopping)return;pollBusy=true;
    try{if(await Native.call<bool>('batchShouldStop')==true&&mounted&&running)await stop();}catch(_){}finally{pollBusy=false;}
   });
   while(saved<5&&!stopping&&!fatal&&processed<60){
    check();
    VideoCandidate? selected;
    for(var offset=0;offset<3;offset++){
     final index=(cursor+offset)%3;final topic=MixedDiscovery.topics[index];
     selected=store.next(topic,skip:tried);
     if(selected==null&&!exhausted.contains(topic)&&searchRound<9){
      final available=MixedDiscovery.queries[index].where((q)=>!usedQueries.contains(q));
      if(available.isEmpty){exhausted.add(topic);continue;}
      final query=store.queryFor(index,usedQueries);usedQueries.add(query);searchRound++;
      store.count(query,'searches');await saveReport();
      finder=MixedDiscovery();
      final found=await finder!.discover(key:searchKey,excluded:store.excluded,query:query,topic:topic,onStatus:(s)=>update('$saved/5 저장 완료 · 검색 $searchRound/9 · $s'));finder=null;check();
      store.add(found);await saveReport();selected=store.next(topic,skip:tried);
     }
     if(selected!=null){cursor=(index+1)%3;break;}
    }
    if(selected==null){
     if(searchRound>=9||exhausted.length==3)break;
     continue;
    }
    final candidate=selected;processed++;tried.add(MixedDiscovery.videoId(candidate.url)!);var retain=false;
    store.count(candidate.query,'attempted');store.accountCount(candidate.url,'attempted');
    final item=<String,dynamic>{'url':candidate.url,'topic':candidate.topic,'title':candidate.title,'state':'다운로드','error':'','query':candidate.query};
    setState(()=>reports.add(item));await saveReport();
    try{
     check();update('${saved}/5 저장 완료 · ${candidate.topic} 원본 다운로드');
     Clip? clip=widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(candidate.url)).firstOrNull;
     if(clip==null||!clip.ready){
      downloader=TikTokDownloader();
      final raw=await downloader!.download(candidate.url,(progress,stage)=>update('${saved}/5 완료 · $stage'),minDuration:5,maxDuration:30);downloader=null;check();
      final downloaded=Clip.fromJson(raw);
      if(clip==null){clip=downloaded;clip.url=candidate.url;widget.clips.insert(0,clip);}
      else{clip.path=downloaded.path;clip.thumbnail=downloaded.thumbnail;clip.duration=downloaded.duration;clip.videoWidth=downloaded.videoWidth;clip.videoHeight=downloaded.videoHeight;clip.name=downloaded.name;clip.creator=downloaded.creator;clip.downloadError='';}
      await widget.onSave();
     }
     store.count(candidate.query,'downloaded');
     final current=clip;
     if(current.duration<5||current.duration>30){item['state']='제외';item['error']='길이 ${current.duration.toStringAsFixed(1)}초 · 사용 범위 5~30초';await saveReport();continue;}
     current.start=0;current.end=current.duration;current.crop=true;current.style=0;current.mute=false;
     item['state']='원본 글자 검사';await saveReport();update('$saved/5 완료 · 원본 자막 확인 중');
     Map<dynamic,dynamic> scan;
     try{scan=await Native.call<Map<dynamic,dynamic>>('scanOriginalText',{'path':current.path})??{};}catch(_){check();throw const AiFailure('원본 글자 검사를 완료하지 못했어요. [SOURCE_TEXT_SCAN]',retryable:true);}
     check();if(scan['complete']!=true)throw const AiFailure('원본 글자 검사가 불완전해요. [SOURCE_TEXT_SCAN]',retryable:true);
     current.videoWidth=(scan['videoWidth'] as num).toDouble();current.videoHeight=(scan['videoHeight'] as num).toDouble();
     item['textScanFrames']=scan['frames'];
     if(OriginalTextPolicy.hasOverlay(scan)){item['state']='제외';item['error']='원본 자막·제목 의심 · 기기 글자 검사에서 화면에 합성된 글자 형태를 발견했어요.';await saveReport();continue;}
     item['state']='AI 생성';item['title']=current.name;await saveReport();
     analyzer=GeminiCaptions();
     final draft=await analyzer!.generate(clip:current,key:key,model:model,assessEntertainment:true,onStatus:(s)=>update('${saved}/5 완료 · $s'));analyzer=null;check();
     item['score']=draft.entertainmentScore;item['quality']=draft.quality.toJson();
     if(!draft.quality.acceptable){item['state']='제외';item['error']='${draft.quality.sourceText=='present'?'기존 자막 포함':draft.quality.sourceText=='uncertain'?'기존 자막 판단 불확실':draft.quality.edited?'편집본':draft.quality.aiSuspected?'AI 영상 의심':'원본 판단 불확실'} · ${draft.quality.reason}';await saveReport();continue;}
     if(draft.entertainmentScore<55){item['state']='제외';item['error']='AI 혼합 주제 적합도 부족 (인기도 측정값이 아니에요)';await saveReport();continue;}
     store.count(candidate.query,'passed');
     current.headline=draft.headline;current.caption='';current.timedCaptions=draft.captions;await widget.onSave();
     item['state']='MP4 저장';await saveReport();update('${saved}/5 완료 · MP4 저장 중');
     await render(current);store.count(candidate.query,'saved');store.accountCount(candidate.url,'saved');saved++;savedCount=saved;item['state']='저장 완료';item['title']=current.headline;item['savedUri']=current.savedUri;update('$saved/5개 저장 완료');await saveReport();
    }catch(e){
     retain=e is AiFailure&&e.retryable;
     item['state']=stopping?'중단':e is DownloadLengthFailure?'제외':'실패';
     item['error']=e is DownloadLengthFailure?'다운로드 전 확인 · 길이 ${e.duration.toStringAsFixed(1)}초 · 사용 범위 5~30초':e.toString();await saveReport();
     // Quota and credential errors would affect every remaining candidate.
     if(stopping||(e is AiFailure&&(e.message.contains('한도')||e.message.contains('권한')||e.message.contains('모델')||e.message.contains('/CLIENT]')))){fatal=true;break;}
    }finally{downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;if(!stopping&&!fatal&&!retain)store.finish(candidate);await saveReport();}
   }
   update(stopping?'작업 중단 · $saved개 저장 완료':saved==5?'혼합 영상 5개 저장 완료':'$saved/5개 저장 완료 · ${fatal?'API 오류로 중단했어요':'검색·처리 한도에 도달했어요'}. 아래 결과를 확인하세요.');
  }catch(e){update(stopping?'작업 중단 · $saved개 저장 완료':'$saved/5개 저장 완료 · $e');}
  finally{
   stopPoll?.cancel();stopPoll=null;
   finder?.cancel();finder=null;downloader?.cancel();downloader=null;analyzer?.cancel();analyzer=null;
   if(mounted)setState(()=>running=false);else running=false;
   try{await saveReport();}catch(_){}
   try{await Native.call('batchFinish',{'status':status,'saved':savedCount});}catch(_){}
  }
 }
 Future<void> recordFeedback(Map<String,dynamic> item,String label)async{
  final id=MixedDiscovery.videoId(item['url'] as String);if(id==null)return;
  setState(()=>store.feedback[id]={'label':label,'url':item['url'],'query':item['query'],'score':item['score'],'quality':item['quality'],'headline':item['title'],'updatedAt':DateTime.now().toIso8601String()});
  try{await saveReport();}catch(_){update('평가 저장에 실패했어요. 다시 눌러 주세요.');}
 }
 Clip? clipFor(Map<String,dynamic> item)=>widget.clips.where((c)=>MixedDiscovery.videoId(c.url)==MixedDiscovery.videoId(item['url'] as String? ?? '')).firstOrNull;
 Future<void> playItem(Map<String,dynamic> item,{bool saved=false})async{
  final clip=clipFor(item);final uri=item['savedUri'] as String? ?? clip?.savedUri??'';
  if(saved&&uri.isNotEmpty){await showPlayback(context,uri:uri,title:item['title'] as String? ?? '저장한 영상');}
  else if(clip!=null&&clip.ready){await showPlayback(context,path:clip.path,title:clip.name);}
 }
 Future<void> editItem(Clip clip)async{
  if(running)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>EditorScreen(clip:clip,onSave:widget.onSave)));
  if(mounted)setState((){});
 }
 Widget countTile(String label,int value,Color color)=>Expanded(child:Column(children:[Text('$value',style:TextStyle(fontSize:24,fontWeight:FontWeight.w600,color:color)),const SizedBox(height:4),Text(label,style:const TextStyle(fontSize:12,color:muted))]));
 Widget resultCard(Map<String,dynamic> item){
  final state=item['state'] as String? ?? '';final clip=clipFor(item);final ready=clip?.ready==true;
  final saved=(item['savedUri'] as String? ?? clip?.savedUri??'').isNotEmpty;
  final message=item['error'] as String? ?? '';
  final complete=state=='저장 완료';final active=!['저장 완료','실패','제외','중단'].contains(state);
  final color=complete?blue:state=='실패'?const Color(0xffb44734):muted;
  return Card(margin:const EdgeInsets.only(bottom:12),color:Colors.white,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[Icon(complete?Icons.check_circle_outline:active?Icons.hourglass_top_rounded:state=='제외'?Icons.skip_next_rounded:Icons.info_outline,size:18,color:color),const SizedBox(width:6),Text(state,style:TextStyle(color:color,fontSize:12,fontWeight:FontWeight.w600)),const Spacer(),Text(item['topic'] as String? ?? '',style:const TextStyle(color:muted,fontSize:11))]),
   const SizedBox(height:12),Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
    if(ready)Padding(padding:const EdgeInsets.only(right:12),child:InkWell(onTap:()=>playItem(item,saved:complete),borderRadius:BorderRadius.circular(12),child:ClipRRect(borderRadius:BorderRadius.circular(12),child:SizedBox(width:72,height:96,child:Stack(fit:StackFit.expand,children:[Container(color:ink,child:clip!.thumbnail.isNotEmpty?Image.file(File(clip.thumbnail),fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.movie,color:Colors.white54)):const Icon(Icons.movie,color:Colors.white54)),const Center(child:Icon(Icons.play_circle_fill,color:Colors.white,size:32))]))))),
    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(item['title'] as String? ?? '',maxLines:3,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w500)),if(ready)Padding(padding:const EdgeInsets.only(top:6),child:Text('${clip!.duration.toStringAsFixed(1)}초',style:const TextStyle(fontSize:12,color:muted))),if(message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text(message.split('\n').first.split(' · 단계').first,style:TextStyle(fontSize:12,color:color)))])),
   ]),
   if(ready||saved)Padding(padding:const EdgeInsets.only(top:12),child:Wrap(spacing:8,runSpacing:4,children:[if(saved)FilledButton.tonalIcon(onPressed:()=>playItem(item,saved:true),icon:const Icon(Icons.play_arrow_rounded,size:18),label:const Text('저장본 재생')),if(ready)OutlinedButton.icon(onPressed:()=>playItem(item),icon:const Icon(Icons.play_arrow_rounded,size:18),label:const Text('원본 재생')),if(ready&&!running)TextButton.icon(onPressed:()=>editItem(clip!),icon:const Icon(Icons.edit_outlined,size:16),label:const Text('편집'))])),
   if(complete||state=='제외')ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('영상 평가',style:TextStyle(fontSize:12,color:muted)),children:[Wrap(spacing:6,runSpacing:4,children:[for(final label in ['괜찮음','재미없음','편집본','AI 의심'])ChoiceChip(label:Text(label,style:const TextStyle(fontSize:11)),selected:store.feedback[MixedDiscovery.videoId(item['url'] as String)]?['label']==label,onSelected:running?null:(_)=>recordFeedback(item,label))])]),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:Text(message.isEmpty?'원본 링크':'상세 정보',style:const TextStyle(fontSize:12,color:muted)),children:[if(message.isNotEmpty)SelectableText(message,style:const TextStyle(fontSize:12,color:muted)),const SizedBox(height:8),SelectableText(item['url'] as String? ?? '',style:const TextStyle(fontSize:11,color:muted)),if(message.isNotEmpty)TextButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:message));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('오류 정보를 복사했어요.')));},icon:const Icon(Icons.copy,size:14),label:const Text('오류 복사'))]),
  ])));
 }
 @override Widget build(BuildContext context){
  final excluded=reports.where((r)=>r['state']=='제외').length;
  final failed=reports.where((r)=>r['state']=='실패').length;
  final shown=reports.reversed.where((r)=>resultFilter=='전체'||(resultFilter=='완료'?r['state']=='저장 완료':['실패','제외','중단'].contains(r['state']))).toList();
  final configured=keyInput.text.isNotEmpty&&searchKey.isNotEmpty;
  return PopScope(canPop:!running,child:Scaffold(appBar:AppBar(title:const Text('혼합 영상 제작',style:TextStyle(fontSize:18)),actions:[IconButton(tooltip:'앱 설정',onPressed:running||loading?null:settings,icon:const Icon(Icons.settings_outlined))]),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,12,20,24),children:[
   const Text('웃긴 순간, 한 번에 5개',style:TextStyle(fontSize:26,fontWeight:FontWeight.w600)),const SizedBox(height:8),
   const Text('웃긴 상황 · 귀여운 동물 · 아기와 가족',style:TextStyle(fontSize:13,color:muted)),const SizedBox(height:20),
   Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xfff2f9ff),borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Text(running?'자동 제작 중':savedCount==5?'제작 완료':'제작 현황',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600)),const Spacer(),Text('$savedCount / 5개',style:const TextStyle(fontSize:18,color:blue,fontWeight:FontWeight.w600))]),const SizedBox(height:14),
    if(loading)const LinearProgressIndicator()else LinearProgressIndicator(value:savedCount/5,minHeight:6,borderRadius:BorderRadius.circular(6)),const SizedBox(height:12),Text(status,style:const TextStyle(fontSize:13)),const SizedBox(height:18),
    Row(children:[countTile('저장',savedCount,blue),countTile('제외',excluded,muted),countTile('실패',failed,const Color(0xffb44734))]),
    if(running)Padding(padding:const EdgeInsets.only(top:14),child:Text(notifications?'홈으로 나가거나 화면을 꺼도 계속해요. 알림에서 중단할 수 있어요.':'알림이 꺼져 있어요. 홈·화면 잠금 중에도 작업을 계속해요.',style:const TextStyle(fontSize:12,color:muted))),
   ])),
   if(!configured&&!loading)Padding(padding:const EdgeInsets.only(top:12),child:ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.settings_outlined,color:blue),title:const Text('제작 전에 앱 설정을 완료하세요',style:TextStyle(fontSize:14)),subtitle:const Text('Gemini · Tavily API 키',style:TextStyle(fontSize:12)),trailing:const Icon(Icons.chevron_right),onTap:settings)),
   const SizedBox(height:20),Row(children:[const Text('제작 결과',style:TextStyle(fontSize:18,fontWeight:FontWeight.w600)),const Spacer(),Text('${reports.length}개 확인',style:const TextStyle(fontSize:12,color:muted))]),const SizedBox(height:10),
   Wrap(spacing:8,children:[for(final label in ['전체','완료','제외·실패'])FilterChip(label:Text(label),selected:resultFilter==label,onSelected:(_)=>setState(()=>resultFilter=label))]),const SizedBox(height:14),
   if(shown.isEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:32),child:Column(children:[const Icon(Icons.video_library_outlined,size:36,color:muted),const SizedBox(height:12),Text(reports.isEmpty?'시작하면 영상 탐색부터 저장까지 진행해요.':'해당하는 결과가 아직 없어요.',style:const TextStyle(fontSize:13,color:muted)),const SizedBox(height:6),const Text('완료된 영상은 여기에서 바로 재생할 수 있어요.',style:TextStyle(fontSize:12,color:muted))])),
   for(final item in shown)resultCard(item),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('제작 방식과 제한',style:TextStyle(fontSize:13,color:muted)),children:[const Text('페이지 길이를 먼저 확인해 5~30초 영상만 다운로드해요. 길이가 없으면 다운로드 후 확인해요. 편집본·AI 의심·판단 불확실 후보는 건너뛰고 다음 후보를 찾습니다. 검색 최대 9회·후보 처리 최대 60개. 5개보다 적게 저장될 수 있어요. AI 판정은 틀릴 수 있어요. 앱 강제 종료·최근 앱에서 제거하면 작업이 중단됩니다.',style:TextStyle(fontSize:12,color:muted))]),
   ExpansionTile(tilePadding:EdgeInsets.zero,title:Text('대기 ${store.queue.length}개 · 검색 효율',style:const TextStyle(fontSize:13,color:muted)),children:[for(final entry in store.metrics.entries)Padding(padding:const EdgeInsets.only(bottom:8),child:Text('${entry.key}\n검색 ${entry.value['searches']??0} · 후보 ${entry.value['found']??0} → 다운로드 ${entry.value['downloaded']??0} → 적합 ${entry.value['passed']??0} → 저장 ${entry.value['saved']??0}',style:const TextStyle(fontSize:12,color:muted)))]),
  ])),bottomNavigationBar:SafeArea(child:Container(padding:const EdgeInsets.fromLTRB(20,12,20,16),decoration:const BoxDecoration(color:Colors.white,border:Border(top:BorderSide(color:line))),child:FilledButton.icon(onPressed:loading||starting||stopping?null:running?stop:start,icon:Icon(running?Icons.stop_rounded:Icons.auto_awesome),label:Text(stopping?'중단하는 중…':running?'자동 제작 중단':'영상 5개 자동 제작'))))));
 }
}
