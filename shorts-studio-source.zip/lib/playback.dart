import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

Future<void> showPlayback(BuildContext context,{String uri='',String path='',required String title})=>Navigator.of(context).push<void>(MaterialPageRoute(builder:(_)=>PlaybackScreen(uri:uri,path:path,title:title)));

class PlaybackScreen extends StatefulWidget {
 const PlaybackScreen({super.key,this.uri='',this.path='',required this.title});
 final String uri,path,title;
 @override State<PlaybackScreen> createState()=>_PlaybackState();
}
class _PlaybackState extends State<PlaybackScreen> with WidgetsBindingObserver {
 late final VideoPlayerController player;
 String? error;bool ready=false;
 @override void initState(){
  super.initState();WidgetsBinding.instance.addObserver(this);
  player=widget.uri.startsWith('content:')?VideoPlayerController.contentUri(Uri.parse(widget.uri)):VideoPlayerController.file(File(widget.path.isNotEmpty?widget.path:Uri.parse(widget.uri).toFilePath()));
  player.addListener(tick);initialize();
 }
 void tick(){if(mounted)setState((){});}
 Future<void> initialize()async{
  try{await player.initialize();if(!mounted)return;await player.play();if(mounted)setState(()=>ready=true);}
  catch(_){if(mounted)setState(()=>error='영상을 열지 못했어요. 저장 파일이 삭제되었거나 접근할 수 없어요.');}
 }
 @override void didChangeAppLifecycleState(AppLifecycleState state){if(state!=AppLifecycleState.resumed)player.pause();}
 @override void dispose(){WidgetsBinding.instance.removeObserver(this);player.removeListener(tick);player.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.black,appBar:AppBar(backgroundColor:Colors.black,foregroundColor:Colors.white,title:Text(widget.title.replaceAll('\n',' '),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:16))),body:SafeArea(child:Column(children:[
  Expanded(child:Center(child:error!=null?Padding(padding:const EdgeInsets.all(24),child:Text(error!,style:const TextStyle(color:Colors.white))):!ready?const CircularProgressIndicator():GestureDetector(onTap:()=>player.value.isPlaying?player.pause():player.play(),child:AspectRatio(aspectRatio:player.value.aspectRatio,child:VideoPlayer(player))))),
  if(ready)Padding(padding:const EdgeInsets.fromLTRB(16,8,16,24),child:Column(children:[VideoProgressIndicator(player,allowScrubbing:true,padding:const EdgeInsets.symmetric(vertical:16)),Row(children:[IconButton(tooltip:player.value.isPlaying?'일시 정지':'재생',color:Colors.white,onPressed:()async{if(player.value.position>=player.value.duration)await player.seekTo(Duration.zero);player.value.isPlaying?player.pause():player.play();},icon:Icon(player.value.isPlaying?Icons.pause_rounded:Icons.play_arrow_rounded)),Text('${player.value.position.inSeconds} / ${player.value.duration.inSeconds}초',style:const TextStyle(color:Colors.white70)),const Spacer(),IconButton(tooltip:'처음부터',color:Colors.white,onPressed:()async{await player.seekTo(Duration.zero);await player.play();},icon:const Icon(Icons.replay))])])),
 ])));
}
