import 'dart:io';
import 'deletion.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

Future<void> showPlayback(BuildContext context,{String uri='',String path='',required String title})=>Navigator.of(context).push<void>(MaterialPageRoute(builder:(_)=>PlaybackScreen(uri:uri,path:path,title:title)));

class PlaybackScreen extends StatefulWidget {
 const PlaybackScreen({super.key,this.uri='',this.path='',required this.title,this.onEnded,this.reviewControls});
 final String uri,path,title;
 final VoidCallback? onEnded;final Widget? reviewControls;
 @override State<PlaybackScreen> createState()=>_PlaybackState();
}
class _PlaybackState extends State<PlaybackScreen> with WidgetsBindingObserver {
 late final VideoPlayerController player;
 String? error;bool ready=false,ended=false;
 @override void initState(){
  super.initState();WidgetsBinding.instance.addObserver(this);
  player=widget.uri.startsWith('content:')?VideoPlayerController.contentUri(Uri.parse(widget.uri)):VideoPlayerController.file(File(widget.path.isNotEmpty?widget.path:Uri.parse(widget.uri).toFilePath()));
  player.addListener(tick);initialize();
 }
 void tick(){
  if(!mounted)return;
  if(player.value.isInitialized&&player.value.duration>Duration.zero&&player.value.position>=player.value.duration&&!ended){
   ended=true;WidgetsBinding.instance.addPostFrameCallback((_){if(mounted)widget.onEnded?.call();});
  }else if(player.value.position<player.value.duration){ended=false;}
  setState((){});
 }
 Future<void> initialize()async{
  try{await player.initialize();if(!mounted)return;await player.play();if(mounted)setState(()=>ready=true);}
  catch(_){if(mounted)setState(()=>error='영상을 열지 못했어요. 저장 파일이 삭제되었거나 접근할 수 없어요.');}
 }
 @override void didChangeAppLifecycleState(AppLifecycleState state){if(state!=AppLifecycleState.resumed)player.pause();}
 @override void dispose(){WidgetsBinding.instance.removeObserver(this);player.removeListener(tick);player.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.black,appBar:AppBar(backgroundColor:Colors.black,foregroundColor:Colors.white,title:Text(widget.title.replaceAll('\n',' '),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:16))),body:SafeArea(child:Column(children:[
  Expanded(child:Center(child:error!=null?Padding(padding:const EdgeInsets.all(24),child:Text(error!,style:const TextStyle(color:Colors.white))):!ready?const CircularProgressIndicator():GestureDetector(onTap:()=>player.value.isPlaying?player.pause():player.play(),child:AspectRatio(aspectRatio:player.value.aspectRatio,child:VideoPlayer(player))))),
  if(ready)Padding(padding:const EdgeInsets.fromLTRB(16,8,16,24),child:Column(children:[VideoProgressIndicator(player,allowScrubbing:true,padding:const EdgeInsets.symmetric(vertical:16)),Row(children:[IconButton(tooltip:player.value.isPlaying?'일시 정지':'재생',color:Colors.white,onPressed:()async{if(player.value.position>=player.value.duration)await player.seekTo(Duration.zero);player.value.isPlaying?player.pause():player.play();},icon:Icon(player.value.isPlaying?Icons.pause_rounded:Icons.play_arrow_rounded)),Text('${player.value.position.inSeconds} / ${player.value.duration.inSeconds}초',style:const TextStyle(color:Colors.white70)),const Spacer(),IconButton(tooltip:'처음부터',color:Colors.white,onPressed:()async{await player.seekTo(Duration.zero);await player.play();},icon:const Icon(Icons.replay))])])),
  if(widget.reviewControls!=null)widget.reviewControls!,
 ])));
}

class PlaybackEntry {
 const PlaybackEntry({required this.uri,required this.title,required this.id});
 final String uri,title,id;
}
Future<void> showReviewPlayback(BuildContext context,{required List<PlaybackEntry> entries,required Map<String,String> ratings,required Future<void> Function(String id,String label) onRate,Future<void> Function(String id)? onDelete})=>Navigator.of(context).push<void>(MaterialPageRoute(builder:(_)=>ReviewPlaybackScreen(entries:entries,ratings:ratings,onRate:onRate,onDelete:onDelete)));
class ReviewPlaybackScreen extends StatefulWidget {
 const ReviewPlaybackScreen({super.key,required this.entries,required this.ratings,required this.onRate,this.onDelete});
 final List<PlaybackEntry> entries;final Map<String,String> ratings;
 final Future<void> Function(String id,String label) onRate;
 final Future<void> Function(String id)? onDelete;
 @override State<ReviewPlaybackScreen> createState()=>_ReviewPlaybackState();
}
class _ReviewPlaybackState extends State<ReviewPlaybackScreen>{
 int index=0;bool saving=false;late final List<PlaybackEntry> entries;
 @override void initState(){super.initState();entries=List.of(widget.entries);}
 void next(){if(!saving&&index+1<entries.length)setState(()=>index++);}
 Future<void> rate(String label)async{
  if(saving)return;final id=entries[index].id;setState(()=>saving=true);
  try{await widget.onRate(id,label);if(mounted)setState(()=>widget.ratings[id]=label);}
  catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('평가를 저장하지 못했어요. 다시 눌러 주세요.')));}
  finally{if(mounted)setState(()=>saving=false);}
 }
 Future<void> deleteCurrent()async{
  if(saving||widget.onDelete==null)return;
  final entry=entries[index];setState(()=>saving=true);
  try{
   if(!await confirmDeletion(context,1,saved:true))return;
   await widget.onDelete!(entry.id);
   if(!mounted)return;
   setState((){entries.removeAt(index);if(index>=entries.length)index=entries.length-1;});
   if(entries.isEmpty)Navigator.pop(context);
  }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('삭제하지 못했어요. 다시 시도해 주세요.')));}
  finally{if(mounted)setState(()=>saving=false);}
 }
 @override Widget build(BuildContext context){
  if(entries.isEmpty)return const Scaffold(body:Center(child:Text('재생할 영상이 없어요.')));
  final entry=entries[index];
  return PlaybackScreen(key:ValueKey(entry.id),uri:entry.uri,title:'${index+1}/${entries.length} · ${entry.title}',onEnded:next,reviewControls:Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Column(children:[
   Wrap(spacing:6,runSpacing:4,children:[for(final label in ['괜찮음','재미없음','편집본','AI 의심'])ChoiceChip(label:Text(label),selected:widget.ratings[entry.id]==label,onSelected:saving?null:(_)=>rate(label))]),
   Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[TextButton.icon(onPressed:saving||index==0?null:()=>setState(()=>index--),icon:const Icon(Icons.skip_previous),label:const Text('이전')),if(widget.onDelete!=null)TextButton.icon(onPressed:saving?null:deleteCurrent,icon:const Icon(Icons.delete_outline),label:const Text('삭제')),TextButton.icon(onPressed:saving||index+1==entries.length?null:next,icon:const Icon(Icons.skip_next),label:const Text('다음'))]),
  ])));
 }
}
