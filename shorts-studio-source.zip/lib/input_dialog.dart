import 'package:flutter/material.dart';

// Own controllers until the dialog route and its exit animation are removed.
class ManagedInputDialog extends StatefulWidget {
 const ManagedInputDialog({super.key,required this.controllers,required this.builder});
 final List<TextEditingController> controllers;
 final WidgetBuilder builder;
 @override State<ManagedInputDialog> createState()=>_ManagedInputDialogState();
}
class _ManagedInputDialogState extends State<ManagedInputDialog> {
 @override Widget build(BuildContext context)=>widget.builder(context);
 @override void dispose(){
  for(final controller in widget.controllers){controller.dispose();}
  super.dispose();
 }
}
