import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'bridge.dart';
import 'model.dart';
import 'youtube_channel.dart';
import 'youtube_upload.dart';
import 'youtube_pc.dart';
import 'youtube_server.dart';
import 'youtube_chrome.dart';

class YouTube extends ChangeNotifier {
  YouTube._({http.Client Function()? clientFactory, YouTubePc? pcAuth})
    : _clientFactory = clientFactory ?? http.Client.new,
      pc = pcAuth ?? YouTubePc();
  @visibleForTesting
  factory YouTube.forTesting({
    required http.Client Function() clientFactory,
    YouTubePc? pcAuth,
  }) => YouTube._(clientFactory: clientFactory, pcAuth: pcAuth);
  final http.Client Function() _clientFactory;
  final YouTubePc pc;
  final server = YouTubeServer();
  final chrome = YouTubeChrome();
  bool get chromeMode => preferences.authMode == 'chrome';
  bool get serverMode => preferences.authMode == 'server';
  bool get brokerMode => pcMode || serverMode;
  YouTubePc get broker => serverMode ? server : pc;
  bool get pcMode => preferences.authMode == 'pc';
  bool get connected => chromeMode ? chrome.hasGrant : brokerMode || user != null;
  String get identity => chromeMode ? 'chrome:${YouTubeChrome.clientId}:${channel?.id ?? preferences.channelId}' : brokerMode ? broker.identity : user?.email ?? '';
  static final instance = YouTube._();
  static const clientId =
      '337875283119-kd8bh4tb2k108mcevsn94fbrb6vju1ah.apps.googleusercontent.com';
  static const scopes = [
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.readonly',
  ];
  YouTubePreferences preferences = YouTubePreferences();
  GoogleSignInAccount? user;
  YouTubeChannel? channel;
  Future<void>? _settingsLoad, _initializing;
  http.Client? _client;
  bool uploading = false, _cancelled = false;
  double? progress;
  String activeUri = '';
  bool get automatic => preferences.automatic;
  Future<void> loadSettings() => _settingsLoad ??= _loadSettings();
  Future<void> _loadSettings() async {
    final raw = await Native.call<String>('youtubeSettings');
    preferences = raw == null
        ? YouTubePreferences()
        : YouTubePreferences.fromJson(
            Map<String, dynamic>.from(jsonDecode(raw) as Map),
          );
    notifyListeners();
  }

  Future<void> saveSettings() async {
    await Native.call('saveYoutubeSettings', {
      'json': jsonEncode(preferences.toJson()),
    });
    notifyListeners();
  }

  Future<void> initialize() => _initializing ??= _initialize();
  Future<void> _initialize() async {
    await loadSettings();
    if (chromeMode) { await chrome.load(); return; }
    if (brokerMode) return;
    await GoogleSignIn.instance.initialize(serverClientId: clientId);
    try {
      user = await GoogleSignIn.instance.attemptLightweightAuthentication();
    } catch (_) {
      /* Explicit connection is available in settings. */
    }
    notifyListeners();
  }

  Future<void> connect() async {
    await initialize();
    if (uploading) throw const YouTubeFailure('전송 후 계정을 변경해 주세요.');
    channel = null;
    preferences.automatic = false;
    preferences.channelId = '';
    preferences.channelTitle = '';
    preferences.email = '';
    if (brokerMode || chromeMode) {
      preferences.authMode = 'google';
      _initializing = null;
      await initialize();
    }
    await saveSettings();
    final previousUser = user;
    user = null;
    notifyListeners();
    // A default-channel change cannot replace a previously granted token.
    // Revoke the previous grant before requesting a fresh account and consent.
    if (previousUser != null) {
      try {
        final cached = await previousUser.authorizationClient
            .authorizationForScopes(scopes);
        if (cached != null)
          await previousUser.authorizationClient.clearAuthorizationToken(
            accessToken: cached.accessToken,
          );
      } catch (_) {
        /* Revocation below is required even if cache invalidation fails. */
      }
    }
    await GoogleSignIn.instance.disconnect();
    user = await GoogleSignIn.instance.authenticate(scopeHint: scopes);
    await user!.authorizationClient.authorizeScopes(scopes);
    await refreshChannel();
  }

  Future<void> connectChrome({bool customTab = false}) async {
    await loadSettings();
    if (uploading) throw const YouTubeFailure('전송 후 계정을 변경해 주세요.');
    channel = null;
    user = null;
    preferences.authMode = 'chrome';
    preferences.automatic = false;
    preferences.email = '';
    preferences.channelId = '';
    preferences.channelTitle = '';
    _initializing = null;
    await saveSettings();
    final connecting = chrome.connect(customTab: customTab);
    notifyListeners();
    try { await connecting; await refreshChannel(); }
    finally { notifyListeners(); }
  }

  Future<void> verifyChromeRefresh() async {
    if (!chromeMode || uploading) throw const YouTubeFailure('Chrome 연결 후 전송이 끝나면 갱신을 확인해 주세요.');
    await chrome.token(forceRefresh: true);
    await refreshChannel();
  }

  Future<void> reconnectServer() async {
    await loadSettings();
    if (uploading) throw const YouTubeFailure('전송 후 계정을 변경해 주세요.');
    channel = null;
    user = null;
    preferences.authMode = 'server';
    preferences.automatic = false;
    preferences.email = '';
    preferences.channelId = '';
    preferences.channelTitle = '';
    _initializing = null;
    await saveSettings();
    final connecting = server.connect();
    notifyListeners();
    await connecting;
    await refreshChannel();
  }

  Future<void> connectServer(String url, String key) async {
    await loadSettings();
    if (uploading) throw const YouTubeFailure('전송 후 계정을 변경해 주세요.');
    await server.configure(url, key);
    channel = null;
    user = null;
    preferences.authMode = 'server';
    preferences.automatic = false;
    preferences.email = '';
    preferences.channelId = '';
    preferences.channelTitle = '';
    _initializing = null;
    await saveSettings();
    final connecting = server.connect();
    notifyListeners();
    await connecting;
    await refreshChannel();
  }

  Future<void> connectBrowser() async {
    await loadSettings();
    if (uploading) throw const YouTubeFailure('전송 후 계정을 변경해 주세요.');
    channel = null;
    user = null;
    preferences.authMode = 'pc';
    preferences.automatic = false;
    preferences.email = '';
    preferences.channelId = '';
    preferences.channelTitle = '';
    await saveSettings();
    final connecting = pc.connect();
    notifyListeners();
    await connecting;
    await refreshChannel();
  }

  Future<void> refreshChannel() async {
    await initialize();
    channel = null;
    notifyListeners();
    final client = _clientFactory();
    try {
      channel = await readYouTubeChannel(client, await _token());
      preferences.channelDiagnostic = {'kind': 'single', 'count': 1};
      if (preferences.channelId.isNotEmpty &&
          (preferences.channelId != channel!.id ||
              preferences.email != identity)) {
        preferences.automatic = false;
        preferences.channelId = '';
        preferences.channelTitle = '';
        preferences.email = '';
        await saveSettings();
      }
      await saveSettings();
    } on YouTubeChannelLookupFailure catch (e) {
      preferences.channelDiagnostic = e.diagnostic;
      try {
        await saveSettings();
      } catch (_) {}
      rethrow;
    } finally {
      client.close();
      notifyListeners();
    }
  }

  Future<void> confirmChannel() async {
    await refreshChannel();
    preferences.email = identity;
    preferences.channelId = channel!.id;
    preferences.channelTitle = channel!.title;
    await saveSettings();
  }

  Future<void> disconnect() async {
    if (uploading) throw const YouTubeFailure('전송 후 연결을 해제해 주세요.');
    final wasPc = brokerMode;
    final wasChrome = chromeMode;
    final revoked = wasChrome ? await chrome.disconnect() : true;
    if (wasPc) await broker.disconnect();
    preferences = YouTubePreferences();
    await saveSettings();
    user = null;
    channel = null;
    notifyListeners();
    if (!wasPc && !wasChrome) await GoogleSignIn.instance.disconnect();
    _initializing = null;
    if (!revoked) throw const YouTubeFailure('휴대폰 연결은 해제했어요. Google 권한 취소는 실패했으니 Google 계정의 연결 관리에서 이 앱 권한을 해제해 주세요.');
  }

  Future<void> setAutomatic(bool enabled) async {
    if (enabled && chromeMode && !chrome.hasRefreshToken) {
      throw const YouTubeFailure('자동 업로드에는 인증 갱신 권한이 필요해요. Chrome에서 다시 연결해 주세요.');
    }
    if (enabled && !preferences.confirmed)
      throw const YouTubeFailure('업로드 채널과 아동용 여부를 먼저 확인해 주세요.');
    preferences.automatic = enabled;
    await saveSettings();
  }

  Future<String> _token() async {
    if (chromeMode) return chrome.token();
    if (brokerMode) {
      final token = await broker.token();
      if (uploading && identity != preferences.email) {
        throw const YouTubeFailure('인증 채널이 바뀌었어요. 설정에서 업로드 대상을 다시 확인해 주세요.');
      }
      return token;
    }
    if (user == null) throw const YouTubeFailure('유튜브 설정에서 계정을 먼저 연결해 주세요.');
    final auth = await user!.authorizationClient.authorizationForScopes(scopes);
    if (auth == null)
      throw const YouTubeFailure('계정을 다시 연결하고 업로드·채널 조회 권한을 허용해 주세요.');
    return auth.accessToken;
  }

  Future<Map<String, dynamic>> state(String uri) async {
    final raw = await Native.call<String>('youtubeUploadState', {'uri': uri});
    return raw == null ? {} : Map<String, dynamic>.from(jsonDecode(raw) as Map);
  }

  void cancelUpload() {
    if (uploading) {
      _cancelled = true;
      _client?.close();
    }
  }

  Future<String> uploadClip(
    Clip clip, {
    void Function(double)? onProgress,
  }) async {
    if (uploading) throw const YouTubeFailure('다른 영상이 전송 중이에요.');
    if (clip.savedUri.isEmpty)
      throw const YouTubeFailure('완성된 MP4를 먼저 저장해 주세요.');
    uploading = true;
    _cancelled = false;
    activeUri = clip.savedUri;
    progress = null;
    notifyListeners();
    final client = _clientFactory();
    _client = client;
    String? path;
    try {
      await initialize();
      final previous = await state(clip.savedUri);
      if (previous['videoId'] is String) return previous['videoId'] as String;
      final actual = await readYouTubeChannel(client, await _token());
      preferences.requireTarget(identity, actual);
      if (_cancelled) throw const YouTubeFailure('전송을 중단했어요. 저장한 영상은 유지됩니다.');
      await Native.call('youtubeKeepAwake', {'enabled': true});
      path = await Native.call<String>('prepareYoutubeVideo', {
        'uri': clip.savedUri,
      });
      if (path == null) throw const YouTubeFailure('저장된 MP4를 열지 못했어요.');
      if (_cancelled) throw const YouTubeFailure('전송을 중단했어요.');
      return await YouTubeUpload(
        client: client,
        token: _token,
        readState: () => state(clip.savedUri),
        writeState: (data) async {
          await Native.call('saveYoutubeUploadState', {
            'uri': clip.savedUri,
            'json': jsonEncode(data),
          });
        },
      ).upload(
        file: File(path),
        email: identity,
        channelId: actual.id,
        title: clip.headline.replaceAll(RegExp(r'\s+'), ' ').trim(),
        description: clip.caption.isNotEmpty
            ? clip.caption
            : clip.timedCaptions.map((t) => t.text).join('\n'),
        madeForKids: preferences.madeForKids!,
        syntheticMedia: preferences.syntheticMedia,
        onProgress: (value) {
          progress = value;
          notifyListeners();
          onProgress?.call(value);
        },
      );
    } catch (e) {
      if (_cancelled)
        throw const YouTubeFailure('전송을 중단했어요. 이어 올리기로 확인할 수 있어요.');
      rethrow;
    } finally {
      client.close();
      _client = null;
      try {
        await Native.call('youtubeKeepAwake', {'enabled': false});
      } catch (_) {}
      if (path != null) {
        try {
          await Native.call('cleanupYoutubeVideo', {'path': path});
        } catch (_) {}
      }
      uploading = false;
      activeUri = '';
      notifyListeners();
    }
  }
}

String youtubeError(Object error) {
  if (error is YouTubeFailure) return error.message;
  if (error is GoogleSignInException)
    return '구글 연결을 완료하지 못했어요. 테스트 사용자·패키지·설치 APK의 SHA-1·업로드 및 채널 조회 권한을 확인해 주세요.';
  if (error is SocketException ||
      error is TimeoutException ||
      error is http.ClientException)
    return '네트워크 연결을 확인한 뒤 이어 올려 주세요.';
  return '작업을 완료하지 못했어요. 저장 공간과 연결 상태를 확인한 뒤 다시 시도해 주세요.';
}
