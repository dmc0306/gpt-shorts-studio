// OCR detects likely overlaid text, not authorship. Never store recognized words.
class OriginalTextPolicy {
 static bool suspicious(Map line){
  double number(String key)=>(line[key] as num? ?? 0).toDouble();
  final x=number('x'),y=number('y'),w=number('w'),h=number('h');
  if([x,y,w,h].any((v)=>!v.isFinite)||w<=0||h<=0)return false;
  if(line['watermark']==true||number('letters')<4)return false;
  final edge=y<.3||y+h>.7;
  return h>=.018&&h<=.2&&w>=(edge?.25:.45);
 }
 static bool hasOverlay(Map scan)=>(scan['lines'] as List? ?? []).whereType<Map>().any(suspicious);
}
