// OCR detects likely overlaid text, not authorship. Never store recognized words.
class OriginalTextPolicy {
 static bool suspicious(Map line){
  double number(String key)=>(line[key] as num? ?? 0).toDouble();
  final x=number('x'),y=number('y'),w=number('w'),h=number('h');
  if([x,y,w,h].any((v)=>!v.isFinite)||w<=0||h<=0)return false;
  if(line['watermark']==true||number('letters')<1)return false;
  if(line['clipped']==true&&h>=.018&&h<=.2&&w>=.025)return true;
  if(number('letters')<4)return false;
  final edge=y<.3||y+h>.7;
  return h>=.018&&h<=.2&&w>=(edge ? .25 : .45);
 }
 static List<double> cropBounds(double width,double height){
  if(width<=0||height<=0||!width.isFinite||!height.isFinite)return [];
  final side=width<height?width:height;
  return [(width-side)/2/width,(height-side)/2/height,side/width,side/height];
 }
 static bool hasOverlay(Map scan,{double? start,double? end})=>(scan['lines'] as List? ?? []).whereType<Map>().where((line){
  if(start==null&&end==null)return true;
  final time=line['time'];return time is num&&time.isFinite&&(start==null||time>=start)&&(end==null||time<=end);
 }).any(suspicious);

}
