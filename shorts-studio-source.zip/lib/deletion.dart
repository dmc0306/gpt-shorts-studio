import 'dart:convert';
import 'package:flutter/material.dart';
import 'bridge.dart';
import 'model.dart';

const libraryCategories=['전체','사람·관계 반전','놀라운 실력','신기한 영상','기발한 상황','귀여운 영상','웃긴 영상','힐링·감동','스포츠·묘기','생활·음식','웃긴 상황·실수·반전','귀여운 동물','아기·가족','기타'];
Future<bool> confirmDeletion(BuildContext context,int count,{required bool saved})async=>await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text('$count개 삭제할까요?'),content:Text(saved?'저장한 MP4를 갤러리에서도 삭제합니다. 원본과 편집 프로젝트는 유지합니다.':'선택한 영상을 수집함에서 삭제합니다. 저장본이 있는 프로젝트는 저장함에 유지하고, 저장본 없는 영상의 앱 내부 원본은 삭제합니다.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('취소')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('삭제'))]))??false;
Future<void> deleteSavedClip(Clip clip)async{
 final uri=clip.savedUri;
 if(uri.isEmpty)return;
 await Native.call('deleteSavedVideo',{'uri':uri});
 clip.savedUri='';clip.savedAt='';clip.inCollection=true;
}
Future<void> syncDeletedReports(Set<String> uris)async{
 final raw=await Native.call<String>('loadBatchReport');
 if(raw==null||raw.isEmpty)return;
 final data=jsonDecode(raw) as Map<String,dynamic>;
 final items=data['items'];if(items is! List)return;
 for(final item in items){if(item is Map&&uris.contains(item['savedUri'])){item['savedUri']='';item['state']='삭제';item['error']='사용자가 저장본을 삭제했어요.';}}
 data['saved']=items.where((i)=>i is Map&&i['state']=='저장 완료'&&(i['savedUri'] as String? ?? '').isNotEmpty).length;
 await Native.call('saveBatchReport',{'json':jsonEncode(data)});
}

// Persist the replacement before deleting the previous gallery file.
Future<bool> replaceSavedClip(Clip clip,String uri,Future<void> Function() save)async{
 if(uri.isEmpty)throw StateError('저장 결과를 받지 못했어요.');
 final previous=clip.savedUri,previousAt=clip.savedAt;
 clip.savedUri=uri;clip.savedAt=DateTime.now().toIso8601String();
 try{await save();}catch(_){clip.savedUri=previous;clip.savedAt=previousAt;rethrow;}
 if(previous.isEmpty||previous==uri)return true;
 var complete=true;
 try{await Native.call('deleteSavedVideo',{'uri':previous});}catch(_){complete=false;}
 try{
  final raw=await Native.call<String>('loadBatchReport');
  if(raw!=null&&raw.isNotEmpty){
   final data=jsonDecode(raw) as Map<String,dynamic>;final items=data['items'];var changed=false;
   if(items is List){for(final item in items){if(item is Map&&item['savedUri']==previous){item['savedUri']=uri;item['title']=clip.headline;changed=true;}}}
   if(changed)await Native.call('saveBatchReport',{'json':jsonEncode(data)});
  }
 }catch(_){complete=false;}
 return complete;
}
