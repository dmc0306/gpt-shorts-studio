package com.local.shorts_studio

import android.os.Bundle
import net.openid.appauth.RedirectUriReceiverActivity

/** Safely tracks whether Android received the callback; never retains OAuth URI or secrets. */
class YouTubeRedirectTraceActivity : RedirectUriReceiverActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val uri = intent?.data
        val valid = uri?.scheme == YouTubeChromeAuth.REDIRECT_SCHEME && uri.path == "/oauth2redirect"
        val code = try { uri?.getQueryParameter("code") != null } catch (_: Exception) { false }
        val error = try { uri?.getQueryParameter("error") != null } catch (_: Exception) { false }
        getSharedPreferences("studio",MODE_PRIVATE).edit()
            .putLong("ytRedirectReceived",System.currentTimeMillis())
            .putBoolean("ytRedirectValid",valid)
            .putBoolean("ytRedirectCode",code)
            .putBoolean("ytRedirectError",error).commit()
        super.onCreate(savedInstanceState)
    }
}
