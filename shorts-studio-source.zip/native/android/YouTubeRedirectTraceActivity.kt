package com.local.shorts_studio

import android.os.Bundle
import android.app.Activity
import android.content.Intent

/** Safely tracks whether Android received the callback; never retains OAuth URI or secrets. */
class YouTubeRedirectTraceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val uri = intent?.data
        val valid = uri?.scheme == YouTubeChromeAuth.REDIRECT_SCHEME && uri.path == "/oauth2redirect"
        val code = try { uri?.getQueryParameter("code") != null } catch (_: Exception) { false }
        val error = try { uri?.getQueryParameter("error") != null } catch (_: Exception) { false }
        getSharedPreferences("studio",MODE_PRIVATE).edit()
            .putLong("ytRedirectReceived",System.currentTimeMillis())
            .putBoolean("ytRedirectValid",valid)
            .putBoolean("ytRedirectCode",code)
            .putBoolean("ytRedirectError",error).commit()
        // The AppAuth management Activity is deliberately bypassed.
        // Send the callback to our own existing Activity, without exposing it to other apps.
        val incoming = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_CHROME_OAUTH_REDIRECT)
            .setData(uri)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(incoming)
        finish()
    }
}
