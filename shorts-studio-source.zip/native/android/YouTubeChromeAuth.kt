package com.local.shorts_studio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.MethodChannel
import net.openid.appauth.AppAuthConfiguration
import net.openid.appauth.AuthState
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import net.openid.appauth.browser.VersionedBrowserMatcher
import net.openid.appauth.connectivity.ConnectionBuilder
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Android public OAuth client: external Chrome, S256 PKCE and Keystore-only state. */
class YouTubeChromeAuth(
    private val activity: Activity,
    private val readStore: () -> String,
    private val writeStore: (String) -> Unit
) {
    companion object {
        const val CLIENT_ID = "337875283119-som1inoqhtgpf1jvkk4b31tg46rub1ag.apps.googleusercontent.com"
        const val REDIRECT_SCHEME = "com.googleusercontent.apps.337875283119-som1inoqhtgpf1jvkk4b31tg46rub1ag"
        val REDIRECT: Uri = Uri.parse("$REDIRECT_SCHEME:/oauth2redirect")
        private val AUTH = Uri.parse("https://accounts.google.com/o/oauth2/v2/auth")
        private val TOKEN = Uri.parse("https://oauth2.googleapis.com/token")
        private val SCOPES = listOf("https://www.googleapis.com/auth/youtube.readonly", "https://www.googleapis.com/auth/youtube.upload")
    }

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val config = AuthorizationServiceConfiguration(AUTH, TOKEN)
    // Chrome browser matcher excludes Custom Tabs: open the installed Chrome app itself.
    private fun createService(matcher: VersionedBrowserMatcher): AuthorizationService {
        return AuthorizationService(activity, AppAuthConfiguration.Builder()
            .setBrowserMatcher(matcher)
            .setConnectionBuilder(ConnectionBuilder { uri ->
                require(uri == TOKEN) { "Unexpected token endpoint" }
                (URL(uri.toString()).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 20000
                    readTimeout = 20000
                }
            }).build())
    }
    private val serviceLazy = lazy { createService(VersionedBrowserMatcher.CHROME_BROWSER) }
    private val tabServiceLazy = lazy { createService(VersionedBrowserMatcher.CHROME_CUSTOM_TAB) }
    private val service get() = serviceLazy.value
    private var loginService: AuthorizationService? = null
    private var loginBrowserMode = "browser"
    private var pending: MethodChannel.Result? = null
    private var epoch = 0
    private var requestCode = 8400
    private var timeout: Runnable? = null
    private var requestState: String? = null

    private fun begin(result: MethodChannel.Result, milliseconds: Long = 90000): Int? {
        if (pending != null) {
            result.error("AUTH_CHROME_BUSY", "다른 Chrome 인증 작업이 진행 중이에요.", null)
            return null
        }
        pending = result
        val attempt = ++epoch
        timeout = Runnable { if (attempt == epoch) fail("AUTH_CHROME_TIMEOUT", "인증 응답 시간이 지났어요. 다시 시도해 주세요.") }
        handler.postDelayed(timeout!!, milliseconds)
        return attempt
    }
    private fun take(): MethodChannel.Result? {
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
        requestState = null
        return pending.also { pending = null }
    }
    private fun fail(code: String, message: String, details: Map<String, Any> = emptyMap()) {
        take()?.error(code, message, details)
    }
    private fun oauthFailure(exception: AuthorizationException?, stage: String) {
        val allowed = setOf("access_denied", "invalid_request", "invalid_scope", "invalid_grant", "invalid_client", "unauthorized_client", "redirect_uri_mismatch", "unsupported_response_type")
        val details = mutableMapOf<String, Any>("stage" to stage)
        if (exception != null) {
            details["oauthType"] = exception.type
            details["oauthCode"] = exception.code
            exception.error?.takeIf { it in allowed }?.let { details["oauthError"] = it }
        }
        fail("AUTH_CHROME_${stage.uppercase()}", "Chrome 인증을 완료하지 못했어요. 연결 설정 또는 권한을 확인해 주세요.", details)
    }

    private fun redirectTrace(): Map<String, Any> {
        val p = activity.getSharedPreferences("studio", Activity.MODE_PRIVATE)
        return mapOf("redirectAttempted" to (p.getLong("ytRedirectAttempt",0L)>0L),
            "redirectSeen" to (p.getLong("ytRedirectReceived",0L)>0L),
            "redirectPathValid" to p.getBoolean("ytRedirectValid",false),
            "redirectHasCode" to p.getBoolean("ytRedirectCode",false),
            "redirectHasError" to p.getBoolean("ytRedirectError",false))
    }
    fun connect(result: MethodChannel.Result, customTab: Boolean = false) {
        val attempt = begin(result, 600000) ?: return
        try {
            check(activity.getSharedPreferences("studio", Activity.MODE_PRIVATE).edit()
                .putLong("ytRedirectAttempt",System.currentTimeMillis())
                .remove("ytRedirectReceived").remove("ytRedirectValid")
                .remove("ytRedirectCode").remove("ytRedirectError").commit())
            val request = AuthorizationRequest.Builder(config, CLIENT_ID, ResponseTypeValues.CODE, REDIRECT)
                .setScopes(SCOPES)
                .setPrompt("select_account consent")
                .setAdditionalParameters(mapOf("access_type" to "offline", "include_granted_scopes" to "false"))
                .build()
            // AppAuth generates a fresh verifier/state and validates returned state itself.
            require(request.codeVerifier != null && request.codeVerifierChallengeMethod == "S256")
            requestState = request.state
            requestCode = 8400 + attempt % 1000
            val selected = if (customTab) tabServiceLazy.value else service
            loginService = selected
            loginBrowserMode = if (customTab) "custom_tab" else "browser"
            @Suppress("DEPRECATION")
            activity.startActivityForResult(selected.getAuthorizationRequestIntent(request), requestCode)
        } catch (_: Exception) {
            fail("AUTH_CHROME_OPEN", "휴대폰 Chrome을 설치·활성화한 뒤 다시 시도해 주세요.")
        }
    }

    fun onActivityResult(code: Int, resultCode: Int, data: Intent?): Boolean {
        if (code !in 8400..9399) return false
        if (code != requestCode || pending == null) return true
        val attempt = epoch
        val response: AuthorizationResponse?
        val exception: AuthorizationException?
        try {
            response = data?.let { AuthorizationResponse.fromIntent(it) }
            exception = data?.let { AuthorizationException.fromIntent(it) }
        } catch (_: Exception) {
            fail("AUTH_CHROME_STATE", "인증 복귀 정보를 확인하지 못했어요.")
            return true
        }
        if (response == null) {
            if (exception == null) {
                fail("AUTH_CHROME_NO_RESULT", "Chrome 인증 복귀 응답이 앱으로 전달되지 않았어요. Chrome 탭 방식으로 다시 시도해 주세요.", mapOf("resultCode" to resultCode, "returnedIntent" to (data != null), "mode" to loginBrowserMode))
            } else if (exception.type == AuthorizationException.TYPE_GENERAL_ERROR && exception.code == 1) {
                val receipt = redirectTrace()
                val seen = receipt["redirectSeen"] == true
                fail(if (seen) "AUTH_CHROME_AFTER_REDIRECT" else "AUTH_CHROME_REDIRECT_MISSING",
                    if (seen) "OAuth 복귀 URI를 받았지만 AppAuth가 완료하지 못했어요."
                    else "Google 동의 후 OAuth 복귀 URI가 Android 앱에 전달되지 않았어요.",
                    receipt + mapOf("oauthType" to exception.type, "oauthCode" to exception.code))
            } else oauthFailure(exception, "authorize")
            return true
        }
        if (exception != null || response.request.clientId != CLIENT_ID ||
            response.request.redirectUri != REDIRECT || response.request.configuration.tokenEndpoint != TOKEN ||
            requestState == null || response.state != requestState || response.authorizationCode.isNullOrBlank()) {
            fail("AUTH_CHROME_STATE", "인증 복귀 정보를 확인하지 못했어요. 앱에서 다시 로그인해 주세요.")
            return true
        }
        try {
            val state = AuthState(response, null)
            (loginService ?: service).performTokenRequest(response.createTokenExchangeRequest()) { token, error ->
                handler.post {
                    if (attempt != epoch || pending == null) return@post
                    if (token == null || error != null) { oauthFailure(error, "token"); return@post }
                    state.update(token, null)
                    if (state.accessToken.isNullOrBlank() || state.scopeSet?.containsAll(SCOPES) != true) {
                        fail("AUTH_CHROME_SCOPE", "채널 조회·업로드 권한을 모두 허용한 뒤 다시 연결해 주세요.")
                        return@post
                    }
                    try {
                        writeStore(state.jsonSerializeString())
                        take()?.success(metadata(state))
                    } catch (_: Exception) { fail("AUTH_CHROME_STORAGE", "인증 정보를 암호화해 저장하지 못했어요.") }
                }
            }
        } catch (_: Exception) { oauthFailure(null, "token") }
        return true
    }

    private fun load(): AuthState? {
        val raw = readStore()
        if (raw.isBlank()) return null
        val state = AuthState.jsonDeserialize(raw)
        val request = state.lastAuthorizationResponse?.request
        require(request != null)
        require(request.clientId == CLIENT_ID && request.redirectUri == REDIRECT && request.configuration.tokenEndpoint == TOKEN)
        require(state.clientSecret == null)
        return state
    }
    private fun metadata(state: AuthState): Map<String, Any> = mapOf(
        "hasGrant" to state.isAuthorized,
        "hasRefreshToken" to !state.refreshToken.isNullOrBlank(),
        "expiresAt" to (state.accessTokenExpirationTime ?: 0L)
    )
    fun status(result: MethodChannel.Result) {
        try { result.success((load()?.let { metadata(it) } ?: mapOf("hasGrant" to false, "hasRefreshToken" to false)) + redirectTrace()) }
        catch (_: Exception) { result.error("AUTH_CHROME_STORAGE", "저장된 인증 정보를 읽지 못했어요. Chrome에서 다시 연결해 주세요.", null) }
    }
    fun token(result: MethodChannel.Result, force: Boolean = false) {
        val attempt = begin(result) ?: return
        try {
            val state = load()
            if (state == null || !state.isAuthorized) { fail("AUTH_CHROME_RECONNECT", "휴대폰 Chrome에서 채널을 먼저 연결해 주세요."); return }
            if (force && state.refreshToken.isNullOrBlank()) {
                fail("AUTH_CHROME_NO_REFRESH", "갱신 권한을 받지 못했어요. Chrome에서 다시 로그인하고 동의해 주세요.")
                return
            }
            if ((state.accessTokenExpirationTime ?: 0L) <= System.currentTimeMillis() + 60000 && state.refreshToken.isNullOrBlank()) {
                fail("AUTH_CHROME_RECONNECT", "인증이 만료됐어요. Chrome에서 다시 연결해 주세요.")
                return
            }
            if (force) state.setNeedsTokenRefresh(true)
            state.performActionWithFreshTokens(service) { accessToken, _, error ->
                handler.post {
                    if (attempt != epoch || pending == null) return@post
                    if (error != null || accessToken.isNullOrBlank()) { oauthFailure(error, "refresh"); return@post }
                    try {
                        writeStore(state.jsonSerializeString())
                        take()?.success(metadata(state) + mapOf("accessToken" to accessToken))
                    } catch (_: Exception) { fail("AUTH_CHROME_STORAGE", "갱신된 인증 정보를 암호화해 저장하지 못했어요.") }
                }
            }
        } catch (_: Exception) { fail("AUTH_CHROME_RECONNECT", "인증 정보를 확인하지 못했어요. Chrome에서 다시 연결해 주세요.") }
    }
    fun cancel() {
        epoch++
        fail("AUTH_CHROME_CANCELLED", "Chrome 인증 대기를 중단했어요.")
    }
    fun disconnect(result: MethodChannel.Result) {
        cancel()
        val refresh = try { load()?.refreshToken } catch (_: Exception) { null }
        try { writeStore("") } catch (_: Exception) { result.error("AUTH_CHROME_STORAGE", "인증 정보를 삭제하지 못했어요.", null); return }
        io.execute {
            var revoked = refresh == null
            if (refresh != null) {
                try {
                    val connection = URL("https://oauth2.googleapis.com/revoke").openConnection() as HttpURLConnection
                    connection.requestMethod = "POST"
                    connection.instanceFollowRedirects = false
                    connection.connectTimeout = 15000
                    connection.readTimeout = 15000
                    connection.doOutput = true
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    try {
                        connection.outputStream.use { it.write(("token=" + URLEncoder.encode(refresh, "UTF-8")).toByteArray(Charsets.UTF_8)) }
                        revoked = connection.responseCode == 200
                    } finally { connection.disconnect() }
                } catch (_: Exception) { /* Local grant is deleted even if remote revocation fails. */ }
            }
            handler.post { result.success(mapOf("revoked" to revoked)) }
        }
    }
    fun close() {
        cancel()
        if (serviceLazy.isInitialized()) service.dispose()
        if (tabServiceLazy.isInitialized()) tabServiceLazy.value.dispose()
        io.shutdownNow()
    }
}
