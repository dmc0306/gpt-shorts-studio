dependencies {
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    // Align Transformer with the ExoPlayer version required by video_player_android.
    implementation("androidx.media3:media3-transformer:1.9.2")
    implementation("androidx.media3:media3-effect:1.9.2")
    implementation("androidx.media3:media3-common:1.9.2")
}
