package com.local.shorts_studio

import android.media.MediaMetadataRetriever
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.File
import java.util.concurrent.TimeUnit

// Bundled model: images and recognized text stay on the device.
object OriginalTextScanner {
    @Volatile var cancelled=false
    fun scan(file:File,startSeconds:Double=0.0,endSeconds:Double?=null,crop:Boolean=false):Map<String,Any> {
        cancelled=false
        val media=MediaMetadataRetriever()
        val recognizer=TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        val lines=mutableListOf<Map<String,Any>>()
        var count=0
        try {
            media.setDataSource(file.absolutePath)
            val seconds=(media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDouble()?:0.0)/1000
            require(seconds in 0.2..60.1)
            val end=endSeconds?:seconds
            require(startSeconds.isFinite()&&end.isFinite()&&startSeconds>=0&&end<=seconds+0.05&&end>startSeconds)
            val stop=minOf(end,seconds)
            val span=stop-startSeconds
            val started=SystemClock.elapsedRealtime()
            val samples=minOf(16,maxOf(6,kotlin.math.ceil(span).toInt()))
            var width=0;var height=0
            for(index in 0 until samples){
                check(!BatchService.stopRequested&&!cancelled){"원본 글자 검사를 중단했어요."}
                check(SystemClock.elapsedRealtime()-started<60000){"원본 글자 검사 시간이 초과됐어요."}
                val margin=minOf(0.1,span/4)
                val time=(startSeconds+margin+(span-2*margin)*index/(samples-1)).coerceIn(startSeconds,stop)
                val bitmap=media.getScaledFrameAtTime((time*1000000).toLong(),MediaMetadataRetriever.OPTION_CLOSEST,720,1280)
                    ?:error("원본 장면을 읽지 못했어요.")
                try {
                    width=bitmap.width;height=bitmap.height
                    val side=minOf(width,height)
                    val frame=if(crop&&width!=height)Bitmap.createBitmap(bitmap,(width-side)/2,(height-side)/2,side,side)else bitmap
                    try {
                    val result=Tasks.await(recognizer.process(InputImage.fromBitmap(frame,0)),10,TimeUnit.SECONDS)
                    count++
                    for(block in result.textBlocks)for(line in block.lines){
                        val box=line.boundingBox?:continue
                        val letters=line.text.count{it.isLetterOrDigit()}
                        if(letters<1)continue
                        val watermark=line.text.trim().startsWith("@")||line.text.trim().equals("TikTok",ignoreCase=true)
                        lines.add(mapOf("x" to box.left.toDouble()/frame.width,"y" to box.top.toDouble()/frame.height,
                            "w" to box.width().toDouble()/frame.width,"h" to box.height().toDouble()/frame.height,
                            "clipped" to (box.left<=2||box.top<=2||box.right>=frame.width-2||box.bottom>=frame.height-2),
                            "letters" to letters,"watermark" to watermark,"time" to time))
                    }
                    } finally {if(frame!==bitmap)frame.recycle()}
                } finally {bitmap.recycle()}
            }
            return mapOf("complete" to true,"frames" to count,"videoWidth" to width,"videoHeight" to height,"lines" to lines,"cropped" to crop,"scanStart" to startSeconds,"scanEnd" to stop)
        } finally {recognizer.close();media.release()}
    }
}
