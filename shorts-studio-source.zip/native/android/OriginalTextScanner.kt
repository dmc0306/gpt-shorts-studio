package com.local.shorts_studio

import android.media.MediaMetadataRetriever
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.File
import java.util.concurrent.TimeUnit

// Bundled model: images and recognized text stay on the device.
object OriginalTextScanner {
    @Volatile var cancelled=false
    fun scan(file:File):Map<String,Any> {
        cancelled=false
        val media=MediaMetadataRetriever()
        val recognizer=TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        val lines=mutableListOf<Map<String,Any>>()
        var count=0
        try {
            media.setDataSource(file.absolutePath)
            val seconds=(media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDouble()?:0.0)/1000
            require(seconds in 0.2..30.1)
            val started=SystemClock.elapsedRealtime()
            val samples=minOf(16,maxOf(6,kotlin.math.ceil(seconds).toInt()))
            var width=0;var height=0
            for(index in 0 until samples){
                check(!BatchService.stopRequested&&!cancelled){"원본 글자 검사를 중단했어요."}
                check(SystemClock.elapsedRealtime()-started<60000){"원본 글자 검사 시간이 초과됐어요."}
                val time=(0.1+(seconds-0.2)*index/(samples-1)).coerceIn(0.0,seconds)
                val bitmap=media.getScaledFrameAtTime((time*1000000).toLong(),MediaMetadataRetriever.OPTION_CLOSEST,720,1280)
                    ?:error("원본 장면을 읽지 못했어요.")
                try {
                    width=bitmap.width;height=bitmap.height
                    val result=Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap,0)),10,TimeUnit.SECONDS)
                    count++
                    for(block in result.textBlocks)for(line in block.lines){
                        val box=line.boundingBox?:continue
                        val letters=line.text.count{it.isLetterOrDigit()}
                        if(letters<4)continue
                        val watermark=line.text.trim().startsWith("@")||line.text.trim().equals("TikTok",ignoreCase=true)
                        lines.add(mapOf("x" to box.left.toDouble()/width,"y" to box.top.toDouble()/height,
                            "w" to box.width().toDouble()/width,"h" to box.height().toDouble()/height,
                            "letters" to letters,"watermark" to watermark,"time" to time))
                    }
                } finally {bitmap.recycle()}
            }
            return mapOf("complete" to true,"frames" to count,"videoWidth" to width,"videoHeight" to height,"lines" to lines)
        } finally {recognizer.close();media.release()}
    }
}
