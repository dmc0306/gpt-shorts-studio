// Passwords are read only from CI environment variables, never generated files.
val studioKeystorePath = System.getenv("ANDROID_KEYSTORE_PATH")
if (!studioKeystorePath.isNullOrBlank()) {
    fun signingSecret(name: String): String = System.getenv(name)
        ?.takeIf { it.isNotEmpty() } ?: error("Missing Android signing setting: $name")
    android {
        val studioSigning = signingConfigs.create("studio") {
            storeFile = file(studioKeystorePath)
            storePassword = signingSecret("ANDROID_KEYSTORE_PASSWORD")
            keyAlias = signingSecret("ANDROID_KEY_ALIAS")
            keyPassword = signingSecret("ANDROID_KEY_PASSWORD")
        }
        buildTypes {
            getByName("debug") { signingConfig = studioSigning }
            getByName("release") { signingConfig = studioSigning }
        }
    }
}
