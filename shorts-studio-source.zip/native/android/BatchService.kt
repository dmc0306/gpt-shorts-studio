package com.local.shorts_studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

// Keeps a user-started batch alive while the activity is stopped (Home/lock).
// No sticky restart: a dead Flutter process cannot safely replay an in-flight export.
class BatchService : Service() {
    companion object {
        const val CHANNEL="shorts_batch"
        const val ID=502
        var active:BatchService?=null
        var stopRequested=false
        var onStop:(()->Unit)?=null
        fun update(text:String,saved:Int){active?.show(text,saved)}
        fun complete(context:android.content.Context,text:String,saved:Int){
            val open=PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notice=Notification.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("쇼츠 자동 제작 · ${saved}/5개 저장").setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true).build()
            context.getSystemService(NotificationManager::class.java).notify(ID+1,notice)
        }
    }
    private var wake:PowerManager.WakeLock?=null
    private val handler=Handler(Looper.getMainLooper())
    private val deadline=Runnable{requestStop();stopSelf()}
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){
        super.onCreate();active=this
        val manager=getSystemService(NotificationManager::class.java)
        manager.cancel(ID+1)
        manager.createNotificationChannel(NotificationChannel(CHANNEL,"영상 자동 제작",NotificationManager.IMPORTANCE_LOW))
        val types=ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or (if(Build.VERSION.SDK_INT>=35) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else 0)
        startForeground(ID,notification("영상 자동 제작 준비 중",0),types)
        wake=getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"ShortsStudio:Batch").apply{acquire(60*60*1000L)}
        handler.postDelayed(deadline,60*60*1000L)
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        if(intent?.action=="STOP"){requestStop();show("진행 중인 작업을 정리한 뒤 중단해요",0)}
        return START_NOT_STICKY
    }
    private fun requestStop(){stopRequested=true;onStop?.invoke()}
    private fun notification(text:String,saved:Int):Notification{
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop=PendingIntent.getService(this,1,Intent(this,BatchService::class.java).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("쇼츠 자동 제작 · ${saved.coerceIn(0,5)}/5개 저장").setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true).setProgress(5,saved.coerceIn(0,5),false).addAction(Notification.Action.Builder(null,"중단",stop).build()).build()
    }
    private fun show(text:String,saved:Int){getSystemService(NotificationManager::class.java).notify(ID,notification(text,saved))}
    override fun onTimeout(startId:Int,fgsType:Int){requestStop();stopSelf()}
    override fun onTaskRemoved(rootIntent:Intent?){requestStop();stopSelf();super.onTaskRemoved(rootIntent)}
    override fun onDestroy(){
        handler.removeCallbacks(deadline)
        if(wake?.isHeld==true)wake?.release();wake=null
        active=null;stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()
    }
}
