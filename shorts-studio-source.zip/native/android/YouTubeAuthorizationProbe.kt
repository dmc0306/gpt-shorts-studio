package com.local.shorts_studio

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import io.flutter.plugin.common.MethodChannel

/** Diagnostic only: no Google Sign-In, server, refresh-token storage or upload. */
class YouTubeAuthorizationProbe(private val activity: Activity) {
    private val client = Identity.getAuthorizationClient(activity)
    private val handler = Handler(Looper.getMainLooper())
    private var pending: MethodChannel.Result? = null
    private var resolutionShown = false
    private var requestCode = 7300
    private var generation = 0
    private val scopes = listOf(
        Scope("https://www.googleapis.com/auth/youtube.readonly"),
        Scope("https://www.googleapis.com/auth/youtube.upload")
    )
    private var timeout: Runnable? = null

    fun start(result: MethodChannel.Result) {
        if (pending != null) {
            result.error("AUTH_NATIVE_BUSY", "다른 권한 요청이 진행 중이에요.", null)
            return
        }
        pending = result
        resolutionShown = false
        generation++
        requestCode = 7300 + generation % 1000
        val attempt = generation
        timeout = Runnable { if (generation == attempt) fail("AUTH_NATIVE_TIMEOUT", "권한 요청 시간이 지났어요. 다시 시도해 주세요.") }
        handler.postDelayed(timeout!!, 600000)
        // Force Google account selection without authenticating a personal Google ID first.
        // Google controls whether this chooser also offers YouTube Brand identities.
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(scopes)
            .setOptOutIncludingGrantedScopes(true)
            .setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)
            .build()
        client.authorize(request)
            .addOnSuccessListener { authorization ->
                if (generation != attempt || pending == null) return@addOnSuccessListener
                if (authorization.hasResolution()) {
                    resolutionShown = true
                    try {
                        val intent = authorization.pendingIntent ?: error("Missing resolution")
                        @Suppress("DEPRECATION")
                        activity.startIntentSenderForResult(intent.intentSender, requestCode, null, 0, 0, 0)
                    } catch (_: Exception) {
                        fail("AUTH_NATIVE_RESOLUTION", "Google 권한 선택 화면을 열지 못했어요.")
                    }
                } else complete(authorization)
            }
            .addOnFailureListener { exception ->
                if (generation == attempt) failException(exception)
            }
    }

    fun onActivityResult(code: Int, resultCode: Int, data: Intent?): Boolean {
        if (code !in 7300..8299) return false
        if (code != requestCode || pending == null) return true
        if (resultCode != Activity.RESULT_OK || data == null) {
            fail("AUTH_NATIVE_CANCELLED", "Google 권한 선택을 취소했어요.")
        } else {
            try { complete(client.getAuthorizationResultFromIntent(data)) }
            catch (exception: Exception) { failException(exception) }
        }
        return true
    }

    private fun complete(authorization: AuthorizationResult) {
        val token = authorization.accessToken
        val granted = authorization.grantedScopes
        if (token.isNullOrBlank() || !granted.containsAll(scopes.map { it.scopeUri })) {
            fail("AUTH_NATIVE_SCOPE", "채널 조회·업로드 권한을 모두 허용해 주세요.")
            return
        }
        val result = takeResult() ?: return
        // Token crosses only the private method channel, never preferences, logs or UI.
        result.success(mapOf("accessToken" to token, "resolutionShown" to resolutionShown,
            "scopes" to granted.filter { it in scopes.map { scope -> scope.scopeUri } }))
    }

    private fun failException(exception: Exception) {
        val code = (exception as? ApiException)?.statusCode
        fail("AUTH_NATIVE_${code ?: "UNKNOWN"}", when (code) {
            10 -> "Android OAuth의 패키지 이름·설치 APK 서명 SHA-1을 확인해 주세요."
            16 -> "Google 권한 요청을 취소했어요."
            7 -> "Google 인증 네트워크 연결을 확인해 주세요."
            else -> "Google 권한 요청에 실패했어요. Google Play 서비스와 OAuth 설정을 확인해 주세요."
        })
    }

    private fun takeResult(): MethodChannel.Result? {
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
        return pending.also { pending = null }
    }

    private fun fail(code: String, message: String) {
        val result = takeResult() ?: return
        result.error(code, message, mapOf("resolutionShown" to resolutionShown))
    }

    fun cancel() {
        generation++
        fail("AUTH_NATIVE_CANCELLED", "권한 테스트를 중단했어요.")
    }
}
