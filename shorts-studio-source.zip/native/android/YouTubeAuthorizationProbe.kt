package com.local.shorts_studio

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import java.security.MessageDigest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import io.flutter.plugin.common.MethodChannel

/** Diagnostic only: no Google Sign-In, server, refresh-token storage or upload. */
class YouTubeAuthorizationProbe(private val activity: Activity) {
    private val client = Identity.getAuthorizationClient(activity)
    private val handler = Handler(Looper.getMainLooper())
    private var pending: MethodChannel.Result? = null
    private var resolutionShown = false
    private var requestCode = 7300
    private var generation = 0
    private var scopes = listOf(Scope("https://www.googleapis.com/auth/youtube.readonly"))
    private var diagnostic = mutableMapOf<String, Any>()

    private fun environment(): MutableMap<String, Any> {
        val info = mutableMapOf<String, Any>("packageName" to activity.packageName)
        try {
            val pkg = activity.packageManager.getPackageInfo(activity.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info["signingSha1"] = pkg.signingInfo?.apkContentsSigners?.map { signature ->
                MessageDigest.getInstance("SHA-1").digest(signature.toByteArray()).joinToString(":") { byte -> "%02X".format(byte.toInt() and 255) }
            } ?: emptyList<String>()
            info["playServicesVersion"] = activity.packageManager.getPackageInfo("com.google.android.gms", 0).versionName ?: "unknown"
        } catch (_: Exception) { /* Diagnostic metadata is optional, never block authorization. */ }
        return info
    }
    private var timeout: Runnable? = null

    fun start(result: MethodChannel.Result, includeUpload: Boolean = false, selectAccount: Boolean = true) {
        if (pending != null) {
            result.error("AUTH_NATIVE_BUSY", "다른 권한 요청이 진행 중이에요.", null)
            return
        }
        pending = result
        resolutionShown = false
        scopes = listOf(Scope("https://www.googleapis.com/auth/youtube.readonly")) +
            if (includeUpload) listOf(Scope("https://www.googleapis.com/auth/youtube.upload")) else emptyList()
        diagnostic = environment().apply {
            put("scopeMode", if (includeUpload) "read_upload" else "readonly")
            put("selectAccount", selectAccount)
            put("callbackReceived", false)
            put("origin", "authorize_task")
        }
        generation++
        requestCode = 7300 + generation % 1000
        val attempt = generation
        timeout = Runnable { if (generation == attempt) fail("AUTH_NATIVE_TIMEOUT", "권한 요청 시간이 지났어요. 다시 시도해 주세요.") }
        handler.postDelayed(timeout!!, 600000)
        // Force Google account selection without authenticating a personal Google ID first.
        // Google controls whether this chooser also offers YouTube Brand identities.
        try {
            val builder = AuthorizationRequest.builder()
                .setRequestedScopes(scopes)
                .setOptOutIncludingGrantedScopes(true)
            if (selectAccount) builder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)
            client.authorize(builder.build())
                .addOnSuccessListener { authorization ->
                    if (generation != attempt || pending == null) return@addOnSuccessListener
                    if (authorization.hasResolution()) {
                        resolutionShown = true
                        try {
                            val intent = authorization.pendingIntent ?: error("Missing resolution")
                            @Suppress("DEPRECATION")
                            activity.startIntentSenderForResult(intent.intentSender, requestCode, null, 0, 0, 0)
                        } catch (_: Exception) {
                            fail("AUTH_NATIVE_RESOLUTION", "Google 권한 선택 화면을 열지 못했어요.")
                        }
                    } else complete(authorization)
                }
                .addOnFailureListener { exception ->
                    if (generation == attempt) failException(exception)
                }
        } catch (exception: Exception) { failException(exception) }
    }

    fun onActivityResult(code: Int, resultCode: Int, data: Intent?): Boolean {
        if (code !in 7300..8299) return false
        if (code != requestCode || pending == null) return true
        diagnostic["origin"] = "activity_result"
        diagnostic["callbackReceived"] = true
        diagnostic["activityResultCode"] = resultCode
        diagnostic["resultDataPresent"] = data != null
        // A canceled result can carry an ApiException. Parse it before classifying.
        // Never inspect/copy arbitrary Intent extras, URLs or exception messages.
        if (data != null) {
            try { complete(client.getAuthorizationResultFromIntent(data)) }
            catch (exception: Exception) { failException(exception) }
        } else {
            fail("AUTH_NATIVE_NO_RESULT", "Google 화면이 인증 결과 없이 종료됐어요.")
        }
        return true
    }

    private fun complete(authorization: AuthorizationResult) {
        val token = authorization.accessToken
        val granted = authorization.grantedScopes
        if (token.isNullOrBlank() || !granted.containsAll(scopes.map { it.scopeUri })) {
            fail("AUTH_NATIVE_SCOPE", "이번 테스트에서 요청한 YouTube 권한을 허용해 주세요.")
            return
        }
        val result = takeResult() ?: return
        // Token crosses only the private method channel, never preferences, logs or UI.
        result.success(diagnostic + mapOf("accessToken" to token, "resolutionShown" to resolutionShown,
            "scopes" to granted.filter { it in scopes.map { scope -> scope.scopeUri } }))
    }

    private fun failException(exception: Exception) {
        val code = (exception as? ApiException)?.statusCode
        if (code != null) diagnostic["googleStatusCode"] = code
        fail("AUTH_NATIVE_${code ?: "UNKNOWN"}", when (code) {
            10 -> "Android OAuth의 패키지 이름·설치 APK 서명 SHA-1을 확인해 주세요."
            16 -> "Google 권한 절차가 완료되지 않았어요. 직접 취소했는지는 알 수 없어요."
            7 -> "Google 인증 네트워크 연결을 확인해 주세요."
            else -> "Google 권한 요청에 실패했어요. Google Play 서비스와 OAuth 설정을 확인해 주세요."
        })
    }

    private fun takeResult(): MethodChannel.Result? {
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
        return pending.also { pending = null }
    }

    private fun fail(code: String, message: String) {
        val result = takeResult() ?: return
        result.error(code, message, diagnostic + mapOf("resolutionShown" to resolutionShown))
    }

    fun cancel(origin: String = "app_cancel") {
        generation++
        diagnostic["origin"] = origin
        fail("AUTH_NATIVE_APP_CANCELLED", "앱에서 권한 테스트를 중단했어요.")
    }
}
