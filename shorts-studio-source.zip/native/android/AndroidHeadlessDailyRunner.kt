package com.local.shorts_studio

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.util.UnstableApi
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A full separate Flutter AOT entry point. Unlike MainActivity.dailyRunChannel
 * it works when the Activity/previous Flutter engine no longer exists.
 *
 * Worker owns lifetime; progress and a single final completion are reported
 * to WorkManager through MethodChannel without starting an Activity.
 */
@UnstableApi
object AndroidHeadlessDailyRunner {
    data class Outcome(val success:Boolean,val skipped:Boolean,val message:String)
    suspend fun execute(
        context:Context,
        allowedCreators:List<String>,
        queueMode:Boolean,
        onProgress:(String)->Unit
    ):Outcome {
        require(allowedCreators.isNotEmpty())
        val completed=CompletableDeferred<Outcome>()
        var engine:FlutterEngine?=null
        var media:HeadlessDailyMedia?=null
        val flutterLoader=FlutterInjector.instance().flutterLoader()
        try{
            withContext(Dispatchers.Main) {
                flutterLoader.startInitialization(context)
                flutterLoader.ensureInitializationComplete(context,null)
                val newEngine=FlutterEngine(context)
                engine=newEngine
                media=HeadlessDailyMedia(context,newEngine)
                val callback=MethodChannel(newEngine.dartExecutor.binaryMessenger,
                    "studio.local/daily_runner")
                callback.setMethodCallHandler{call,result->
                    when(call.method){
                        "settings" -> result.success(mapOf(
                            "creators" to allowedCreators,
                            "queueMode" to queueMode
                        ))
                        "progress" -> {
                            onProgress(call.argument<String>("stage")?.take(140)
                                ?:"진행 중")
                            result.success(null)
                        }
                        "finished" -> {
                            val ok=call.argument<Boolean>("success")==true
                            val msg=call.argument<String>("message")?.take(200)
                                ?:if(ok)"업로드 성공"else"영상 제작 실패"
                            val skipped=call.argument<Boolean>("skipped")==true
                            onProgress(msg)
                            if(!completed.isCompleted)completed.complete(Outcome(ok,skipped,msg))
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                }
                newEngine.dartExecutor.executeDartEntrypoint(
                    DartExecutor.DartEntrypoint(
                        flutterLoader.findAppBundlePath(),
                        "dailyHeadlessMain"
                    )
                )
            }
            // Long-running media-processing foreground work is bounded.
            return withTimeoutOrNull(42*60*1000L){
                completed.await()
            } ?: Outcome(false,false,"실패: 작업 제한 시간 초과 · 다음 확인 때 재검사")
        }catch(_:Exception){
            return Outcome(false,false,"실패: Android 백그라운드 실행 오류")
        }finally{
            withContext(NonCancellable+Dispatchers.Main){
                try{media?.close()}catch(_:Exception){}
                try{engine?.destroy()}catch(_:Exception){}
            }
        }
    }
}
