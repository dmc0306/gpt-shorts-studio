package com.local.shorts_studio

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.WindowManager
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

@UnstableApi
class MainActivity : FlutterActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("studio", MODE_PRIVATE) }
    private var pickerResult: MethodChannel.Result? = null
    private var transformer: Transformer? = null
    private var exportResult: MethodChannel.Result? = null
    private var output: File? = null
    private var publishing = false
    private var overlay: Bitmap? = null
    private val inboxLock = Any()
    private val inboxFile by lazy { File(filesDir, "inbox.json") }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); if(savedInstanceState==null) acceptShare(intent) }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); acceptShare(intent) }
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger,"studio.local/media").setMethodCallHandler { call, result ->
            try { handle(call,result) } catch(e: Exception) { result.error("STUDIO", e.message, null) }
        }
    }
    private fun async(result: MethodChannel.Result, block: () -> Any?) { worker.execute { try { val value=block(); ui.post { result.success(value) } } catch(e:Exception) { ui.post { result.error("STUDIO", e.message, null) } } } }
    private fun handle(call: MethodCall, r: MethodChannel.Result) {
        when(call.method) {
            "loadProjects" -> async(r) { val file=File(filesDir,"projects.json");if(file.exists())file.readText() else "[]" }
            "saveProjects" -> async(r) { val json=call.argument<String>("json")!!;JSONArray(json);atomicWrite(File(filesDir,"projects.json"),json);null }
            "drainInbox" -> async(r) { synchronized(inboxLock){ (0 until inbox().length()).map { jsonMap(inbox().getJSONObject(it)) } } }
            "ackInbox" -> async(r) { val ids=call.argument<List<String>>("ids")!!.toSet();synchronized(inboxLock){val old=inbox();val keep=JSONArray();for(i in 0 until old.length())if(old.getJSONObject(i).getString("id") !in ids)keep.put(old.getJSONObject(i));atomicWrite(inboxFile,keep.toString())};null }
            "pickVideo" -> {check(pickerResult==null){"이미 파일 선택 중이에요."};pickerResult=r;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},10)}
            "chooseFolder" -> {check(pickerResult==null);pickerResult=r;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),11)}
            "watchEnabled" -> r.success(prefs.contains("folder"))
            "stopWatching" -> {prefs.edit().remove("folder").apply();r.success(null)}
            "scanFolder" -> async(r) {scanFolder();null}
            "addLink" -> async(r) {addLink(call.argument<String>("url")!!);null}
            "importDemo" -> async(r) {val target=File(filesDir,"sources/demo.mp4");target.parentFile!!.mkdirs();if(!target.exists())assets.open("flutter_assets/assets/demo.mp4").use{input->target.outputStream().use{input.copyTo(it)}};enqueue(inspect(target,"Motion study · 샘플","demo"));null}
            "export" -> startExport(call,r)
            "exportProgress" -> {val holder=ProgressHolder();val state=transformer?.getProgress(holder);r.success(if(state==Transformer.PROGRESS_STATE_AVAILABLE)holder.progress else -1)}
            "cancelExport" -> {if(publishing){r.error("SAVING","갤러리에 저장하는 중이에요.",null)}else{transformer?.cancel();finishExport("CANCELLED","저장을 취소했어요.");r.success(null)}}
            else -> r.notImplemented()
        }
    }
    private fun atomicWrite(file: File,text:String){val temp=File(file.parentFile,file.name+".tmp");temp.writeText(text);check(temp.renameTo(file)){"프로젝트 저장에 실패했어요."}}
    private fun inbox():JSONArray = if(inboxFile.exists())JSONArray(inboxFile.readText()) else JSONArray()
    private fun enqueue(item:Map<String,Any>){synchronized(inboxLock){val arr=inbox();arr.put(JSONObject(item));atomicWrite(inboxFile,arr.toString())}}
    private fun jsonMap(o:JSONObject):Map<String,Any?> = o.keys().asSequence().associateWith { key -> val v=o.get(key);if(v==JSONObject.NULL)null else v }
    private fun validTikTok(value:String):Boolean{val u=Uri.parse(value);val host=u.host?.lowercase()?:return false;return u.scheme=="https"&&(host=="tiktok.com"||host.endsWith(".tiktok.com"))&&u.userInfo==null&&(u.port==-1||u.port==443)}
    private fun addLink(raw:String){
        val link=Regex("https://[^\\s<>]+").findAll(raw).map{it.value.trimEnd(')',',','.','!')}.firstOrNull{validTikTok(it)}?:throw IllegalArgumentException("TikTok HTTPS 링크가 필요해요.")
        val item=mutableMapOf<String,Any>("id" to UUID.randomUUID().toString(),"name" to "TikTok 영상","url" to link,"creator" to "TikTok · 원본 파일 연결 필요")
        // oEmbed supplies metadata only. It is never treated as a download API.
        try {
            val connection=URL("https://www.tiktok.com/oembed?url="+java.net.URLEncoder.encode(link,"UTF-8")).openConnection() as HttpURLConnection
            connection.connectTimeout=7000;connection.readTimeout=7000;connection.instanceFollowRedirects=false
            try{if(connection.responseCode==200){val data=JSONObject(connection.inputStream.bufferedReader().use{it.readText()});item["name"]=data.optString("title","TikTok 영상").take(150);item["creator"]=data.optString("author_name","TikTok")}}finally{connection.disconnect()}
        }catch(_:Exception){/* The link remains useful offline. */}
        enqueue(item)
    }
    private fun acceptShare(intent:Intent?){
        if(intent?.action!=Intent.ACTION_SEND)return
        if(intent.type=="text/plain"){val text=intent.getStringExtra(Intent.EXTRA_TEXT)?:return;worker.execute{try{addLink(text)}catch(_:Exception){}}}
        else if(intent.type?.startsWith("video/")==true){@Suppress("DEPRECATION") val uri=intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?:return;worker.execute{try{enqueue(importUri(uri))}catch(_:Exception){}}}
    }
    @Deprecated("Android activity result compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=10&&requestCode!=11)return
        val r=pickerResult?:return;pickerResult=null
        val uri=data?.data
        if(resultCode!=Activity.RESULT_OK||uri==null){r.success(null);return}
        if(requestCode==10)async(r){importUri(uri)}
        else try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs.edit().putString("folder",uri.toString()).apply();async(r){scanFolder();true}}catch(e:Exception){r.error("FOLDER",e.message,null)}
    }
    private fun importUri(uri:Uri):Map<String,Any>{
        val document=DocumentFile.fromSingleUri(this,uri)
        val name=document?.name?:"새 영상"
        val id=UUID.randomUUID().toString();val file=File(filesDir,"sources/$id.mp4");file.parentFile!!.mkdirs()
        try{
            contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{out->val buffer=ByteArray(65536);var total=0L;while(true){val n=input.read(buffer);if(n<0)break;total+=n;check(filesDir.usableSpace>32L*1024*1024){"저장 공간이 부족해요."};check(total<=512L*1024*1024){"512MB 이하 영상을 사용해 주세요."};out.write(buffer,0,n)}}}?:error("파일을 열 수 없어요.")
            return inspect(file,name,id)
        }catch(e:Exception){file.delete();throw e}
    }
    private fun inspect(file:File,name:String,id:String):Map<String,Any>{
        val media=MediaMetadataRetriever()
        try{media.setDataSource(file.absolutePath);val duration=(media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDouble()?:0.0)/1000;require(duration>=.2&&duration<=120){"0.2초~120초 영상을 사용해 주세요."}
            val thumbnail=File(filesDir,"thumbnails/$id.jpg");thumbnail.parentFile!!.mkdirs()
            val bitmap=media.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,360,640)
            bitmap?.let{thumbnail.outputStream().use{out->it.compress(Bitmap.CompressFormat.JPEG,85,out)};it.recycle()}
            return mapOf("id" to id,"name" to name,"path" to file.absolutePath,"thumbnail" to (if(thumbnail.exists())thumbnail.absolutePath else ""),"duration" to duration)
        }finally{media.release()}
    }
    private fun scanFolder(){
        val tree=prefs.getString("folder",null)?:return
        val root=DocumentFile.fromTreeUri(this,Uri.parse(tree))?:error("폴더를 다시 선택해 주세요.")
        check(root.canRead()){ "폴더 접근 권한이 사라졌어요. 다시 선택해 주세요." }
        val seen=(prefs.getStringSet("seen",emptySet())?:emptySet()).toMutableSet()
        // Bounded foreground scan. Only settled files, no recursion and no exported gallery folder loop.
        var imported = 0
        for(file in root.listFiles().filter{it.isFile&&(it.type?.startsWith("video/")==true||it.name?.endsWith(".mp4",true)==true)}.take(500)){
            if(imported>=10)break
            if(file.name?.startsWith("ShortsStudio_")==true)continue
            if(file.length()==0L||System.currentTimeMillis()-file.lastModified()<5000)continue
            val key="${file.uri}:${file.length()}:${file.lastModified()}"
            if(key in seen)continue
            try{enqueue(importUri(file.uri));imported++;seen.add(key);prefs.edit().putStringSet("seen",seen.toSet()).commit()}catch(_:Exception){/* Retry unavailable or still-writing files on a later scan. */}
        }
    }
    private fun startExport(call:MethodCall,r:MethodChannel.Result){
        check(exportResult==null){"이전 영상 저장이 진행 중이에요."}
        val source=File(call.argument<String>("path")!!)
        require(source.canonicalPath.startsWith(File(filesDir,"sources").canonicalPath+File.separator)&&source.exists())
        val start=call.argument<Number>("startMs")!!.toLong();val end=call.argument<Number>("endMs")!!.toLong();require(start>=0&&end>start)
        val bytes=call.argument<ByteArray>("overlay")!!;val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)?:error("자막 이미지 오류")
        overlay=bitmap;output=File(cacheDir,"export_${UUID.randomUUID()}.mp4");exportResult=r
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try{
            val media=MediaItem.Builder().setUri(Uri.fromFile(source)).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(end).build()).build()
            val fit=if(call.argument<Boolean>("crop")==true)Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
            val effects=Effects(emptyList(),listOf(Presentation.createForWidthAndHeight(1080,1920,fit),OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(bitmap)))))
            val item=EditedMediaItem.Builder(media).setRemoveAudio(call.argument<Boolean>("mute")==true).setEffects(effects).build()
            transformer=Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).addListener(object:Transformer.Listener{
                override fun onCompleted(composition:Composition,result:ExportResult){
                    publishing=true;val completed=output!!
                    worker.execute{try{val uri=publish(completed);ui.post{val pending=exportResult;cleanupExport();pending?.success(uri)}}catch(e:Exception){ui.post{finishExport("SAVE",e.message?:"갤러리 저장 실패")}}}
                }
                override fun onError(composition:Composition,result:ExportResult,exception:ExportException){finishExport("EXPORT",exception.message?:"영상 변환 실패")}
            }).build()
            transformer!!.start(item,output!!.absolutePath)
        }catch(e:Exception){finishExport("EXPORT",e.message?:"영상 변환 실패")}
    }
    private fun publish(file:File):String{
        val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,"ShortsStudio_${System.currentTimeMillis()}.mp4");put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/ShortsStudio");put(MediaStore.Video.Media.IS_PENDING,1)}
        val uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)?:error("갤러리 저장 위치 생성 실패")
        try{contentResolver.openOutputStream(uri)?.use{out->file.inputStream().use{it.copyTo(out)}}?:error("저장 파일을 열 수 없어요.");check(contentResolver.update(uri,ContentValues().apply{put(MediaStore.Video.Media.IS_PENDING,0)},null,null)>0);return uri.toString()}
        catch(e:Exception){contentResolver.delete(uri,null,null);throw e}
    }
    private fun finishExport(code:String,message:String){val pending=exportResult;cleanupExport();pending?.error(code,message,null)}
    private fun cleanupExport(){transformer=null;exportResult=null;publishing=false;output?.delete();output=null;overlay?.recycle();overlay=null;window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}
    override fun onDestroy(){if(!publishing){transformer?.cancel();if(exportResult!=null)finishExport("INTERRUPTED","앱이 종료되어 저장이 중단됐어요.")};worker.shutdown();super.onDestroy()}
}
