package com.local.shorts_studio

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextureOverlay
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.WindowManager
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

@UnstableApi
class MainActivity : FlutterActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("studio", MODE_PRIVATE) }
    private val youtubeProbe by lazy { YouTubeAuthorizationProbe(this) }
    private val youtubeChromeDelegate = lazy { YouTubeChromeAuth(this,
        { readAiKey("youtubeChrome") },
        { value -> saveAiKey(value,"youtubeChrome");check(prefs.edit().commit()) }) }
    private val youtubeChrome get() = youtubeChromeDelegate.value
    private var pickerResult: MethodChannel.Result? = null
    private var transformer: Transformer? = null
    private var exportResult: MethodChannel.Result? = null
    private var output: File? = null
    private var publishing = false
    private var batchAwake = false
    private var notificationResult: MethodChannel.Result? = null
    private var overlay: Bitmap? = null
    private val captionBitmaps = mutableListOf<Bitmap>()
    private val inboxLock = Any()
    private val inboxFile by lazy { File(filesDir, "inbox.json") }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); if(savedInstanceState==null) acceptShare(intent) }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); acceptShare(intent) }
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        BatchService.onStop={MethodChannel(engine.dartExecutor.binaryMessenger,"studio.local/batch").invokeMethod("stop",null)}
        MethodChannel(engine.dartExecutor.binaryMessenger,"studio.local/media").setMethodCallHandler { call, result ->
            try { handle(call,result) } catch(e: Exception) { result.error("STUDIO", e.message, null) }
        }
    }
    private fun async(result: MethodChannel.Result, block: () -> Any?) { worker.execute { try { val value=block(); ui.post { result.success(value) } } catch(e:Exception) { ui.post { result.error("STUDIO", e.message, null) } } } }
    private fun handle(call: MethodCall, r: MethodChannel.Result) {
        when(call.method) {
            "loadAiSettings" -> async(r) {mapOf("key" to readAiKey(),"model" to prefs.getString("aiModel","gemini-3.5-flash-lite"),"searchKey" to readAiKey("search"))}
            "saveAiSettings" -> async(r) {saveAiKey(call.argument<String>("key")?:"");if(call.hasArgument("searchKey"))saveAiKey(call.argument<String>("searchKey")?:"","search");prefs.edit().putString("aiModel",call.argument<String>("model")).apply();null}
            "batchNotifications" -> {
                if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
                    check(notificationResult==null);notificationResult=r;requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),42)
                }else r.success(true)
            }
            "batchStart" -> {BatchService.stopRequested=false;startForegroundService(Intent(this,BatchService::class.java));batchAwake=true;r.success(null)}
            "batchStatus" -> {if(batchAwake)BatchService.update(call.argument<String>("status")?:"진행 중",call.argument<Number>("saved")?.toInt()?:0);r.success(null)}
            "batchShouldStop" -> r.success(BatchService.stopRequested)
            "batchFinish" -> {val wasRunning=batchAwake;batchAwake=false;stopService(Intent(this,BatchService::class.java));window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(wasRunning)BatchService.complete(this,call.argument<String>("status")?:"작업 종료",call.argument<Number>("saved")?.toInt()?:0);r.success(null)}
            "loadBatchReport" -> async(r) {val file=File(filesDir,"batch-report.json");if(file.exists())file.readText() else "{}"}
            "saveBatchReport" -> async(r) {val json=call.argument<String>("json")!!;JSONObject(json);atomicWrite(File(filesDir,"batch-report.json"),json);null}
            "deleteSavedVideo" -> async(r) {
                val uri=Uri.parse(call.argument<String>("uri")!!)
                require(uri.scheme=="content"&&uri.authority=="media"){"앱 저장 영상 주소가 아니에요."}
                contentResolver.query(uri,arrayOf(MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.RELATIVE_PATH),null,null,null)?.use { cursor ->
                    if(cursor.moveToFirst()){
                        require(cursor.getString(0).startsWith("ShortsStudio_")&&cursor.getString(1).trimEnd('/')=="Movies/ShortsStudio"){"앱에서 저장한 영상만 삭제할 수 있어요."}
                        check(contentResolver.delete(uri,null,null)>0){"저장 영상을 삭제하지 못했어요."}
                    }
                };null
            }
            "deleteLocalVideo" -> async(r) {
                for(path in call.argument<List<String>>("paths")?:emptyList()){
                    if(path.isBlank())continue
                    val file=File(path);val canonical=file.canonicalPath
                    require(listOf("sources","thumbnails").any { canonical.startsWith(File(filesDir,it).canonicalPath+File.separator) })
                    check(!file.exists()||file.delete()){"원본 파일을 삭제하지 못했어요."}
                };null
            }
            "loadProjects" -> async(r) { val file=File(filesDir,"projects.json");if(file.exists())file.readText() else "[]" }
            "saveProjects" -> async(r) { val json=call.argument<String>("json")!!;JSONArray(json);atomicWrite(File(filesDir,"projects.json"),json);null }
            "drainInbox" -> async(r) { synchronized(inboxLock){ (0 until inbox().length()).map { jsonMap(inbox().getJSONObject(it)) } } }
            "ackInbox" -> async(r) { val ids=call.argument<List<String>>("ids")!!.toSet();synchronized(inboxLock){val old=inbox();val keep=JSONArray();for(i in 0 until old.length())if(old.getJSONObject(i).getString("id") !in ids)keep.put(old.getJSONObject(i));atomicWrite(inboxFile,keep.toString())};null }
            "pickVideo" -> {check(pickerResult==null){"이미 파일 선택 중이에요."};pickerResult=r;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},10)}
            "chooseFolder" -> {check(pickerResult==null);pickerResult=r;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),11)}
            "watchEnabled" -> r.success(prefs.contains("folder"))
            "stopWatching" -> {prefs.edit().remove("folder").apply();r.success(null)}
            "scanFolder" -> async(r) {scanFolder();null}
            "addLink" -> async(r) {addLink(call.argument<String>("url")!!);null}
            "downloadPath" -> async(r) {check(filesDir.usableSpace>64L*1024*1024){"저장 공간이 부족해요."};val file=File(filesDir,"sources/${UUID.randomUUID()}.part");file.parentFile!!.mkdirs();file.absolutePath}
            "cancelTextScan" -> {OriginalTextScanner.cancelled=true;r.success(null)}
            "scanOriginalText" -> async(r) {
                val source=File(call.argument<String>("path")!!)
                require(source.canonicalPath.startsWith(File(filesDir,"sources").canonicalPath+File.separator)&&source.exists())
                OriginalTextScanner.scan(source,call.argument<Number>("startMs")?.toDouble()?.div(1000.0)?:0.0,call.argument<Number>("endMs")?.toDouble()?.div(1000.0),call.argument<Boolean>("crop")==true)
            }
            "inspectDownload" -> async(r) {
                val part=File(call.argument<String>("path")!!)
                require(part.canonicalPath.startsWith(File(filesDir,"sources").canonicalPath+File.separator)&&part.name.endsWith(".part")&&part.exists())
                val id=part.name.removeSuffix(".part");val file=File(part.parentFile,"$id.mp4")
                check(part.renameTo(file)){"영상 파일 저장에 실패했어요."}
                try{inspect(file,call.argument<String>("name")?:"TikTok 영상",id)}catch(e:Exception){file.delete();throw e}
            }
            "importDemo" -> async(r) {val target=File(filesDir,"sources/demo.mp4");target.parentFile!!.mkdirs();if(!target.exists())assets.open("flutter_assets/assets/demo.mp4").use{input->target.outputStream().use{input.copyTo(it)}};enqueue(inspect(target,"Motion study · 샘플","demo"));null}
            "export" -> startExport(call,r)
            "youtubeAutomatic" -> r.success(prefs.getBoolean("youtubeAutomatic",false))
            "youtubeKeepAwake" -> {if(call.argument<Boolean>("enabled")==true)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else if(!batchAwake)window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);r.success(null)}
            "setYoutubeAutomatic" -> {check(prefs.edit().putBoolean("youtubeAutomatic",call.argument<Boolean>("enabled")==true).commit());r.success(null)}
            "youtubeUploadState" -> r.success(prefs.getString("youtubeUpload:${call.argument<String>("uri")!!}",null))
            "saveYoutubeUploadState" -> {val json=call.argument<String>("json")!!;JSONObject(json);check(prefs.edit().putString("youtubeUpload:${call.argument<String>("uri")!!}",json).commit());r.success(null)}
            "prepareYoutubeVideo" -> async(r) {
                val uri=Uri.parse(call.argument<String>("uri")!!)
                require(uri.scheme=="content"&&uri.authority=="media"){"갤러리에 저장한 영상을 사용해 주세요."}
                val file=File(cacheDir,"youtube_${UUID.randomUUID()}.mp4")
                try{contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{out->val buffer=ByteArray(65536);while(true){val n=input.read(buffer);if(n<0)break;check(cacheDir.usableSpace>32L*1024*1024){"업로드 준비 공간이 부족해요."};out.write(buffer,0,n)}}}?:error("저장한 영상을 찾을 수 없어요.");file.absolutePath}
                catch(e:Exception){file.delete();throw e}
            }
            "cleanupYoutubeVideo" -> async(r) {val file=File(call.argument<String>("path")!!);require(file.canonicalFile.parentFile==cacheDir.canonicalFile&&file.name.startsWith("youtube_"));file.delete();null}
            "youtubeChromeConnect" -> youtubeChrome.connect(r, call.argument<Boolean>("customTab")==true)
            "youtubeChromeToken" -> youtubeChrome.token(r,call.argument<Boolean>("forceRefresh")==true)
            "youtubeChromeStatus" -> youtubeChrome.status(r)
            "youtubeChromeDisconnect" -> youtubeChrome.disconnect(r)
            "youtubeChromeCancel" -> {youtubeChrome.cancel();r.success(null)}
            "youtubeAuthorizationProbe" -> youtubeProbe.start(r,call.argument<Boolean>("includeUpload")==true,call.argument<Boolean>("selectAccount")!=false)
            "cancelYoutubeAuthorizationProbe" -> {youtubeProbe.cancel();r.success(null)}
            "youtubeSettings" -> r.success(prefs.getString("youtubeSettings",null))
            "youtubeServerConfig" -> async(r) { readAiKey("youtubeServer") }
            "saveYoutubeServerConfig" -> async(r) {
                val json=call.argument<String>("json")!!
                val config=JSONObject(json)
                val uri=Uri.parse(config.getString("url"))
                require(uri.scheme=="https"&&!uri.host.isNullOrEmpty()&&uri.userInfo==null&&uri.query==null&&uri.fragment==null&&(uri.port==-1||uri.port==443))
                require(uri.path.isNullOrEmpty()||uri.path=="/")
                require(Regex("^[A-Za-z0-9_-]{43}$").matches(config.getString("key")))
                saveAiKey(json,"youtubeServer")
                null
            }
            "youtubePcKey" -> async(r) {
                val incoming=File(filesDir,"youtube-pc-pairing.json")
                if(incoming.exists()){
                    require(incoming.length()<=1024)
                    val key=JSONObject(incoming.readText()).getString("key")
                    require(Regex("^[A-Za-z0-9_-]{43}$").matches(key))
                    saveAiKey(key,"youtubePc")
                    check(prefs.edit().commit())
                    check(incoming.delete())
                }
                readAiKey("youtubePc")
            }
            "openYoutubeBrowser" -> {
                val uri=Uri.parse(call.argument<String>("url")!!)
                require(uri.scheme=="https"&&uri.host=="accounts.google.com"&&uri.path=="/o/oauth2/v2/auth"&&uri.userInfo==null&&(uri.port==-1||uri.port==443))
                val intent=Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE)
                try{startActivity(Intent(intent).setPackage("com.android.chrome"))}
                catch(_:android.content.ActivityNotFoundException){startActivity(intent)}
                r.success(null)
            }
            "saveYoutubeSettings" -> {val json=call.argument<String>("json")!!;JSONObject(json);check(prefs.edit().putString("youtubeSettings",json).commit());r.success(null)}
            "exportProgress" -> {val holder=ProgressHolder();val state=transformer?.getProgress(holder);r.success(if(state==Transformer.PROGRESS_STATE_AVAILABLE)holder.progress else -1)}
            "cancelExport" -> {if(publishing){r.error("SAVING","갤러리에 저장하는 중이에요.",null)}else{transformer?.cancel();finishExport("CANCELLED","저장을 취소했어요.");r.success(null)}}
            else -> r.notImplemented()
        }
    }
    private fun aiSecret():SecretKey {
        val store=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (store.getKey("studio-gemini",null) as? SecretKey)?.let{return it}
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("studio-gemini",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    private fun saveAiKey(key:String,prefix:String="ai"){
        if(key.isBlank()){prefs.edit().remove("${prefix}Key").remove("${prefix}Iv").apply();return}
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,aiSecret())
        prefs.edit().putString("${prefix}Key",Base64.encodeToString(cipher.doFinal(key.toByteArray(Charsets.UTF_8)),Base64.NO_WRAP)).putString("${prefix}Iv",Base64.encodeToString(cipher.iv,Base64.NO_WRAP)).apply()
    }
    private fun readAiKey(prefix:String="ai"):String {
        val value=prefs.getString("${prefix}Key",null)?:return ""
        return try{val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,aiSecret(),GCMParameterSpec(128,Base64.decode(prefs.getString("${prefix}Iv",""),Base64.NO_WRAP)));String(cipher.doFinal(Base64.decode(value,Base64.NO_WRAP)),Charsets.UTF_8)}catch(_:Exception){""}
    }
    private fun atomicWrite(file: File,text:String){val temp=File(file.parentFile,file.name+".tmp");temp.writeText(text);check(temp.renameTo(file)){"프로젝트 저장에 실패했어요."}}
    private fun inbox():JSONArray = if(inboxFile.exists())JSONArray(inboxFile.readText()) else JSONArray()
    private fun enqueue(item:Map<String,Any>){synchronized(inboxLock){val arr=inbox();arr.put(JSONObject(item));atomicWrite(inboxFile,arr.toString())}}
    private fun jsonMap(o:JSONObject):Map<String,Any?> = o.keys().asSequence().associateWith { key -> val v=o.get(key);if(v==JSONObject.NULL)null else v }
    private fun validTikTok(value:String):Boolean{val u=Uri.parse(value);val host=u.host?.lowercase()?:return false;return u.scheme=="https"&&(host=="tiktok.com"||host.endsWith(".tiktok.com"))&&u.userInfo==null&&(u.port==-1||u.port==443)}
    private fun addLink(raw:String){
        val link=Regex("https://[^\\s<>]+").findAll(raw).map{it.value.trimEnd(')',',','.','!')}.firstOrNull{validTikTok(it)}?:throw IllegalArgumentException("TikTok HTTPS 링크가 필요해요.")
        val item=mutableMapOf<String,Any>("id" to UUID.randomUUID().toString(),"name" to "TikTok 영상","url" to link,"creator" to "TikTok · 원본 파일 연결 필요")
        // oEmbed supplies metadata only. It is never treated as a download API.
        try {
            val connection=URL("https://www.tiktok.com/oembed?url="+java.net.URLEncoder.encode(link,"UTF-8")).openConnection() as HttpURLConnection
            connection.connectTimeout=7000;connection.readTimeout=7000;connection.instanceFollowRedirects=false
            try{if(connection.responseCode==200){val data=JSONObject(connection.inputStream.bufferedReader().use{it.readText()});item["name"]=data.optString("title","TikTok 영상").take(150);item["creator"]=data.optString("author_name","TikTok")}}finally{connection.disconnect()}
        }catch(_:Exception){/* The link remains useful offline. */}
        enqueue(item)
    }
    private fun acceptShare(intent:Intent?){
        if(intent?.action!=Intent.ACTION_SEND)return
        if(intent.type=="text/plain"){val text=intent.getStringExtra(Intent.EXTRA_TEXT)?:return;worker.execute{try{addLink(text)}catch(_:Exception){}}}
        else if(intent.type?.startsWith("video/")==true){@Suppress("DEPRECATION") val uri=intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?:return;worker.execute{try{enqueue(importUri(uri))}catch(_:Exception){}}}
    }
    @Deprecated("Android activity result compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode in 8400..9399&&youtubeChrome.onActivityResult(requestCode,resultCode,data))return
        if(youtubeProbe.onActivityResult(requestCode,resultCode,data))return
        if(requestCode!=10&&requestCode!=11)return
        val r=pickerResult?:return;pickerResult=null
        val uri=data?.data
        if(resultCode!=Activity.RESULT_OK||uri==null){r.success(null);return}
        if(requestCode==10)async(r){importUri(uri)}
        else try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs.edit().putString("folder",uri.toString()).apply();async(r){scanFolder();true}}catch(e:Exception){r.error("FOLDER",e.message,null)}
    }
    private fun importUri(uri:Uri):Map<String,Any>{
        val document=DocumentFile.fromSingleUri(this,uri)
        val name=document?.name?:"새 영상"
        val id=UUID.randomUUID().toString();val file=File(filesDir,"sources/$id.mp4");file.parentFile!!.mkdirs()
        try{
            contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{out->val buffer=ByteArray(65536);var total=0L;while(true){val n=input.read(buffer);if(n<0)break;total+=n;check(filesDir.usableSpace>32L*1024*1024){"저장 공간이 부족해요."};check(total<=512L*1024*1024){"512MB 이하 영상을 사용해 주세요."};out.write(buffer,0,n)}}}?:error("파일을 열 수 없어요.")
            return inspect(file,name,id)
        }catch(e:Exception){file.delete();throw e}
    }
    private fun inspect(file:File,name:String,id:String):Map<String,Any>{
        val media=MediaMetadataRetriever()
        try{media.setDataSource(file.absolutePath);val duration=(media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDouble()?:0.0)/1000;require(duration>=.2&&duration<=120){"0.2초~120초 영상을 사용해 주세요."}
            val thumbnail=File(filesDir,"thumbnails/$id.jpg");thumbnail.parentFile!!.mkdirs()
            val bitmap=media.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,360,640)
            bitmap?.let{thumbnail.outputStream().use{out->it.compress(Bitmap.CompressFormat.JPEG,85,out)};it.recycle()}
            return mapOf("videoWidth" to (media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toDouble()?:0.0),"videoHeight" to (media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toDouble()?:0.0),"id" to id,"name" to name,"path" to file.absolutePath,"thumbnail" to (if(thumbnail.exists())thumbnail.absolutePath else ""),"duration" to duration)
        }finally{media.release()}
    }
    private fun scanFolder(){
        val tree=prefs.getString("folder",null)?:return
        val root=DocumentFile.fromTreeUri(this,Uri.parse(tree))?:error("폴더를 다시 선택해 주세요.")
        check(root.canRead()){ "폴더 접근 권한이 사라졌어요. 다시 선택해 주세요." }
        val seen=(prefs.getStringSet("seen",emptySet())?:emptySet()).toMutableSet()
        // Bounded foreground scan. Only settled files, no recursion and no exported gallery folder loop.
        var imported = 0
        for(file in root.listFiles().filter{it.isFile&&(it.type?.startsWith("video/")==true||it.name?.endsWith(".mp4",true)==true)}.take(500)){
            if(imported>=10)break
            if(file.name?.startsWith("ShortsStudio_")==true)continue
            if(file.length()==0L||System.currentTimeMillis()-file.lastModified()<5000)continue
            val key="${file.uri}:${file.length()}:${file.lastModified()}"
            if(key in seen)continue
            try{enqueue(importUri(file.uri));imported++;seen.add(key);prefs.edit().putStringSet("seen",seen.toSet()).commit()}catch(_:Exception){/* Retry unavailable or still-writing files on a later scan. */}
        }
    }
    private data class TimedLayer(val start:Long,val end:Long,val image:Bitmap,val settings:StaticOverlaySettings)
    private fun startExport(call:MethodCall,r:MethodChannel.Result){
        check(exportResult==null){"이전 영상 저장이 진행 중이에요."}
        val source=File(call.argument<String>("path")!!)
        require(source.canonicalPath.startsWith(File(filesDir,"sources").canonicalPath+File.separator)&&source.exists())
        val start=call.argument<Number>("startMs")!!.toLong();val end=call.argument<Number>("endMs")!!.toLong();require(start>=0&&end>start)
        val bytes=call.argument<ByteArray>("overlay")!!;val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)?:error("자막 이미지 오류")
        overlay=bitmap;output=File(cacheDir,"export_${UUID.randomUUID()}.mp4");exportResult=r
        if(!batchAwake)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try{
            val media=MediaItem.Builder().setUri(Uri.fromFile(source)).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(end).build()).build()
            val fit=if(call.argument<Boolean>("crop")==true)Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
            val layers=mutableListOf<TextureOverlay>(BitmapOverlay.createStaticBitmapOverlay(bitmap))
            val entries=call.argument<List<Map<String,Any>>>("timedOverlays")?:emptyList()
            require(entries.size<=20)
            if(entries.isNotEmpty()){
                val blank=Bitmap.createBitmap(1080,200,Bitmap.Config.ARGB_8888);captionBitmaps.add(blank)
                val timed=entries.map { entry ->
                    val png=entry["png"] as ByteArray
                    val image=BitmapFactory.decodeByteArray(png,0,png.size)?:error("시간별 자막 이미지 오류")
                    captionBitmaps.add(image);require(image.width==1080&&image.height==200)
                    val top=(entry["topPx"] as? Number)?.toFloat()?:1200f
                    require(top.isFinite()&&top>=420f&&top<=1720f)
                    TimedLayer((entry["startUs"] as Number).toLong(),(entry["endUs"] as Number).toLong(),image,
                        StaticOverlaySettings.Builder().setBackgroundFrameAnchor(0f,1f-2f*(top+100f)/1920f).build())
                }
                val emptySettings=StaticOverlaySettings.Builder().build()
                layers.add(object:BitmapOverlay(){
                    override fun getBitmap(presentationTimeUs:Long):Bitmap = timed.firstOrNull{presentationTimeUs>=it.start&&presentationTimeUs<it.end}?.image?:blank
                    override fun getOverlaySettings(presentationTimeUs:Long)=timed.firstOrNull{presentationTimeUs>=it.start&&presentationTimeUs<it.end}?.settings?:emptySettings
                })
            }
            val effects=Effects(emptyList(),listOf(Presentation.createForWidthAndHeight(1080,1080,fit),Presentation.createForWidthAndHeight(1080,1920,Presentation.LAYOUT_SCALE_TO_FIT),OverlayEffect(layers)))
            val item=EditedMediaItem.Builder(media).setRemoveAudio(call.argument<Boolean>("mute")==true).setEffects(effects).build()
            transformer=Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).addListener(object:Transformer.Listener{
                override fun onCompleted(composition:Composition,result:ExportResult){
                    publishing=true;val completed=output!!
                    worker.execute{try{val uri=publish(completed);ui.post{val pending=exportResult;cleanupExport();pending?.success(uri)}}catch(e:Exception){ui.post{finishExport("SAVE",e.message?:"갤러리 저장 실패")}}}
                }
                override fun onError(composition:Composition,result:ExportResult,exception:ExportException){finishExport("EXPORT",exception.message?:"영상 변환 실패")}
            }).build()
            transformer!!.start(item,output!!.absolutePath)
        }catch(e:Exception){finishExport("EXPORT",e.message?:"영상 변환 실패")}
    }
    private fun publish(file:File):String{
        val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,"ShortsStudio_${System.currentTimeMillis()}.mp4");put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/ShortsStudio");put(MediaStore.Video.Media.IS_PENDING,1)}
        val uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)?:error("갤러리 저장 위치 생성 실패")
        try{contentResolver.openOutputStream(uri)?.use{out->file.inputStream().use{it.copyTo(out)}}?:error("저장 파일을 열 수 없어요.");check(contentResolver.update(uri,ContentValues().apply{put(MediaStore.Video.Media.IS_PENDING,0)},null,null)>0);return uri.toString()}
        catch(e:Exception){contentResolver.delete(uri,null,null);throw e}
    }
    private fun finishExport(code:String,message:String){val pending=exportResult;cleanupExport();pending?.error(code,message,null)}
    private fun cleanupExport(){transformer=null;exportResult=null;publishing=false;output?.delete();output=null;overlay?.recycle();overlay=null;captionBitmaps.forEach{it.recycle()};captionBitmaps.clear();if(!batchAwake)window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==42){notificationResult?.success(grantResults.firstOrNull()==android.content.pm.PackageManager.PERMISSION_GRANTED);notificationResult=null}
    }
    override fun onDestroy(){if(youtubeChromeDelegate.isInitialized())youtubeChrome.close();youtubeProbe.cancel("activity_destroy");BatchService.onStop=null;stopService(Intent(this,BatchService::class.java));if(!publishing){transformer?.cancel();if(exportResult!=null)finishExport("INTERRUPTED","앱이 종료되어 저장이 중단됐어요.")};worker.shutdown();super.onDestroy()}
}
