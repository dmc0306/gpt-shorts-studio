@echo off
setlocal
cd /d "%~dp0"
set "STUDIO_FLUTTER=C:\Users\Min\flutter\bin\flutter.bat"
set "STUDIO_DART=C:\Users\Min\flutter\bin\dart.bat"
if exist "%CD%\.build-tools\flutter\bin\flutter.bat" (
  set "STUDIO_FLUTTER=%CD%\.build-tools\flutter\bin\flutter.bat"
  set "STUDIO_DART=%CD%\.build-tools\flutter\bin\dart.bat"
  set "FLUTTER_ROOT=%CD%\.build-tools\flutter"
  set "PUB_CACHE=%CD%\.pub-cache"
  set "GRADLE_USER_HOME=%CD%\.build-tools\gradle-home"
  set "ANDROID_HOME=%CD%\.build-tools\android-sdk"
  set "ANDROID_SDK_ROOT=%CD%\.build-tools\android-sdk"
  set "ANDROID_USER_HOME=%CD%\.build-tools\android-user"
  set "TEMP=%CD%\.build-tools\tmp"
  set "TMP=%CD%\.build-tools\tmp"
)
set "FLUTTER_SUPPRESS_ANALYTICS=true"
set "CI=true"
if not exist "%STUDIO_FLUTTER%" (
  echo Flutter SDK not found at C:\Users\Min\flutter.
  echo Install Flutter or update STUDIO_FLUTTER and STUDIO_DART in this file.
  goto failed
)
if not exist build mkdir build
set "STUDIO_LOG=%CD%\build\youtube_build.log"
echo Shorts Studio YouTube build started %DATE% %TIME%> "%STUDIO_LOG%"
echo [1/5] Downloading dependencies...
call "%STUDIO_FLUTTER%" pub get >> "%STUDIO_LOG%" 2>&1
if errorlevel 1 goto failed
echo [2/5] Analyzing Dart code...
call "%STUDIO_FLUTTER%" analyze --no-fatal-infos --no-fatal-warnings >> "%STUDIO_LOG%" 2>&1
if errorlevel 1 goto failed
echo [3/5] Running application tests...
call "%STUDIO_FLUTTER%" test >> "%STUDIO_LOG%" 2>&1
if errorlevel 1 goto failed
echo [4/5] Checking YouTube upload protocol...
call "%STUDIO_DART%" run tool/verify_youtube_upload.dart >> "%STUDIO_LOG%" 2>&1
if errorlevel 1 goto failed
echo [5/5] Building Android APK...
call "%STUDIO_FLUTTER%" build apk --debug >> "%STUDIO_LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "build\app\outputs\flutter-apk\app-debug.apk" goto failed
echo.
echo SUCCESS: build\app\outputs\flutter-apk\app-debug.apk
echo Google login and a private test upload still need to be checked on your phone.
start "" explorer.exe "%CD%\build\app\outputs\flutter-apk"
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. No new APK has been verified.
if defined STUDIO_LOG (
  echo Log: %STUDIO_LOG%
  type "%STUDIO_LOG%"
)
pause
exit /b 1
