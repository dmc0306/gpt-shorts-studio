"""Offline structural checks only. Run flutter analyze and flutter test for real validation."""
from pathlib import Path
import ast,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
for file in (root/'lib').glob('*.dart'):
 s=file.read_text();stack=[];i=0
 while i<len(s):
  if s[i:i+2]=='//':
   p=s.find('\n',i);i=len(s) if p<0 else p;continue
  if s[i] in '\"\'':
   quote=s[i];i+=1
   while i<len(s):
    if s[i]=='\\':i+=2;continue
    if s[i]==quote:break
    i+=1
  elif s[i] in '([{':stack.append((s[i],i))
  elif s[i] in ')]}':
   assert stack and {'(':')','[':']','{':'}'}[stack[-1][0]]==s[i],(file,i,stack[-3:])
   stack.pop()
  i+=1
 assert not stack,(file,stack)
 print(file.name,': balanced delimiters')
ET.parse(root/'native/android/AndroidManifest.xml')
for p in (root/'tool').glob('*.py'):ast.parse(p.read_text())
print('Manifest XML and Python syntax: OK. Flutter/Kotlin compilation is not checked.')
