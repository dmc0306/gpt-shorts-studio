import contextlib
import copy
import http.client
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit
import youtube_pc as pc

CHANNEL = {'id': 'UC' + 'a' * 22, 'snippet': {'title': 'Test Brand'}}


class MemoryVault:
    def __init__(self):
        self.data = {'client': {'client_id': pc.CLIENT_ID, 'client_secret': 'test-secret'}}

    def read(self, key):
        return copy.deepcopy(self.data.get(key))

    def write(self, key, value):
        self.data[key] = copy.deepcopy(value)

    def remove(self, key):
        self.data.pop(key, None)

    def pair_key(self):
        return 'test-pairing-key'


class BrokerTests(unittest.TestCase):
    def setUp(self):
        self.vault = MemoryVault()
        self.now = 1000
        self.calls = []
        self.channel = CHANNEL
        self.scopes = ' '.join(pc.SCOPES)
        self.broker = pc.Broker(self.vault, self.fetch, lambda: self.now)

    def fetch(self, url, form=None, token=None):
        self.calls.append((url, form, token))
        if '/channels?' in url:
            return {'items': [self.channel], 'pageInfo': {'totalResults': 1}}
        return {'access_token': 'short-token', 'refresh_token': 'private-refresh',
                'expires_in': 3600, 'scope': self.scopes}

    def finish(self):
        login = self.broker.start()
        query = parse_qs(urlsplit(login['url']).query)
        self.broker.callback({'state': query['state'], 'code': ['one-use-code']})
        return login, query

    def test_pkce_state_scopes_and_one_time_callback(self):
        login, query = self.finish()
        self.assertEqual(query['code_challenge_method'], ['S256'])
        self.assertEqual(query['scope'], [' '.join(pc.SCOPES)])
        self.assertNotIn('openid', query['scope'][0])
        verifier = self.calls[0][1]['code_verifier']
        challenge = pc.base64.urlsafe_b64encode(pc.hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
        self.assertEqual(query['code_challenge'], [challenge])
        self.assertEqual(self.broker.status(login['flow']), {'status': 'complete'})
        with self.assertRaises(pc.SafeError):
            self.broker.callback({'state': query['state'], 'code': ['replay']})
        token = self.broker.token()
        self.assertNotIn('refresh_token', token)
        self.assertNotIn('client_secret', json.dumps(token))
        self.assertEqual(token['channel']['id'], CHANNEL['id'])

    def test_expired_and_cancelled_callback_cannot_exchange_code(self):
        login = self.broker.start()
        state = parse_qs(urlsplit(login['url']).query)['state']
        with self.assertRaises(pc.SafeError):
            self.broker.callback({'state': ['wrong'], 'code': ['code']})
        self.now += 601
        with self.assertRaises(pc.SafeError):
            self.broker.callback({'state': state, 'code': ['code']})
        self.assertEqual(self.calls, [])
        login = self.broker.start()
        state = parse_qs(urlsplit(login['url']).query)['state']
        with self.assertRaises(pc.SafeError):
            self.broker.callback({'state': state, 'error': ['access_denied']})
        self.assertEqual(self.broker.status(login['flow'])['status'], 'error')
        self.assertEqual(self.calls, [])

    def test_new_flow_invalidates_older_login(self):
        first = self.broker.start()
        self.broker.start()
        with self.assertRaises(pc.SafeError):
            self.broker.status(first['flow'])

    def test_missing_scope_and_zero_multiple_channels_do_not_replace_grant(self):
        self.finish()
        previous = copy.deepcopy(self.vault.data['grant'])
        for missing in ('scope', 'zero', 'multiple'):
            def fetch(url, form=None, token=None):
                if '/channels?' in url:
                    return {'items': [] if missing == 'zero' else [CHANNEL, CHANNEL]}
                return {'access_token': 'other', 'refresh_token': 'other', 'expires_in': 3600,
                        'scope': '' if missing == 'scope' else self.scopes}
            self.broker.fetch = fetch
            with self.assertRaises(pc.SafeError):
                self.finish()
            self.assertEqual(self.vault.data['grant'], previous)

    def test_refresh_revalidates_channel_before_returning_new_token(self):
        self.finish()
        self.now += 3550
        self.broker.token()
        self.assertEqual(self.calls[-2][1]['grant_type'], 'refresh_token')
        self.assertIn('/channels?', self.calls[-1][0])
        self.now += 3550
        self.channel = {**CHANNEL, 'id': 'UC' + 'b' * 22}
        with self.assertRaises(pc.SafeError):
            self.broker.token()

    def test_disconnect_erases_grant_even_when_revocation_fails(self):
        self.finish()
        def fail(*args, **kwargs):
            raise pc.SafeError('network failure')
        self.broker.fetch = fail
        self.broker.disconnect()
        self.assertNotIn('grant', self.vault.data)
        self.assertEqual(self.broker.flows, {})

    @unittest.skipUnless(os.name == 'nt', 'Windows DPAPI')
    def test_real_dpapi_round_trip_is_not_plaintext_and_corruption_fails(self):
        with tempfile.TemporaryDirectory(dir=pc.ROOT / 'build') as folder:
            vault = pc.Vault(folder)
            try:
                vault.write('grant', {'refresh_token': 'test-private-refresh'})
            except pc.SafeError as error:
                if str(error).endswith('(code 2).'):
                    self.skipTest('Sandbox has no Windows user DPAPI profile; no plaintext fallback.')
                raise
            raw = (Path(folder) / 'grant.bin').read_bytes()
            self.assertNotIn(b'test-private-refresh', raw)
            self.assertEqual(vault.read('grant')['refresh_token'], 'test-private-refresh')
            (Path(folder) / 'grant.bin').write_bytes(b'corrupt')
            with self.assertRaises(pc.SafeError):
                vault.read('grant')

    def test_failed_credential_protection_never_writes_plaintext(self):
        with tempfile.TemporaryDirectory(dir=pc.ROOT / 'build') as folder:
            vault = pc.Vault(folder)
            with patch.object(pc, 'dpapi', side_effect=pc.SafeError('No user profile')):
                with self.assertRaises(pc.SafeError):
                    vault.write('grant', {'refresh_token': 'secret'})
            self.assertEqual(list(Path(folder).iterdir()), [])


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.broker = pc.Broker(MemoryVault())
        self.server = pc.Server(self.broker, port=0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

    def call(self, method, path, headers=None, body=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        connection.request(method, path, headers=headers or {}, body=body)
        response = connection.getresponse()
        data = response.read()
        result = response.status, dict(response.getheaders()), data
        connection.close()
        return result

    def test_unauthorized_origin_and_rebinding_are_rejected(self):
        self.assertEqual(self.call('POST', '/api/token')[0], 401)
        auth = {'Authorization': 'Bearer test-pairing-key'}
        self.assertEqual(self.call('POST', '/api/login', {**auth, 'Origin': 'https://evil.example'})[0], 403)
        self.assertEqual(self.call('POST', '/api/login', {**auth, 'Host': 'evil.example'})[0], 400)
        self.assertEqual(self.call('POST', '/api/login', {**auth, 'Sec-Fetch-Site': 'cross-site'})[0], 403)
        self.assertEqual(self.call('POST', '/api/login', auth, 'data')[0], 400)
        self.assertEqual(self.broker.flows, {})

    def test_api_responses_no_store_health_has_no_credentials_no_request_logs(self):
        output = io.StringIO()
        with contextlib.redirect_stderr(output):
            status, headers, raw = self.call('GET', '/health')
            self.assertEqual(status, 200)
            self.assertEqual(headers['Cache-Control'], 'no-store')
            self.assertNotIn('test-secret', raw.decode())
            self.call('GET', '/oauth/callback?state=secret-state&code=secret-code')
        self.assertEqual(output.getvalue(), '')


if __name__ == '__main__':
    unittest.main()
