// Run with: dart run tool/verify_youtube_upload.dart
// Uses an in-memory HTTP server substitute; never calls Google or uploads media.
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shorts_studio/youtube_upload.dart';

void require(bool condition, String message) {
  if (!condition) throw StateError(message);
}

Future<void> main() async {
  final directory = await Directory.systemTemp.createTemp('youtube_protocol_');
  final file = File('${directory.path}/sample.mp4');
  await file.writeAsBytes([1, 2, 3, 4]);
  const session =
      'https://www.googleapis.com/upload/youtube/v3/videos?upload_id=test';
  var passed = 0;
  Future<void> scenario(String name, Future<void> Function() body) async {
    await body();
    passed++;
    stdout.writeln('PASS $name');
  }

  Map<String, dynamic> state = {};
  YouTubeUpload uploader(
    Future<http.Response> Function(http.Request) handler,
  ) => YouTubeUpload(
    client: MockClient(handler),
    token: () async => 'fake-token',
    readState: () async => Map.of(state),
    writeState: (data) async => state = Map.of(data),
  );
  Future<String> run(
    YouTubeUpload upload, {
    String email = 'test@example.com',
  }) => upload.upload(
    file: file,
    email: email,
    channelId: 'UCaaaaaaaaaaaaaaaaaaaaaa',
    title: 'test title',
    description: 'test',
    madeForKids: true,
    syntheticMedia: true,
    onProgress: (_) {},
  );
  Future<void> fails(YouTubeUpload upload, String fragment) async {
    try {
      await run(upload);
    } on YouTubeFailure catch (e) {
      require(e.message.contains(fragment), 'Unexpected failure: $e');
      return;
    }
    throw StateError('Expected YouTubeFailure');
  }

  try {
    await scenario(
      'private upload, metadata, bytes and durable completion',
      () async {
        var requests = 0;
        final id = await run(
          uploader((request) async {
            requests++;
            require(
              request.headers['Authorization'] == 'Bearer fake-token',
              'Missing auth',
            );
            require(!request.followRedirects, 'Unexpected redirect');
            if (request.method == 'POST') {
              final body = jsonDecode(request.body);
              require(
                body['status']['privacyStatus'] == 'private',
                'Must be private',
              );
              require(
                body['status']['selfDeclaredMadeForKids'] == true,
                'Kids flag missing',
              );
              require(
                body['status']['containsSyntheticMedia'] == true,
                'Synthetic flag missing',
              );
              require(
                request.headers['X-Upload-Content-Length'] == '4',
                'Wrong size',
              );
              return http.Response('', 200, headers: {'location': session});
            }
            require(
              state['session'] == session,
              'Session was not saved before sending bytes',
            );
            require(
              request.headers['Content-Range'] == 'bytes 0-3/4',
              'Wrong range',
            );
            require(request.bodyBytes.join(',') == '1,2,3,4', 'Wrong bytes');
            return http.Response('{"id":"video_123"}', 201);
          }),
        );
        require(
          id == 'video_123' && state['videoId'] == id && requests == 2,
          'Wrong result',
        );
      },
    );
    await scenario(
      'completed upload returns saved ID without another request',
      () async {
        require(
          await run(
                uploader((_) async => throw StateError('Duplicate request')),
              ) ==
              'video_123',
          'Lost ID',
        );
      },
    );
    await scenario(
      'interrupted upload resumes after server-confirmed bytes',
      () async {
        state = {
          'session': session,
          'size': 4,
          'email': 'test@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        var requests = 0;
        await run(
          uploader((request) async {
            requests++;
            require(request.method == 'PUT', 'Must not create another video');
            if (requests == 1) {
              require(
                request.bodyBytes.isEmpty &&
                    request.headers['Content-Range'] == 'bytes */4',
                'Missing status query',
              );
              return http.Response('', 308, headers: {'range': 'bytes=0-1'});
            }
            require(
              request.headers['Content-Range'] == 'bytes 2-3/4',
              'Wrong resume position',
            );
            require(
              request.bodyBytes.join(',') == '3,4',
              'Wrong resumed bytes',
            );
            return http.Response('{"id":"resumed"}', 201);
          }),
        );
        require(
          requests == 2 && state['videoId'] == 'resumed',
          'Resume failed',
        );
      },
    );
    await scenario(
      'lost completion response is recovered without re-upload',
      () async {
        state = {
          'session': session,
          'size': 4,
          'email': 'test@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        var requests = 0;
        await run(
          uploader((request) async {
            requests++;
            require(request.bodyBytes.isEmpty, 'Must only query status');
            return http.Response('{"id":"already_done"}', 200);
          }),
        );
        require(
          requests == 1 && state['videoId'] == 'already_done',
          'Completion recovery failed',
        );
      },
    );
    await scenario(
      'another account cannot continue a pending upload',
      () async {
        state = {
          'session': session,
          'size': 4,
          'email': 'other@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        await fails(
          uploader((_) async => throw StateError('Unexpected request')),
          '계정',
        );
      },
    );
    await scenario(
      'expired session does not silently create a duplicate',
      () async {
        state = {
          'session': session,
          'size': 4,
          'email': 'test@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        await fails(
          uploader((request) async {
            require(request.method == 'PUT', 'Duplicate session created');
            return http.Response('', 404);
          }),
          '기한',
        );
        require(
          state['session'] == session,
          'Ambiguous state must remain recorded',
        );
      },
    );
    await scenario(
      'changed output size is rejected before transmission',
      () async {
        state = {
          'session': session,
          'size': 999,
          'email': 'test@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        await fails(
          uploader((_) async => throw StateError('Unexpected request')),
          '변경',
        );
      },
    );
    await scenario(
      'non-Google session cannot receive an access token',
      () async {
        state = {
          'session': 'https://evil.example/upload/',
          'size': 4,
          'email': 'test@example.com',
          'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
        };
        await fails(
          uploader((_) async => throw StateError('Leaked request')),
          '주소',
        );
      },
    );
    await scenario('quota rejection preserves pending upload', () async {
      state = {
        'session': session,
        'size': 4,
        'email': 'test@example.com',
        'channelId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
      };
      await fails(
        uploader(
          (_) async => http.Response(
            '{"error":{"errors":[{"reason":"quotaExceeded"}]}}',
            403,
          ),
        ),
        '사용량',
      );
      require(!state.containsKey('videoId'), 'Failure marked completed');
    });
    stdout.writeln(
      '$passed protocol checks passed. Live Google authentication/upload not tested.',
    );
  } finally {
    await directory.delete(recursive: true);
  }
}
