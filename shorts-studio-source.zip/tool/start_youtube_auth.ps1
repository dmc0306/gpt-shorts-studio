$ErrorActionPreference = 'Stop'
$studioRoot = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $studioRoot
if (!(Test-Path -LiteralPath '.local/youtube-auth/client.bin')) {
    Write-Host 'Google Web OAuth callback: http://127.0.0.1:8765/oauth/callback'
    Write-Host 'Select the downloaded Web OAuth client JSON file.'
    Add-Type -AssemblyName System.Windows.Forms
    $studioPicker = New-Object System.Windows.Forms.OpenFileDialog
    $studioPicker.Title = 'Shorts Studio - Google Web OAuth client JSON'
    $studioPicker.Filter = 'Google OAuth JSON (*.json)|*.json'
    if ($studioPicker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }
    & python tool/youtube_pc.py import-client $studioPicker.FileName
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& python tool/youtube_pc.py pair
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python tool/youtube_pc.py serve
exit $LASTEXITCODE
