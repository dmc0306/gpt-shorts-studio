$FlutterArguments = @($args)
$ErrorActionPreference = 'Stop'
$studioRoot = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $studioRoot
$env:FLUTTER_ROOT = Join-Path $studioRoot '.build-tools\flutter'
$env:PUB_CACHE = Join-Path $studioRoot '.pub-cache'
$env:GRADLE_USER_HOME = Join-Path $studioRoot '.build-tools\gradle-home'
$env:ANDROID_USER_HOME = Join-Path $studioRoot '.build-tools\android-user'
$env:ANDROID_HOME = Join-Path $studioRoot '.build-tools\android-sdk'
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:JAVA_HOME = 'C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot'
$env:CI = 'true'
$env:FLUTTER_SUPPRESS_ANALYTICS = 'true'
$env:TEMP = Join-Path $studioRoot '.build-tools\tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP, $env:ANDROID_USER_HOME | Out-Null
$studioKey = Join-Path $env:ANDROID_USER_HOME 'debug.keystore'
if (!(Test-Path -LiteralPath $studioKey)) {
  Copy-Item -LiteralPath (Join-Path $env:USERPROFILE '.android\debug.keystore') -Destination $studioKey
}
$studioDart = Join-Path $env:FLUTTER_ROOT 'bin\cache\dart-sdk\bin\dart.exe'
$studioFlutter = Join-Path $env:FLUTTER_ROOT 'bin\cache\flutter_tools.snapshot'
& $studioDart $studioFlutter --suppress-analytics @FlutterArguments
exit $LASTEXITCODE
