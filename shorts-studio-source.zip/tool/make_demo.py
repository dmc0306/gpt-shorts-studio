from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import math,subprocess
root=Path(__file__).resolve().parents[1]
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
big=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',58)
cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','360x640','-r','24','-i','-','-an','-c:v','libx264','-crf','24','-pix_fmt','yuv420p','-movflags','+faststart',str(root/'assets/demo.mp4')]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for frame in range(360):
 t=frame/24
 im=Image.new('RGB',(360,640),'#deddd8');d=ImageDraw.Draw(im)
 for x in range(0,360,24): d.line((x,0,x,640),fill='#d2d1cb')
 for y in range(0,640,24): d.line((0,y,360,y),fill='#d2d1cb')
 d.text((24,24),'STUDIO / MOTION 001',fill='#333333',font=font)
 x=180+45*math.sin(t*.8);y=300+40*math.cos(t*.65)
 d.ellipse((x-122,y-122,x+122,y+122),fill='#0099ff')
 d.ellipse((x-90,y-90,x+90,y+90),fill='#deddd8')
 d.ellipse((x-50,y-50,x+50,y+50),fill='#101010')
 d.text((24,490),'Make it',font=big,fill='#101010');d.text((24,552),'move.',font=big,fill='#101010')
 if frame==60:im.save(root/'design/demo-poster.jpg',quality=92)
 p.stdin.write(im.tobytes())
p.stdin.close();assert p.wait()==0
