import base64
import os
from pathlib import Path
import tempfile
import unittest
import hashlib
import subprocess
from unittest.mock import patch
from signing import restore, verify

class SigningSetupTests(unittest.TestCase):
    def test_restore_preserves_bytes_uses_private_temp_file_and_exports_only_path(self):
        with tempfile.TemporaryDirectory() as directory:
            env={'RUNNER_TEMP':directory,'GITHUB_ENV':str(Path(directory)/'env'),
                 'ANDROID_KEYSTORE_BASE64':'\n'+base64.b64encode(b'synthetic-test-bytes').decode()+'\n',
                 'ANDROID_KEYSTORE_PASSWORD':'dummy password','ANDROID_KEY_ALIAS':'dummy alias',
                 'ANDROID_KEY_PASSWORD':'dummy key password'}
            target=restore(env)
            self.assertEqual(target.read_bytes(),b'synthetic-test-bytes')
            self.assertEqual(target.stat().st_mode & 0o777,0o600)
            exported=Path(env['GITHUB_ENV']).read_text()
            self.assertEqual(exported,f'ANDROID_KEYSTORE_PATH={target}\n')
            self.assertNotIn('dummy',exported)

    def test_missing_secrets_do_not_fall_back_to_debug_signing(self):
        with self.assertRaisesRegex(ValueError,'Missing GitHub Secrets'):
            restore({})

    def test_invalid_base64_does_not_write_a_keystore(self):
        with tempfile.TemporaryDirectory() as directory:
            env={name:'dummy' for name in ['ANDROID_KEYSTORE_PASSWORD','ANDROID_KEY_ALIAS','ANDROID_KEY_PASSWORD']}
            env.update(ANDROID_KEYSTORE_BASE64='not a valid key!',RUNNER_TEMP=directory,GITHUB_ENV=str(Path(directory)/'env'))
            with self.assertRaisesRegex(ValueError,'not valid base64'):
                restore(env)
            self.assertEqual(list(Path(directory).iterdir()),[])

    def check_certificate(self, output, fails=False):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            tool=root/'build-tools/36.0.0/apksigner'
            tool.parent.mkdir(parents=True)
            tool.touch()
            env={'ANDROID_HOME':directory,'RUNNER_TEMP':directory,
                 'ANDROID_KEYSTORE_PATH':str(root/'key.jks'),
                 'ANDROID_KEY_ALIAS':'dummy','ANDROID_KEYSTORE_PASSWORD':'dummy'}
            def run(args, **kwargs):
                if args[0]=='keytool':
                    (root/'studio-signing.der').write_bytes(b'synthetic-certificate')
                    return subprocess.CompletedProcess(args,0)
                return subprocess.CompletedProcess(args,0,stdout=output)
            with patch('signing.subprocess.run',side_effect=run):
                if fails:
                    with self.assertRaises(ValueError):
                        verify(root/'app.apk',env)
                else:
                    verify(root/'app.apk',env)
            self.assertFalse((root/'studio-signing.der').exists())

    def test_numbered_and_sdk_range_signers_match_the_keystore(self):
        digest=hashlib.sha256(b'synthetic-certificate').hexdigest()
        self.check_certificate(f'Signer #1 certificate SHA-256 digest: {digest}\n')
        self.check_certificate(
            f'Signer (minSdkVersion=33, maxSdkVersion=2147483647) certificate SHA-256 digest: {digest}\n'
            f'Signer (minSdkVersion=29, maxSdkVersion=32) certificate SHA-256 digest: {digest}\n'
            f'Source Stamp Signer certificate SHA-256 digest: {"f"*64}\n')

    def test_wrong_or_missing_or_additional_signer_is_rejected(self):
        digest=hashlib.sha256(b'synthetic-certificate').hexdigest()
        self.check_certificate(f'Signer #1 certificate SHA-256 digest: {"f"*64}\n',True)
        self.check_certificate(f'Signer #1 public key SHA-256 digest: {digest}\n',True)
        self.check_certificate(
            f'Signer #1 certificate SHA-256 digest: {digest}\n'
            f'Signer #2 certificate SHA-256 digest: {"f"*64}\n',True)

if __name__=='__main__':
    unittest.main()
