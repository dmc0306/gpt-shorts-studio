import base64
import os
from pathlib import Path
import tempfile
import unittest
from signing import restore

class SigningSetupTests(unittest.TestCase):
    def test_restore_preserves_bytes_uses_private_temp_file_and_exports_only_path(self):
        with tempfile.TemporaryDirectory() as directory:
            env={'RUNNER_TEMP':directory,'GITHUB_ENV':str(Path(directory)/'env'),
                 'ANDROID_KEYSTORE_BASE64':'\n'+base64.b64encode(b'synthetic-test-bytes').decode()+'\n',
                 'ANDROID_KEYSTORE_PASSWORD':'dummy password','ANDROID_KEY_ALIAS':'dummy alias',
                 'ANDROID_KEY_PASSWORD':'dummy key password'}
            target=restore(env)
            self.assertEqual(target.read_bytes(),b'synthetic-test-bytes')
            self.assertEqual(target.stat().st_mode & 0o777,0o600)
            exported=Path(env['GITHUB_ENV']).read_text()
            self.assertEqual(exported,f'ANDROID_KEYSTORE_PATH={target}\n')
            self.assertNotIn('dummy',exported)

    def test_missing_secrets_do_not_fall_back_to_debug_signing(self):
        with self.assertRaisesRegex(ValueError,'Missing GitHub Secrets'):
            restore({})

    def test_invalid_base64_does_not_write_a_keystore(self):
        with tempfile.TemporaryDirectory() as directory:
            env={name:'dummy' for name in ['ANDROID_KEYSTORE_PASSWORD','ANDROID_KEY_ALIAS','ANDROID_KEY_PASSWORD']}
            env.update(ANDROID_KEYSTORE_BASE64='not a valid key!',RUNNER_TEMP=directory,GITHUB_ENV=str(Path(directory)/'env'))
            with self.assertRaisesRegex(ValueError,'not valid base64'):
                restore(env)
            self.assertEqual(list(Path(directory).iterdir()),[])

if __name__=='__main__':
    unittest.main()
