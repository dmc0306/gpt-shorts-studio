"""Loopback-only OAuth broker for the Android app. Secrets never enter the APK.

python tool/youtube_pc.py import-client <downloaded-web-client.json>
python tool/youtube_pc.py pair
python tool/youtube_pc.py serve
"""
import argparse
import base64
import ctypes
from ctypes import wintypes
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import socket
import struct
import threading
import time
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

ROOT = Path(__file__).resolve().parents[1]
HOME = ROOT / '.local' / 'youtube-auth'
PORT = 8765
REDIRECT = f'http://127.0.0.1:{PORT}/oauth/callback'
CLIENT_ID = '337875283119-kd8bh4tb2k108mcevsn94fbrb6vju1ah.apps.googleusercontent.com'
SCOPES = ('https://www.googleapis.com/auth/youtube.upload',
          'https://www.googleapis.com/auth/youtube.readonly')
PACKAGE = 'com.local.shorts_studio'


class SafeError(Exception):
    pass


def dpapi(data, decrypt=False):
    """Current Windows user only. No plaintext fallback."""
    if os.name != 'nt':
        raise SafeError('This broker requires Windows DPAPI.')
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    target = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    crypt.CryptProtectData.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR,
        ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    crypt.CryptUnprotectData.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p,
        ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    if decrypt:
        ok = crypt.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target))
    else:
        ok = crypt.CryptProtectData(ctypes.byref(source), 'Shorts Studio', None, None, None, 1, ctypes.byref(target))
    if not ok:
        raise SafeError('Windows credential protection failed (code ' + str(ctypes.get_last_error()) + ').')
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        kernel.LocalFree(target.data)


class Vault:
    def __init__(self, folder=HOME):
        self.folder = Path(folder)

    def read(self, name):
        path = self.folder / (name + '.bin')
        if not path.exists():
            return None
        try:
            return json.loads(dpapi(path.read_bytes(), decrypt=True))
        except Exception:
            raise SafeError('Cannot read protected PC credentials.') from None

    def write(self, name, value):
        self.folder.mkdir(parents=True, exist_ok=True)
        path = self.folder / (name + '.bin')
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(dpapi(json.dumps(value).encode()))
        temporary.replace(path)

    def remove(self, name):
        (self.folder / (name + '.bin')).unlink(missing_ok=True)

    def pair_key(self):
        value = self.read('pairing')
        if value is None:
            value = {'key': secrets.token_urlsafe(32)}
            self.write('pairing', value)
        return value['key']


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def google_json(url, form=None, token=None):
    # URLs are constants supplied by this program, never from a request body.
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    data = None
    if form is not None:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        data = urlencode(form).encode()
    try:
        with build_opener(NoRedirect()).open(Request(url, data=data, headers=headers), timeout=30) as response:
            return json.loads(response.read(1024 * 1024))
    except (HTTPError, OSError, ValueError):
        raise SafeError('Google request failed. Reconnect or check PC internet.') from None


def channel_for(token, fetch=google_json):
    result = fetch('https://www.googleapis.com/youtube/v3/channels?' + urlencode({
        'part': 'snippet', 'mine': 'true', 'maxResults': '2'}), token=token)
    items = result.get('items', [])
    total = result.get('pageInfo', {}).get('totalResults', len(items))
    if not isinstance(items, list) or len(items) != 1 or result.get('nextPageToken') or total != 1:
        raise SafeError('A single channel was not found. Check the selected Brand Account. [YT_CHANNEL_COUNT]')
    item = items[0]
    channel_id, title = item.get('id', ''), item.get('snippet', {}).get('title', '')
    if not re.fullmatch(r'UC[A-Za-z0-9_-]{22}', channel_id) or not isinstance(title, str) or not title.strip():
        raise SafeError('Invalid YouTube channel response.')
    return {'id': channel_id, 'title': title}


class Broker:
    def __init__(self, vault=None, fetch=google_json, clock=time.time):
        self.vault = vault or Vault()
        self.key = self.vault.pair_key()
        self.fetch, self.clock = fetch, clock
        self.lock = threading.RLock()
        self.flows = {}

    def config(self):
        config = self.vault.read('client')
        if not config:
            raise SafeError('PC_SETUP: Import the Google Web OAuth client JSON on the PC first.')
        return config

    def start(self):
        with self.lock:
            config = self.config()
            # Only the most recent explicit connection attempt may finish.
            self.flows.clear()
            flow, state, verifier = (secrets.token_urlsafe(32) for _ in range(3))
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
            self.flows[flow] = {'state': state, 'verifier': verifier,
                                'expires': self.clock() + 600, 'status': 'pending'}
            url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urlencode({
                'client_id': config['client_id'], 'redirect_uri': REDIRECT,
                'response_type': 'code', 'scope': ' '.join(SCOPES),
                'access_type': 'offline', 'prompt': 'select_account consent',
                'state': state, 'code_challenge': challenge, 'code_challenge_method': 'S256'})
            return {'flow': flow, 'url': url}

    def status(self, flow):
        with self.lock:
            item = self.flows.get(flow)
            if not item or item['expires'] <= self.clock():
                raise SafeError('Login expired. Start again in the app.')
            return {key: item[key] for key in ('status', 'error') if key in item}

    def callback(self, query):
        with self.lock:
            states = query.get('state', [])
            if len(states) != 1:
                raise SafeError('Invalid OAuth state.')
            item = next((item for item in self.flows.values()
                         if item.get('state') and hmac.compare_digest(item['state'], states[0])), None)
            if not item or item['status'] != 'pending' or item['expires'] <= self.clock():
                raise SafeError('Invalid or expired OAuth state.')
            item['state'] = ''  # One use, even on denial or Google failure.
            try:
                if query.get('error'):
                    raise SafeError('Google consent was cancelled. Start again in the app.')
                codes = query.get('code', [])
                if len(codes) != 1 or not codes[0] or len(codes[0]) > 8192:
                    raise SafeError('Missing authorization code.')
                config = self.config()
                tokens = self.fetch('https://oauth2.googleapis.com/token', form={
                    'client_id': config['client_id'], 'client_secret': config['client_secret'],
                    'code': codes[0], 'code_verifier': item.pop('verifier'),
                    'grant_type': 'authorization_code', 'redirect_uri': REDIRECT})
                granted = set(tokens.get('scope', '').split())
                if not set(SCOPES).issubset(granted):
                    raise SafeError('Both channel read and video upload permissions are required.')
                if not tokens.get('refresh_token') or not tokens.get('access_token'):
                    raise SafeError('Offline permission missing. Reconnect and consent again.')
                channel = channel_for(tokens['access_token'], self.fetch)
                self.vault.write('grant', {'refresh_token': tokens['refresh_token'],
                    'access_token': tokens['access_token'], 'client_id': config['client_id'],
                    'expires': self.clock() + min(int(tokens.get('expires_in', 0)), 3600),
                    'channel': channel})
                item['status'] = 'complete'
            except SafeError as error:
                item.update(status='error', error=str(error))
                raise
            except Exception:
                item.update(status='error', error='Invalid Google authentication response. Reconnect in the app.')
                raise SafeError(item['error']) from None
            finally:
                item.pop('verifier', None)

    def token(self):
        with self.lock:
            config, grant = self.config(), self.vault.read('grant')
            if not grant or grant['client_id'] != config['client_id']:
                raise SafeError('PC_LOGIN: Connect with the mobile browser first.')
            if grant['expires'] <= self.clock() + 90:
                tokens = self.fetch('https://oauth2.googleapis.com/token', form={
                    'client_id': config['client_id'], 'client_secret': config['client_secret'],
                    'grant_type': 'refresh_token', 'refresh_token': grant['refresh_token']})
                token = tokens.get('access_token')
                if not token:
                    raise SafeError('PC_LOGIN: Reconnect in the app.')
                actual = channel_for(token, self.fetch)
                if actual['id'] != grant['channel']['id']:
                    raise SafeError('Channel changed. Reconnect and confirm the destination.')
                grant.update(access_token=token,
                    expires=self.clock() + min(int(tokens.get('expires_in', 0)), 3600))
                self.vault.write('grant', grant)
            return {'access_token': grant['access_token'], 'channel': grant['channel'],
                    'identity': 'pc:' + config['client_id'] + ':' + grant['channel']['id'],
                    'expires': grant['expires']}

    def disconnect(self):
        with self.lock:
            grant = self.vault.read('grant')
            self.flows.clear()
            self.vault.remove('grant')
            if grant:
                try:
                    self.fetch('https://oauth2.googleapis.com/revoke', form={'token': grant['refresh_token']})
                except SafeError:
                    pass  # Local credentials are removed even if Google is unavailable.


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, broker, port=PORT):
        self.broker = broker
        super().__init__(('127.0.0.1', port), Handler)


class Handler(BaseHTTPRequestHandler):
    server_version = 'ShortsStudioAuth/1'

    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def log_message(self, *args):
        pass  # Never log URLs, OAuth codes, tokens or pairing credentials.

    def reply(self, status, body, html=False):
        data = body.encode('utf8') if html else json.dumps(body).encode('utf8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self.handle_request()

    def do_POST(self):
        self.handle_request()

    def handle_request(self):
        broker = self.server.broker
        host = self.headers.get('Host', '')
        if host != f'127.0.0.1:{self.server.server_port}' or len(self.path) > 16384:
            return self.reply(400, {'error': 'Invalid request host or size.'})
        parsed = urlsplit(self.path)
        if parsed.scheme or parsed.netloc:
            return self.reply(400, {'error': 'Invalid request target.'})
        if parsed.path == '/oauth/callback' and self.command == 'GET':
            try:
                broker.callback(parse_qs(parsed.query, keep_blank_values=True))
                message = '인증 완료. Shorts Studio 앱으로 돌아가 채널을 확인하세요.'
                status = 200
            except SafeError:
                message = '인증을 완료하지 못했어요. Shorts Studio 앱으로 돌아가 오류를 확인하고 다시 연결하세요.'
                status = 400
            except Exception:
                message, status = '인증 응답을 처리하지 못했어요. 앱에서 다시 연결하세요.', 400
            return self.reply(status, '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Shorts Studio</title><p>' + message + '</p>', html=True)
        if self.headers.get('Origin') or self.headers.get('Sec-Fetch-Site'):
            return self.reply(403, {'error': 'Browser API calls are not allowed.'})
        if parsed.path == '/health' and self.command == 'GET':
            return self.reply(200, {'service': 'shorts-studio-auth', 'version': 1,
                                    'configured': broker.vault.read('client') is not None})
        authorization = self.headers.get('Authorization', '')
        if not hmac.compare_digest(authorization, 'Bearer ' + broker.key):
            return self.reply(401, {'error': 'PC_PAIR: Pair this phone on the PC first.'})
        try:
            if self.command == 'POST':
                if self.headers.get('Transfer-Encoding') or int(self.headers.get('Content-Length', '0')) > 1024:
                    return self.reply(400, {'error': 'Invalid request size.'})
                if int(self.headers.get('Content-Length', '0')):
                    return self.reply(400, {'error': 'Request body must be empty.'})
            if parsed.path == '/api/login' and self.command == 'POST':
                result = broker.start()
            elif parsed.path.startswith('/api/login/') and self.command == 'GET':
                result = broker.status(parsed.path.removeprefix('/api/login/'))
            elif parsed.path == '/api/token' and self.command == 'POST':
                result = broker.token()
            elif parsed.path == '/api/disconnect' and self.command == 'POST':
                broker.disconnect()
                result = {'ok': True}
            else:
                return self.reply(404, {'error': 'Unknown endpoint.'})
            self.reply(200, result)
        except SafeError as error:
            self.reply(409, {'error': str(error)})
        except Exception:
            self.reply(500, {'error': 'PC authentication failed. Reconnect in the app.'})


def adb_read(sock, size):
    data = b''
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise SafeError('ADB connection closed.')
        data += chunk
    return data


def adb_request(sock, service):
    data = service.encode()
    sock.sendall(f'{len(data):04x}'.encode() + data)
    if adb_read(sock, 4) != b'OKAY':
        size = int(adb_read(sock, 4), 16)
        adb_read(sock, size)
        raise SafeError('ADB request failed. Check that this phone is authorized and the app is installed.')


def adb_transport(serial):
    sock = socket.create_connection(('127.0.0.1', 5037), timeout=10)
    adb_request(sock, 'host:transport:' + serial)
    return sock


def pair(vault):
    # Uses only an existing authorized ADB server. Never accepts device trust prompts.
    with socket.create_connection(('127.0.0.1', 5037), timeout=10) as sock:
        adb_request(sock, 'host:devices')
        listing = adb_read(sock, int(adb_read(sock, 4), 16)).decode()
    devices = [line.split('\t')[0] for line in listing.splitlines() if line.endswith('\tdevice')]
    if len(devices) != 1:
        raise SafeError('Connect exactly one authorized Android phone first.')
    serial = devices[0]
    with adb_transport(serial) as sock:
        adb_request(sock, f'reverse:forward:tcp:{PORT};tcp:{PORT}')
        # Reverse service sends a second protocol status after dispatch.
        if adb_read(sock, 4) != b'OKAY':
            raise SafeError('ADB reverse tunnel could not be created.')
    payload = json.dumps({'key': vault.pair_key()}).encode()
    with adb_transport(serial) as sock:
        # Pairing is written directly into app-private storage, never /sdcard or argv.
        adb_request(sock, 'shell,v2,raw:run-as ' + PACKAGE + " sh -c 'umask 077; cat > files/youtube-pc-pairing.tmp && mv files/youtube-pc-pairing.tmp files/youtube-pc-pairing.json'")
        # Shell v2's explicit CLOSE_STDIN lets cat finish and rename atomically.
        # Half-closing the raw exec socket can kill the command before rename.
        sock.sendall(struct.pack('<BI', 0, len(payload)) + payload + struct.pack('<BI', 4, 0))
        output, exit_code = bytearray(), None
        while exit_code is None:
            kind, length = struct.unpack('<BI', adb_read(sock, 5))
            if length > 1024 * 1024:
                raise SafeError('Invalid ADB shell response.')
            data = adb_read(sock, length)
            if kind == 3:
                exit_code = data[0] if data else 1
            elif kind in (1, 2):
                output.extend(data)
        if output or exit_code != 0:
            raise SafeError('Cannot provision the app. Install the debug APK and run it once first.')
    print('Phone paired; loopback tunnel ready. Keep this ADB connection active.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['serve', 'pair', 'import-client'])
    parser.add_argument('json_file', nargs='?')
    args = parser.parse_args()
    vault = Vault()
    try:
        if args.command == 'import-client':
            data = json.loads(Path(args.json_file).read_text(encoding='utf-8-sig'))
            web = data.get('web', {})
            if web.get('client_id') != CLIENT_ID or not web.get('client_secret'):
                raise SafeError('Use the existing Shorts Studio Web OAuth client JSON.')
            if REDIRECT not in web.get('redirect_uris', []):
                raise SafeError('Register ' + REDIRECT + ' in the Web OAuth client, then download its JSON.')
            vault.write('client', {key: web[key] for key in ('client_id', 'client_secret')})
            print('Web client imported into Windows protected storage. No secret was printed.')
        elif args.command == 'pair':
            pair(vault)
        else:
            broker = Broker(vault)
            print('Shorts Studio authentication: ' + REDIRECT, flush=True)
            print('Configured:', vault.read('client') is not None, flush=True)
            Server(broker).serve_forever()
    except (SafeError, OSError, ValueError, TypeError):
        # No exception trace: a parser/network exception could include credential data.
        print('Setup failed. Check the client JSON, callback URI, Windows user and authorized ADB phone.')
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
