#!/usr/bin/env python3
"""Generate Flutter's platform scaffolding, then install the native implementation."""
from pathlib import Path
import shutil, subprocess, sys, re
root=Path(__file__).resolve().parents[1]
flutter=shutil.which('flutter')
if not flutter:
    sys.exit('Flutter SDK가 PATH에 필요합니다. README.md의 실행 순서를 확인하세요.')
subprocess.run([flutter,'create','--platforms=android','--org','com.local','--project-name','shorts_studio','--no-pub',str(root)],check=True,cwd=root)
app=root/'android/app'
for source,target in [('BenchmarkFrameExtractor.kt','src/main/kotlin/com/local/shorts_studio/BenchmarkFrameExtractor.kt'),('BenchmarkOcrCrop.kt','src/main/kotlin/com/local/shorts_studio/BenchmarkOcrCrop.kt'),('YouTubeRedirectTraceActivity.kt','src/main/kotlin/com/local/shorts_studio/YouTubeRedirectTraceActivity.kt'),('YouTubeChromeAuth.kt','src/main/kotlin/com/local/shorts_studio/YouTubeChromeAuth.kt'),('YouTubeAuthorizationProbe.kt','src/main/kotlin/com/local/shorts_studio/YouTubeAuthorizationProbe.kt'),('OriginalTextScanner.kt','src/main/kotlin/com/local/shorts_studio/OriginalTextScanner.kt'),('BatchService.kt','src/main/kotlin/com/local/shorts_studio/BatchService.kt'),('AndroidDailyScheduler.kt','src/main/kotlin/com/local/shorts_studio/AndroidDailyScheduler.kt'),('AndroidHeadlessDailyRunner.kt','src/main/kotlin/com/local/shorts_studio/AndroidHeadlessDailyRunner.kt'),('HeadlessDailyMedia.kt','src/main/kotlin/com/local/shorts_studio/HeadlessDailyMedia.kt'),('MainActivity.kt','src/main/kotlin/com/local/shorts_studio/MainActivity.kt'),('AndroidManifest.xml','src/main/AndroidManifest.xml')]:
    dest=app/target;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'native/android'/source,dest)
dest=app/'src/main/res/xml/network_security_config.xml'
dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'native/android/network_security_config.xml',dest)
frame_share_xml=app/'src/main/res/xml/benchmark_frame_paths.xml'
frame_share_xml.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'native/android/benchmark_frame_paths.xml',frame_share_xml)
# Preserve the installed Flutter SDK's Gradle/Kotlin plugin configuration.
gradle=app/'build.gradle.kts'
if not gradle.exists():
    sys.exit('Flutter 3.44 이상 stable SDK를 사용하세요. Kotlin Gradle 구성이 필요합니다.')
text=gradle.read_text()
text=re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = 29', text)
marker='// SHORTS_STUDIO_NATIVE_DEPENDENCIES'
if marker in text: text=text.split(marker)[0]
gradle.write_text(text+'\n'+marker+'\n'+(root/'native/android/dependencies.gradle.kts').read_text()+'\n'+(root/'native/android/signing.gradle.kts').read_text())
# Kotlin incremental caches cannot relativize plugin sources across Windows drives.
properties=root/'android/gradle.properties'
settings=properties.read_text() if properties.exists() else ''
for key,value in [('kotlin.incremental','false'),('kotlin.compiler.execution.strategy','in-process')]:
    settings=re.sub(r'^'+re.escape(key)+r'\s*=.*\n?', '', settings, flags=re.MULTILINE)
    settings=settings.rstrip()+'\n'+key+'='+value+'\n'
properties.write_text(settings)
# Flutter generates a counter test; this project has its own tests.
(root/'test/widget_test.dart').unlink(missing_ok=True)
subprocess.run([flutter,'pub','get'],check=True,cwd=root)
print('준비 완료: flutter run 또는 flutter build apk --debug')


# BEGIN Latin OCR model v0.21.19
from pathlib import Path as _ShortsPath
_gradle_files=[
    _ShortsPath("android/app/build.gradle.kts"),
    _ShortsPath("android/app/build.gradle"),
]
_gradle=next((p for p in _gradle_files if p.is_file()),None)
if _gradle is None:
    raise RuntimeError("Android app Gradle file not found for bundled Latin OCR")
_gradle_text=_gradle.read_text(encoding="utf8")
if "com.google.mlkit:text-recognition:16.0.1" not in _gradle_text:
    if _gradle.name.endswith(".kts"):
        _gradle_text+='\n\ndependencies {\n    implementation("com.google.mlkit:text-recognition:16.0.1")\n}\n'
    else:
        _gradle_text+="\n\ndependencies {\n    implementation 'com.google.mlkit:text-recognition:16.0.1'\n}\n"
    _gradle.write_text(_gradle_text,encoding="utf8")
# END Latin OCR model v0.21.19
