"""Restore CI-only keystore and verify APK against its public certificate."""
import base64
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys


def restore(env):
    names = ['ANDROID_KEYSTORE_BASE64', 'ANDROID_KEYSTORE_PASSWORD',
             'ANDROID_KEY_ALIAS', 'ANDROID_KEY_PASSWORD']
    missing = [name for name in names if not env.get(name)]
    if missing:
        raise ValueError('Missing GitHub Secrets: ' + ', '.join(missing))
    try:
        raw = base64.b64decode(''.join(env[names[0]].split()), validate=True)
    except (ValueError, TypeError):
        raise ValueError('ANDROID_KEYSTORE_BASE64 is not valid base64') from None
    if not raw:
        raise ValueError('ANDROID_KEYSTORE_BASE64 is empty')
    target = Path(env['RUNNER_TEMP']) / 'studio-signing.jks'
    with target.open('wb') as output:
        os.chmod(target, 0o600)
        output.write(raw)
    with open(env['GITHUB_ENV'], 'a') as output:
        output.write(f'ANDROID_KEYSTORE_PATH={target}\n')
    return target


def verify(apk, env):
    sdk = Path(env.get('ANDROID_HOME') or env['ANDROID_SDK_ROOT'])
    tools = sorted(sdk.glob('build-tools/*/apksigner'),
                   key=lambda p: tuple(int(x) for x in re.findall(r'\d+', p.parent.name)))
    if not tools:
        raise ValueError('Android apksigner is unavailable')
    certificate = Path(env['RUNNER_TEMP']) / 'studio-signing.der'
    try:
        exported = subprocess.run(['keytool', '-exportcert', '-keystore', env['ANDROID_KEYSTORE_PATH'],
                                   '-alias', env['ANDROID_KEY_ALIAS'], '-storepass:env',
                                   'ANDROID_KEYSTORE_PASSWORD', '-file', str(certificate)],
                                  env=env, capture_output=True, timeout=30)
        if exported.returncode:
            raise ValueError('Keystore password or alias is invalid')
        checked = subprocess.run([str(tools[-1]), 'verify', '--print-certs', str(apk)],
                                 capture_output=True, text=True, timeout=60)
        if checked.returncode:
            raise ValueError('APK signature verification failed')
        digests = re.findall(r'Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)', checked.stdout)
        expected = hashlib.sha256(certificate.read_bytes()).hexdigest()
        if len(digests) != 1 or digests[0].lower() != expected:
            raise ValueError('APK was not signed by the configured keystore')
        print('APK signature verified against ANDROID_KEYSTORE_BASE64')
        print('Signing certificate SHA-256: ' + expected)
    finally:
        certificate.unlink(missing_ok=True)


def main():
    try:
        if sys.argv[1] == 'restore':
            restore(os.environ)
            print('Android keystore restored in runner temporary storage')
        elif sys.argv[1] == 'verify':
            verify(Path(sys.argv[2]), os.environ)
        elif sys.argv[1] == 'cleanup':
            (Path(os.environ['RUNNER_TEMP']) / 'studio-signing.jks').unlink(missing_ok=True)
        else:
            raise ValueError('Unknown signing operation')
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        # Do not print subprocess output, private values or secret contents.
        print('Android signing setup failed: ' + (str(error) if isinstance(error, ValueError) else type(error).__name__), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
