import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.parse import parse_qs, urlsplit
from cryptography.fernet import Fernet
from auth_server import ServerVault, CloudServer, Broker, SafeError


class CloudTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.key = 'a' * 43
        self.encryption = Fernet.generate_key()
        self.config = {'client_id': 'test.apps.googleusercontent.com', 'client_secret': 'private-secret'}
        self.vault = ServerVault(self.temp.name, self.config, self.key, self.encryption)
        self.now = 1000
        self.calls = []
        self.channel = 'UC' + 'a' * 22
        self.broker = self.new_broker()

    def fetch(self, url, form=None, token=None):
        self.calls.append((url, form))
        if '/channels?' in url:
            return {'items': [{'id': self.channel, 'snippet': {'title': 'Brand'}}]}
        return {'access_token': 'short-lived', 'refresh_token': 'never-send-to-phone',
                'expires_in': 3600, 'scope': 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly'}

    def new_broker(self):
        return Broker(self.vault, self.fetch, lambda: self.now,
                      redirect='https://auth.example.com/oauth/callback', identity_prefix='server:')

    def finish(self):
        login = self.broker.start()
        query = parse_qs(urlsplit(login['url']).query)
        self.assertEqual(query['redirect_uri'], ['https://auth.example.com/oauth/callback'])
        self.broker.callback({'state': query['state'], 'code': ['test-code']})
        self.assertEqual(self.calls[0][1]['redirect_uri'], query['redirect_uri'][0])
        return query

    def test_restart_refresh_without_browser_and_encrypted_disk(self):
        query = self.finish()
        data = (Path(self.temp.name) / 'grant.enc').read_bytes()
        self.assertNotIn(b'never-send-to-phone', data)
        self.assertNotIn(b'short-lived', data)
        self.broker = self.new_broker()  # Simulate process restart with the same volume/key.
        self.now += 3550
        result = self.broker.token()
        self.assertTrue(result['identity'].startswith('server:'))
        self.assertNotIn('refresh_token', result)
        self.assertNotIn('private-secret', json.dumps(result))
        self.assertEqual(self.calls[-2][1]['grant_type'], 'refresh_token')
        with self.assertRaises(SafeError):
            self.broker.callback({'state': query['state'], 'code': ['replay']})
        self.broker.disconnect()
        self.assertIsNone(self.vault.read('grant'))

    def test_wrong_key_and_tampered_cipher_fail_closed(self):
        self.finish()
        with self.assertRaises(SafeError):
            ServerVault(self.temp.name, self.config, self.key, Fernet.generate_key())
        (Path(self.temp.name) / 'grant.enc').write_bytes(b'tampered')
        with self.assertRaises(SafeError):
            self.vault.read('grant')

    def test_changed_channel_cannot_refresh(self):
        self.finish()
        self.now += 3550
        self.channel = 'UC' + 'b' * 22
        with self.assertRaises(SafeError):
            self.broker.token()

    def test_https_proxy_protocol_rejects_host_key_origin_and_body(self):
        server = CloudServer(self.broker, 'auth.example.com', ('127.0.0.1', 0))
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        def request(method, path, headers=None, body=None):
            connection = http.client.HTTPConnection('127.0.0.1', server.server_port)
            headers = {'Host': 'auth.example.com', **(headers or {})}
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            code, result = response.status, response.read()
            connection.close()
            return code, result
        try:
            self.assertEqual(request('POST', '/api/login')[0], 401)
            auth = {'Authorization': 'Bearer ' + self.key}
            self.assertEqual(request('POST', '/api/login', {**auth, 'Host': 'evil.example'})[0], 400)
            self.assertEqual(request('POST', '/api/login', {**auth, 'Origin': 'https://evil.example'})[0], 403)
            self.assertEqual(request('POST', '/api/login', auth, b'x')[0], 400)
            self.assertEqual(request('POST', '/api/login', auth)[0], 200)
            status, response = request('GET', '/health')
            self.assertEqual(status, 200)
            self.assertNotIn(b'configured', response)
            self.assertNotIn(self.key.encode(), response)
        finally:
            server.shutdown()
            worker.join()
            server.server_close()


if __name__ == '__main__':
    unittest.main()
