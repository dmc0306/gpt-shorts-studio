"""Generate private single-owner server settings; never print secrets."""
import base64
import json
import os
from pathlib import Path
import re
import secrets


def main():
    folder = Path(__file__).resolve().parent
    if (folder / '.env').exists() or (folder / 'connection.txt').exists():
        raise ValueError('Settings already exist. Keep the existing encryption key; do not overwrite.')
    domain = input('Public auth hostname (auth.example.com): ').strip()
    if not re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?', domain) or '.' not in domain:
        raise ValueError('Invalid hostname.')
    path = input('Google Web OAuth client JSON file path: ').strip().strip('"')
    data = json.loads(Path(path).read_text(encoding='utf-8-sig'))['web']
    redirect = 'https://' + domain + '/oauth/callback'
    if redirect not in data.get('redirect_uris', []):
        raise ValueError('Register ' + redirect + ' in Google Cloud and download the Web client JSON again.')
    client, secret = data['client_id'], data['client_secret']
    if not client.endswith('.apps.googleusercontent.com') or not re.fullmatch(r'[A-Za-z0-9_-]+', secret):
        raise ValueError('Invalid Web client JSON.')
    key = secrets.token_urlsafe(32)
    encryption = base64.urlsafe_b64encode(os.urandom(32)).decode()
    values = {'AUTH_DOMAIN': domain, 'GOOGLE_CLIENT_ID': client,
              'GOOGLE_CLIENT_SECRET': secret, 'AUTH_PAIRING_KEY': key,
              'AUTH_ENCRYPTION_KEY': encryption}
    def save(name, text):
        fd = os.open(folder / name, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'w', encoding='utf8') as f:
            f.write(text)
    save('.env', ''.join(k + '=' + v + '\n' for k, v in values.items()))
    save('connection.txt', 'Server: https://' + domain + '\nConnection key: ' + key + '\n')
    print('Private server/.env and server/connection.txt created. Do not upload or share these files.')
    print('On Windows, keep these files in your private user folder with restricted NTFS permissions.')


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError):
        print('Setup failed. Check hostname, client JSON, callback registration and existing files. No secrets printed.')
        raise SystemExit(1)
