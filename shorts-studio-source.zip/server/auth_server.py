"""Single-owner OAuth broker, behind the bundled HTTPS reverse proxy.
Never expose port 8000 directly. One process owns the encrypted credential volume.
"""
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from cryptography.fernet import Fernet, InvalidToken
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tool'))
from youtube_pc import Broker, Handler, SafeError, ThreadingHTTPServer


class ServerVault:
    def __init__(self, folder, config, key, encryption_key):
        self.folder = Path(folder)
        self.folder.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.config = config
        if not re.fullmatch(r'[A-Za-z0-9_-]{43}', key):
            raise SafeError('Invalid server pairing key.')
        self.key = key
        self.cipher = Fernet(encryption_key)
        # Detect wrong volume/encryption key at startup, never overwrite unreadable grants.
        self.read('grant')

    def pair_key(self):
        return self.key

    def read(self, name):
        if name == 'client':
            return self.config.copy()
        if name != 'grant':
            raise SafeError('Invalid credential slot.')
        path = self.folder / 'grant.enc'
        if not path.exists():
            return None
        try:
            return json.loads(self.cipher.decrypt(path.read_bytes()))
        except (InvalidToken, ValueError, OSError):
            raise SafeError('Cannot decrypt stored credentials. Restore the original encryption key.') from None

    def write(self, name, value):
        if name != 'grant':
            raise SafeError('Invalid credential slot.')
        blob = self.cipher.encrypt(json.dumps(value).encode())
        temporary = self.folder / 'grant.tmp'
        fd = os.open(temporary, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(blob)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(self.folder / 'grant.enc')
        directory = os.open(self.folder, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)

    def remove(self, name):
        if name != 'grant':
            raise SafeError('Invalid credential slot.')
        (self.folder / 'grant.enc').unlink(missing_ok=True)


class CloudHandler(Handler):
    def valid_host(self, host):
        return host in (self.server.public_host, self.server.public_host + ':443')

    def handle_request(self):
        # Do not accept attacker-controlled Host/X-Forwarded-* as OAuth redirect input.
        if not self.valid_host(self.headers.get('Host', '')):
            return self.reply(400, {'error': 'AUTH_HOST'})
        if not self.server.allow_request(self.path):
            return self.reply(429, {'error': 'AUTH_RATE'})
        if self.command == 'POST':
            try:
                length = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                return self.reply(400, {'error': 'AUTH_SIZE'})
            if length != 0 or self.headers.get('Transfer-Encoding'):
                return self.reply(400, {'error': 'AUTH_SIZE'})
        if self.path == '/health' and self.command == 'GET':
            return self.reply(200, {'service': 'shorts-studio-auth', 'version': 2})
        super().handle_request()

    def reply(self, status, body, html=False):
        if not html and isinstance(body, dict) and 'error' in body:
            message = body['error']
            # OAuth errors are redacted; preserve only actionable safe diagnostic codes.
            body = {'error': 'YT_CHANNEL_COUNT' if 'YT_CHANNEL_COUNT' in message else
                    'AUTH_KEY' if status == 401 else
                    'AUTH_RATE' if status == 429 else 'AUTH_RECONNECT'}
        super().reply(status, body, html)


class CloudServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def __init__(self, broker, host, address=('0.0.0.0', 8000)):
        self.broker, self.public_host = broker, host
        self._rate_lock = threading.Lock()
        self._requests = {}
        self._slots = threading.BoundedSemaphore(16)
        super().__init__(address, CloudHandler)

    def allow_request(self, path):
        # Bounded global buckets are sufficient for this single-owner deployment.
        # Includes browser polling; authentication attempts limited to 12 / minute.
        group = 'login' if path == '/api/login' else 'all'
        limit, period = (12, 60) if group == 'login' else (600, 60)
        now = int(time.monotonic() // period)
        with self._rate_lock:
            bucket, count = self._requests.get(group, (now, 0))
            count = count + 1 if bucket == now else 1
            self._requests[group] = (now, count)
            return count <= limit

    def process_request(self, request, address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self._slots.release()

    def handle_error(self, request, client_address):
        pass  # No raw request paths, headers, tokens or tracebacks in logs.


def create_server(env=os.environ):
    domain = env['AUTH_DOMAIN']
    if not re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?', domain) or '.' not in domain:
        raise SafeError('Set a public DNS hostname without a scheme or path.')
    config = {'client_id': env['GOOGLE_CLIENT_ID'], 'client_secret': env['GOOGLE_CLIENT_SECRET']}
    if not config['client_id'].endswith('.apps.googleusercontent.com') or not config['client_secret']:
        raise SafeError('Configure the Google Web OAuth client.')
    vault = ServerVault(env.get('AUTH_DATA_DIR', '/data'), config,
                        env['AUTH_PAIRING_KEY'], env['AUTH_ENCRYPTION_KEY'])
    broker = Broker(vault, redirect='https://' + domain + '/oauth/callback', identity_prefix='server:')
    return CloudServer(broker, domain)


if __name__ == '__main__':
    try:
        server = create_server()
        print('Shorts Studio auth ready behind HTTPS proxy.', flush=True)
        server.serve_forever()
    except (SafeError, KeyError, ValueError, OSError):
        print('Auth startup failed. Check private environment settings and credential volume.', flush=True)
        raise SystemExit(1)
